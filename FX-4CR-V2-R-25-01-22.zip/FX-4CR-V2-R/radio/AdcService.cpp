/*
 * This file is part of the FX-4CR-V2 project.
 * See: https://github.com/f5bud/FX-4CR-V2
 *
 * Copyright (c) 2024 Daniel Nespoulous, F5BUD
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE. 
 */
//-----------------------------------------------------------------------------
//	AdcService.cpp
//-----------------------------------------------------------------------------
#include "AdcService.h"

//-----------------------------------------------------------------------------
void AdcService::Init()
{
	AdcBase().Init(ADC1);														// Vcc, Pow, Fwr

	GpioPin(GPIOA, 0, eAnaMode, eOpenDrain, eLowSpeed, ePullNone, 0);			// Fwd, INP16
	GpioPin(GPIOA, 1, eAnaMode, eOpenDrain, eLowSpeed, ePullNone, 0);			// Swr, INP17
	GpioPin(GPIOC, 0, eAnaMode, eOpenDrain, eLowSpeed, ePullNone, 0);			// Vox, INP10
	GpioPin(GPIOC, 3, eAnaMode, eOpenDrain, eLowSpeed, ePullNone, 0);			// Dcv, INP13

	mAdcIndex = 0;

	mAdcValues[0] = 0;
	mAdcValues[1] = 0;
	mAdcValues[2] = 0;
	mAdcValues[3] = 0;

	ADC1->CR    = 0x00;
	ADC1->CFGR  = 0x00;
	ADC1->CFGR2 = 0x00;
	ADC1->PCSEL = 0x00;
	ADC1->SQR1  = 0x00;
	ADC1->SMPR1 = 0xffff'ffff;													// all 810.5 ADC clock cycles
	ADC1->SMPR2 = 0xffff'ffff;													// all 810.5 ADC clock cycles
	ADC12_COMMON->CCR = 0x00;

	SET_BIT(ADC1->CR, ADC_CR_BOOST);											// 1: Boost mode on

	MODIFY_REG(ADC12_COMMON->CCR, ADC_CCR_CKMODE, 2UL << ADC_CCR_CKMODE_Pos);	// 1: adc_hclk/2 (Synchronous clock mode)

	SET_BIT(ADC1->CFGR, ADC_CFGR_CONT);											// 1: Continuous conversion mode
	SET_BIT(ADC1->CFGR, ADC_CFGR_AUTDLY);										// 1: Auto-delayed conversion mode on

	MODIFY_REG(ADC1->CFGR2, ADC_CFGR2_OVSR, 255UL << ADC_CFGR2_OVSR_Pos);		// 256 Conventions
	MODIFY_REG(ADC1->CFGR2, ADC_CFGR2_OVSS,   8UL << ADC_CFGR2_OVSS_Pos);		// Shift right 8-bits

	SET_BIT(ADC1->CFGR2, ADC_CFGR2_ROVSE);										// 1: Regular Oversampling enabled

//	input select

	SET_BIT(ADC1->PCSEL, ADC_PCSEL_PCSEL_16);
	SET_BIT(ADC1->PCSEL, ADC_PCSEL_PCSEL_17);
	SET_BIT(ADC1->PCSEL, ADC_PCSEL_PCSEL_10);
	SET_BIT(ADC1->PCSEL, ADC_PCSEL_PCSEL_13);

	MODIFY_REG(ADC1->SQR1, ADC_SQR1_SQ1, 16UL << ADC_SQR1_SQ1_Pos);				// Fwd
	MODIFY_REG(ADC1->SQR1, ADC_SQR1_SQ2, 17UL << ADC_SQR1_SQ2_Pos);				// Rev
	MODIFY_REG(ADC1->SQR1, ADC_SQR1_SQ3, 10UL << ADC_SQR1_SQ3_Pos);				// Vox
	MODIFY_REG(ADC1->SQR1, ADC_SQR1_SQ4, 13UL << ADC_SQR1_SQ4_Pos);				// DcV

	MODIFY_REG(ADC1->SQR1, ADC_SQR1_L, 3UL << ADC_SQR1_L_Pos);					// 4 conversions

//	Calibre

	SET_BIT(ADC1->CR, ADC_CR_ADVREGEN);											// 1: ADC Voltage regulator enabled
	while((ADC1->ISR & ADC_ISR_LDORDY) == 0);

	SET_BIT(ADC1->CR, ADC_CR_ADCALLIN);											// 1: ADC Linearity calibration
	SET_BIT(ADC1->CR, ADC_CR_ADCAL);											// 1: Write 1 to calibrate the ADC
	while(ADC1->CR & ADC_CR_ADCAL);

	SET_BIT(ADC1->CR, ADC_CR_ADEN);												// 1: Write 1 to enable the ADC
	while((ADC1->ISR & ADC_ISR_ADRDY) == 0);

	SET_BIT(ADC1->CR, ADC_CR_ADSTART);											// start regular conversions
}
//-----------------------------------------------------------------------------
void AdcService::Loop()
{
	if (ADC1->ISR & ADC_ISR_EOC)
	{
		int32_t value = ADC1->DR;
		int16_t index = mAdcIndex & 3;

		mAdcPeaks [index] = std::max(mAdcPeaks[index], value);
		mAdcValues[index] = value;

		mAdcIndex ++;
	}
}
//-----------------------------------------------------------------------------
int32_t AdcService::getPwr()
{
	int32_t value = std::max(mAdcValues[0], mAdcPeaks[0]);						// return peak Fwd

	mAdcPeaks[0] = 0L;

	return value;
}
//-----------------------------------------------------------------------------
float32_t AdcService::getSwr()
{
	float32_t adcFwd = mAdcValues[0] + 100L;									// diode gap
	float32_t adcRev = mAdcValues[1] + 100L;									// diode gap

	if (adcFwd < 300.0f) return 0.0f;

	return (adcFwd + adcRev) / (adcFwd - adcRev);
}
//-----------------------------------------------------------------------------
int32_t AdcService::getVolt()
{
	return mAdcValues[3];
}
//-----------------------------------------------------------------------------
