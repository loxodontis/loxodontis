/*
 * This file is part of the FX-4CR-V2 project.
 * See: https://github.com/f5bud/FX-4CR-V2
 *
 * Copyright (c) 2024 Daniel Nespoulous, F5BUD
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE. 
 */
//-----------------------------------------------------------------------------
//	Si5351.cpp
//-----------------------------------------------------------------------------
#include "Si5351.h"
#include "Eeprom.h"

//-----------------------------------------------------------------------------
void Si5351::Init(Thread &thread)
{
	gI2cData.WriteByte(SI5351, SI5351_RESET, 0b1010'0000);								// PLLB_Reset, PLLA_Reset

	thread.Delay(50);

	gI2cData.WriteByte(SI5351, SI5351_CLK0, 0b1000'0000);								// PDN=1: Power off
//	gI2cData.WriteByte(SI5351, SI5351_CLK1, 0b1000'0000);								// PDN=1: Power off
	gI2cData.WriteByte(SI5351, SI5351_CLK1, 0b0110'1100);								// INT=1: integer mode, SRC=11: MultiSynth PLLB, IDRV=00: 2 mA
	gI2cData.WriteByte(SI5351, SI5351_CLK2, 0b0100'1100);								// INT=1: integer mode, SRC=11: MultiSynth PLLA, IDRV=00: 2 mA
}
//-----------------------------------------------------------------------------
void Si5351::SetFreq(int32_t tcxo, int32_t freq)
{
	if ((mTcxo != tcxo) || (mFrequency != freq))
	{
		mTcxo = tcxo;
		mFrequency = freq;

		float num;
		int32_t mul;
		int32_t div = 900'000'000L / freq;

		if (div % 2L) div --;

		int32_t vco = div * freq;

		mul = vco / tcxo;
		num = vco % tcxo;
		num *= 0x0FFFFFL;
		num /= tcxo;

		int32_t tmp = num;

		num = tmp * 128L / 0x0FFFFFL;

		int32_t MSx_P1 = div * 128L - 512L;

		int32_t Pllx_P1 = mul * 128L + num - 512L;
		int32_t Pllx_P2 = tmp * 128L - num * 0x0FFFFFL;

		Pll(SI5351_PLLB, Pllx_P1, Pllx_P2);
		Synth(SI5351_MS1, MSx_P1);

		Pll(SI5351_PLLA, Pllx_P1, Pllx_P2);
		Synth(SI5351_MS2, MSx_P1);
	}
}
//-----------------------------------------------------------------------------
void Si5351::Pll(uint8_t reg, int32_t P1, int32_t P2)
{
	gI2cData.WriteByte(SI5351, reg + 0, 0xFF);										// 26: PLLx_P3[15: 8]
	gI2cData.WriteByte(SI5351, reg + 1, 0xFF);										// 27: PLLx_P3[ 7: 0]

	gI2cData.WriteByte(SI5351, reg + 2, (P1 & 0x030000L) >> 16);					// 28: PLLx_P1[17:16]
	gI2cData.WriteByte(SI5351, reg + 3, (P1 & 0x00FF00L) >>  8);					// 29: PLLx_P1[15: 8]
	gI2cData.WriteByte(SI5351, reg + 4,  P1 & 0x0000FFL);							// 30: PLLx_P1[ 7: 0]

	gI2cData.WriteByte(SI5351, reg + 5, (P2 & 0x0F0000L) >> 16 | 0xF0);				// 31: PLLx_P3[19:16], PLLx_P2[19:16]
	gI2cData.WriteByte(SI5351, reg + 6, (P2 & 0x00FF00L) >>  8);					// 32: PLLx_P2[15: 8]
	gI2cData.WriteByte(SI5351, reg + 7,  P2 & 0x0000FFL);							// 33: PLLx_P2[ 7: 0]
}
//-----------------------------------------------------------------------------
void Si5351::Synth(uint8_t reg, int32_t P1)
{
	gI2cData.WriteByte(SI5351, reg + 0, 0x00);										// 58: MSx_P3[15: 8]
	gI2cData.WriteByte(SI5351, reg + 1, 0x01);										// 59: MSx_P3[ 7: 0]

	gI2cData.WriteByte(SI5351, reg + 2, (P1 & 0x030000) >> 16);						// 60: MSx_P1[17:16]
	gI2cData.WriteByte(SI5351, reg + 3, (P1 & 0x00FF00) >>  8);						// 61: MSx_P1[15: 8]
	gI2cData.WriteByte(SI5351, reg + 4,  P1 & 0x0000FF);							// 62: MSx_P1[ 7: 0]

	gI2cData.WriteByte(SI5351, reg + 5, 0x00);										// 63: MSx_P3[19:16], MS2_P2[19:16]
	gI2cData.WriteByte(SI5351, reg + 6, 0x00);										// 64: MSx_P2[15: 8]
	gI2cData.WriteByte(SI5351, reg + 7, 0x00);										// 65: MSx_P2[ 7: 0]
}
//-----------------------------------------------------------------------------
