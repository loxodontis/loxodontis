/*
 * This file is part of the FX-4CR-V2 project.
 * See: https://github.com/f5bud/FX-4CR-V2
 *
 * Copyright (c) 2024 Daniel Nespoulous, F5BUD
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE. 
 */
//-----------------------------------------------------------------------------
//	RadioTask.cpp
//-----------------------------------------------------------------------------
#include "RadioTask.h"
#include "UserTask.h"
#include "Format.h"

//-----------------------------------------------------------------------------
RadioTask gRadioTask;

//-----------------------------------------------------------------------------
void RadioTask::Handler()
{
	gRadioTask.Loop();
}
//-----------------------------------------------------------------------------
void RadioTask::Loop()
{
	SaiSwitch::Init(*this);

	mSi5351.Init(*this);

	while (1)
	{
		setState(SUSPENDED);

		mParamType.AgcSpeed  = gUserTask.getAgcSpeed	();
		mParamType.AdcAux	 = gUserTask.getAdcAux		();
		mParamType.AdcMic	 = gUserTask.getAdcMic		();
		mParamType.RxAtt	 = gUserTask.getRxAtt		();
		mParamType.Band		 = gUserTask.getBand		();
		mParamType.CwPitch   = gUserTask.getCwPitch		();
		mParamType.DacAux	 = gUserTask.getDacAux		();
		mParamType.DspStatus = gUserTask.getDspStatus	();
//		mParamType.DspValue  = gUserTask.getDspValue	();
		mParamType.InputType = gUserTask.getKeyTone		();
		mParamType.Filter    = gUserTask.getFilter		();
		mParamType.Mode      = gUserTask.getMode		();
		mParamType.Muted	 = gUserTask.getSqlValue	() > getSmeter();
		mParamType.Relays    = gUserTask.getRelays		();
		mParamType.RssiCal   = gUserTask.getRssiCal		();
		mParamType.SetBand   = gUserTask.getSetBand		();
		mParamType.Speaker	 = gUserTask.getSpeaker		();
		mParamType.TxPower   = gUserTask.getTxPower		();

		switch (mParamType.InputType)
		{
		case eVxMonitor:
		case eVxRecord:
			RadioVx();
			break;

		case eRxIQ:
			RadioRx();
			ComputeRssi();
			break;

		default:			// eTxNone, eTxKey, eTxMic, eTxAux, eVxPlayer
			RadioTx();
			break;
		}
	}
}
//-----------------------------------------------------------------------------
void RadioTask::RadioRx()
{
	mSi5351.SetFreq(gUserTask.getTcxoCal(), (gUserTask.getRxFrequency() - L24000) * 2L);
	mSi5351AB.setLow();	//maybe used for VFOA or VFOB

	if ((mCurMode  != mParamType.Mode) ||
		(mCurBand  != mParamType.Band) ||
		(mCurRxAtt != mParamType.RxAtt))
	{
		mCurMode  = mParamType.Mode;
		mCurBand  = mParamType.Band;
		mCurRxAtt = mParamType.RxAtt;

		stopSignal();
	}

	if (mRadioRX == nullptr)
	{
		stopSignal();

		mTransmit.setHigh();													// HF power OFF
		mPttOut.setLow();														// switch output mixer

		mTxRelay0.setLow();														// Power filters OFF
		mTxRelay1.setLow();
		mTxRelay2.setLow();
		mTxRelay3.setLow();
		mTxRelay4.setLow();
		mTxRelay5.setLow();

		mFilter0.setPin((mParamType.Relays.RxTxFilter >> 0) & 1);				// Rx/Tx filters
		mFilter1.setPin((mParamType.Relays.RxTxFilter >> 1) & 1);
		mFilter2.setPin((mParamType.Relays.RxTxFilter >> 2) & 1);
		mFilter3.setPin((mParamType.Relays.RxTxFilter >> 3) & 1);

		mRxAtt.setPin(mParamType.RxAtt);										// false = attenuator
	}

	setRecept(mParamType);														// switch
}
//-----------------------------------------------------------------------------
void RadioTask::RadioTx()
{
	if (gUserTask.canTransmit())
	{
		if (gUserTask.getCwPractice() == false)
		{
			mSi5351.SetFreq(gUserTask.getTcxoCal(), (gUserTask.getTxFrequency() - L24000) * 2L);

			if (mRadioTX == nullptr)
			{
				stopSignal();

				mRxAtt.setLow();												// pre-amp off

				mTxRelay0.setPin(mParamType.Relays.TxRelay0);					// Power filters ON
				mTxRelay1.setPin(mParamType.Relays.TxRelay1);
				mTxRelay2.setPin(mParamType.Relays.TxRelay2);
				mTxRelay3.setPin(mParamType.Relays.TxRelay3);
				mTxRelay4.setPin(mParamType.Relays.TxRelay4);
				mTxRelay5.setPin(mParamType.Relays.TxRelay5);

				mPttOut.setHigh();												// switch output mixer
				mTransmit.setLow();												// HF power ON
			}

			mParamType.Filter = 2700;											// forced to transmit

			setTransmit(mParamType);											// repeat for update() !!!
		}
	}
}
//-----------------------------------------------------------------------------
void RadioTask::RadioVx()
{
	if (mRadioVX == nullptr)
	{
		stopSignal();
	}

	mParamType.Filter = 2700;													// forced to transmit

	setVoice(mParamType);														// repeat for update() !!!
}
//-----------------------------------------------------------------------------
int16_t RadioTask::getAlc()
{
	return mRadioTX ? mRadioTX->getRate() : 0;
}
//-----------------------------------------------------------------------------
int32_t * RadioTask::getRssiArray()
{
	return mRssiArray;
}
//-----------------------------------------------------------------------------
int16_t RadioTask::getRssiDb()
{
	return mRssiDb;
}
//-----------------------------------------------------------------------------
std::string	RadioTask::getRssiDbStr()
{
	return Format().Fmt("%ddb", mRssiDb);
}
//-----------------------------------------------------------------------------
int16_t RadioTask::getSmeter()
{
	#define RSSI_SIZE 15

	static const int16_t rssiValues[RSSI_SIZE] =
	{
	//	  S1    S2    S3    S4   S5   S6   S7   S8   S9   10   20   30   40   50   60
		-121, -115, -109, -103, -97, -91, -85, -79, -73, -63, -53, -43, -33, -23, -13
	};

	for (int16_t i = 0; i < RSSI_SIZE; i ++)
	{
		if (mRssiDb <= rssiValues[i])
		{
			return (i * 100) / (RSSI_SIZE - 1);
		}
	}

	return 100;
}
//-----------------------------------------------------------------------------
float32_t RadioTask::getSwr()
{
	return mAdcService.getSwr();
}
//-----------------------------------------------------------------------------
std::string RadioTask::getSwrAlcStr()
{
	return Format().Fmt("Swr: %.1f Alc: %3d%%", getSwr(), getAlc());
}
//-----------------------------------------------------------------------------
std::string RadioTask::getTempStr()
{
	int16_t value = mTempService.getTemp();

	if (gUserTask.getDegreCF())
	{
		return Format().Fmt("%2d|f", ((value * 9) / 5) + 32);
	}

	return Format().Fmt("%2d|c", value);
}
//-----------------------------------------------------------------------------
float32_t RadioTask::getVolt()
{
	return (float32_t) mAdcService.getVolt() / gUserTask.getVoltCal();
}
//-----------------------------------------------------------------------------
std::string RadioTask::getVoltStr()
{
	return Format().Fmt("%.2fv", getVolt());
}
//-----------------------------------------------------------------------------
float32_t RadioTask::getWatt()
{
	float32_t adcFwd = (mAdcService.getPwr() + 3000.0f) / 100.0f;							// diode gap

	if (adcFwd < 35.0f) return 0.0f;

	return (adcFwd * adcFwd) / (gUserTask.getWattCal() * 10.0f);
}
//-----------------------------------------------------------------------------
std::string RadioTask::getWattStr()
{
	return Format().Fmt("%.2fw", getWatt());
}
//-----------------------------------------------------------------------------
float32_t RadioTask::FftToWf(float32_t value)
{
	float32_t inc = 0.0f;
	float32_t lim = 0.0f;

	while (inc < 45.0f)															// 45: height and 45/3 = 15: color
	{
		lim += inc * 0.002f;

		if (lim > value) break;

		inc ++;
	}

	return inc;
}
//-----------------------------------------------------------------------------
void RadioTask::ComputeRssi()
{
	if (mRadioRX)
	{
		Complex *fftArray = mRadioRX->getDspFft()->Compute();					// -73db = 2.757634

		if (fftArray)
		{
			int16_t   width  = FFT_SIZE / (gUserTask.getFftWidth() * 2);		// 1, 2, 4 => 512, 256, 128
			Complex  *buffer = fftArray + FFT_24000 - (width / 2);				// index = left of 24kHz
			float32_t smooth = gUserTask.getFftSmooth();

			for (int16_t i = 0; i < SCREEN_SIZE; i ++)
			{
				int16_t x = (i * width) / SCREEN_SIZE;
				float32_t temp = FftToWf(buffer[x].mag());

				mRssiArray[i] -= mRssiArray[i] / smooth;
				mRssiArray[i] += temp          / smooth;
			}

			width = (mParamType.Filter * FFT_24000) / L24000;

			switch(mParamType.Mode)
			{
			case eSSBL:					// left signal
			case eDIGL:
				buffer = fftArray + FFT_24000 - width;
				break;

			case eSSBU:					// right signal
			case eDIGU:
				buffer = fftArray + FFT_24000;
				break;

			default:					// center signal
				buffer = fftArray + FFT_24000 - (width / 2);
				break;
			}

			float32_t temp = 0.0f;

			while (width --)
			{
				temp = std::max(temp, buffer[width].mag());
			}

			mRssiDb = (20.0f * log10f(temp)) - sqrt(10.0f + mRadioRX->getAd605()) - mParamType.RssiCal;

			mRadioRX->getDspFft()->Init();
		}
	}
}
//-----------------------------------------------------------------------------
bool RadioTask::isOnAir()
{
	return mRadioTX;			// ? nullptr
}
//-----------------------------------------------------------------------------
