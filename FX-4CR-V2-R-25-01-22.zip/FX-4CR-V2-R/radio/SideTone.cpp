/*
 * This file is part of the FX-4CR-V2 project.
 * See: https://github.com/f5bud/FX-4CR-V2
 *
 * Copyright (c) 2024 Daniel Nespoulous, F5BUD
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE. 
 */
//-----------------------------------------------------------------------------
//	SideTone.cpp
//-----------------------------------------------------------------------------
#include "SideTone.h"
#include "UserTask.h"
#include "RadioTask.h"

//-----------------------------------------------------------------------------
static SideTone *sInternal;
/*
If the keyer is in mode A, it will finish sending the current element and then stop.
If the keyer is in mode B, it will finish sending the current element, send another element and then stop.
*/
//-----------------------------------------------------------------------------
extern "C" void CEC_IRQHandler()												// Chose unused interrupt, see kernel
{
	sInternal->Handler();														// 1ms tick
}
//-----------------------------------------------------------------------------
void SideTone::Init()
{
	sInternal = this;

	mToneGen.Init();
	mToneGen.setCwPitch(gUserTask.getCwPitch());
	mToneGen.setCwAudio(gUserTask.getCwAudio());

	mStateType = eWaitDit;
	mInputType = eRxIQ;
}
//-----------------------------------------------------------------------------
void SideTone::setEditTemp(char *value, int16_t size)
{
	CwService::setEditTemp(value, size);

	(value) ? sideToneOn() : sideToneOff();
}
//-----------------------------------------------------------------------------
void SideTone::sideToneOn()
{
	int32_t delay = (6000L / (gUserTask.getCwSpeed() * 5L));

	if (mToneDelay != delay)
	{
		mToneDelay = delay;
		Reset(delay);
	}

	mToneGen.setCwPitch(gUserTask.getCwPitch());
	mToneGen.setCwAudio(gUserTask.getCwAudio());

	mTxRxDelay = gUserTask.getCwDelay();

	mCwKeyType = isTxMessage() ? eCallerCw : gUserTask.getCwKey();

	switch(mCwKeyType)
	{
	case eIambicRegA:
		mReverse  = false;
		mIambicAB = false;
		break;

	case eIambicRevA:
		mReverse  = true;
		mIambicAB = false;
		break;

	case eIambicRegB:
		mReverse  = false;
		mIambicAB = true;
		break;

	case eIambicRevB:
		mReverse  = true;
		mIambicAB = true;
		break;

	case eStraightKey:
		mReverse  = false;
		mNewDah   = false;														// reset unused key
		break;

	default:
		break;
	}

	NVIC_EnableIRQ(CEC_IRQn);
}
//-----------------------------------------------------------------------------
void SideTone::sideToneOff()
{
	mToneGen.setEnabled(false);

	mInputType = eRxIQ;
	mStateType = eWaitDit;
	mCounter   = 0;
	mNewDit    = false;
	mNewDah    = false;

	NVIC_DisableIRQ(CEC_IRQn);
}
//-----------------------------------------------------------------------------
void SideTone::Handler()
{
	switch(mCwKeyType)
	{
	case eStraightKey:
		simpleKeyer();
		break;

	case eCallerCw:
		messageKeyer();
		break;

	default:
		paddleKeyer();
		break;
	}

	Process(mInputType == eTxKey);
}
//-----------------------------------------------------------------------------
void SideTone::simpleKeyer()
{
	updateKeys();

	if (getDitKey() | getPttKey())												// by Dit, Micro PTT or RTS
		mStateType = eQuietDit;

	switch (mStateType)
	{
	case eWaitDit:
	case eWaitDah:
		if (mCounter < 0)
			setKeyTone(eRxIQ);
		else
			mCounter --;

		break;

	case eQuietDit:
		setDitTime();
		break;

	default:
		setWaitTime(eWaitDit);
		break;
	}
}
//-----------------------------------------------------------------------------
void SideTone::paddleKeyer()
{
	switch (mStateType)
	{
	case eWaitDit:
		if (mCounter < 0)
			setKeyTone(eRxIQ);
		else
			mCounter --;														// delay: (CwDelay) 50mS ... 1000mS

		updateKeys();

		if (getDitKey())
		{
			setDitTime();
			break;
		}

		if (getDahKey())
		{
			setDahTime();
			break;
		}

		break;

	case eToneDit:
		if (mCounter < 0)
			setQuietTime(eQuietDit);
		else
			mCounter --;														// delay: (DitTime)

		if (mIambicAB) updateKeys();
		break;

	case eQuietDit:
		if (mCounter < 0)
			setWaitTime(eWaitDah);
		else
			mCounter --;														// delay: (DitTime)

		mNewDit = false;
		break;

	case eWaitDah:
		if (mCounter < 0)
			setKeyTone(eRxIQ);
		else
			mCounter --;														// delay: (CwDelay) 50mS ... 1000mS

		updateKeys();

		if (getDahKey())
		{
			setDahTime();
			break;
		}

		if (getDitKey())
		{
			setDitTime();
			break;
		}

		break;

	case eToneDah:
		if (mCounter < 0)
			setQuietTime(eQuietDah);
		else
			mCounter --;														// delay: (DitTime * 3)

		if (mIambicAB) updateKeys();
		break;

	case eQuietDah:
		if (mCounter < 0)
			setWaitTime(eWaitDit);
		else
			mCounter --;														// delay: (DitTime)

		mNewDah = false;
		break;
	}
}
//-----------------------------------------------------------------------------
void SideTone::messageKeyer()
{
	updateKeys();

	switch (mStateType)
	{
	case eWaitDit:
	case eWaitDah:
		if (mCounter < 0)
			setKeyTone(eRxIQ);
		else
			mCounter --;														// delay: (CwDelay) 50mS ... 1000mS

		if (getPttKey() || getDitKey() || getDahKey())							// if key hit then end message
		{
			mNewDit = false;
			mNewDah = false;
			mNewPtt = false;

			Stop();																// stop transmit buffer
		}

		switch(getNext() & 0b11)
		{
		case 0b01:																// space = 7 * Dit
			setQuietTime(eQuietDah, 4);
			break;

		case 0b10:																// Dit
			setDitTime();
			break;

		case 0b11:																// Dah = 3 * Dit
			setDahTime();
			break;

		default:
			setQuietTime(eQuietDah, 3);
			break;
		}

		break;

	case eToneDit:
	case eToneDah:
		if (mCounter < 0)
			setQuietTime(eQuietDah);
		else
			mCounter --;

		break;

	case eQuietDit:
	case eQuietDah:
		if (mCounter < 0)
			setWaitTime(eWaitDah);
		else
			mCounter --;

		break;
	}
}
//-----------------------------------------------------------------------------
void SideTone::setDitTime()
{
	mCounter = mToneDelay;

	mStateType = eToneDit;
	setKeyTone(eTxKey);
}
//-----------------------------------------------------------------------------
void SideTone::setDahTime()
{
	mCounter = mToneDelay * 3;

	mStateType = eToneDah;
	setKeyTone(eTxKey);
}
//-----------------------------------------------------------------------------
void SideTone::setQuietTime(eStateType state, int16_t mult)
{
	mCounter = mToneDelay * mult;

	mStateType = state;
	setKeyTone(eTxNone);
}
//-----------------------------------------------------------------------------
void SideTone::setWaitTime(eStateType state)
{
	mCounter = mTxRxDelay;

	mStateType = state;
	setKeyTone(eTxNone);
}
//-----------------------------------------------------------------------------
bool SideTone::getDitKey()
{
	bool result = mNewDit;

	mNewDit = false;

	return result;
}
//-----------------------------------------------------------------------------
bool SideTone::getDahKey()
{
	bool result = mNewDah;

	mNewDah = false;

	return result;
}
//-----------------------------------------------------------------------------
bool SideTone::getPttKey()
{
	bool result = mNewPtt;

	mNewPtt = false;

	return result;
}
//-----------------------------------------------------------------------------
void SideTone::updateKeys()
{
	mNewDit |= ((mReverse ? mDahHey : mDitKey).getPin() == false);
	mNewDah |= ((mReverse ? mDitKey : mDahHey).getPin() == false);
	mNewPtt |= gUserTask.getPttKey();
}
//-----------------------------------------------------------------------------
eInputType SideTone::getKeyTone()
{
	return mInputType;
}
//-----------------------------------------------------------------------------
void SideTone::setKeyTone(eInputType value)
{
	if (mInputType != value)
	{
		mToneGen.setEnabled(value == eTxKey);

		mInputType = value;

		gRadioTask.setState(READY);												// set task active
	}
}
//-----------------------------------------------------------------------------
