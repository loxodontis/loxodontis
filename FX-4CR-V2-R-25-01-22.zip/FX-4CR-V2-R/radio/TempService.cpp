/*
 * This file is part of the FX-4CR-V2 project.
 * See: https://github.com/f5bud/FX-4CR-V2
 *
 * Copyright (c) 2024 Daniel Nespoulous, F5BUD
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE. 
 */
//-----------------------------------------------------------------------------
//	TempService.cpp
//-----------------------------------------------------------------------------
#include "TempService.h"

//-----------------------------------------------------------------------------
void TempService::Init()
{
	AdcBase().Init(ADC3);

	mCalibre30 = (*TEMP_CAL030) * 33 / 25;										// Vref @ 2.5V
	mCalibre80 = (*TEMP_CAL110) * 33 / 25 - mCalibre30;							// Vref @ 2.5V

	mAdcBuffer = mCalibre30;

	ADC3->CR    = 0x00;
	ADC3->CFGR  = 0x00;
	ADC3->CFGR2 = 0x00;
	ADC3->PCSEL = 0x00;
	ADC3->SQR1  = 0x00;
	ADC3->SMPR1 = 0xffff'ffff;													// all 810.5 ADC clock cycles
	ADC3->SMPR2 = 0xffff'ffff;													// all 810.5 ADC clock cycles
	ADC3_COMMON->CCR = 0x00;

	SET_BIT(ADC3_COMMON->CCR, ADC_CCR_TSEN);									// 1: Temperature sensor channel enabled

	SET_BIT(ADC3->CR, ADC_CR_BOOST);											// 1: Boost mode on

	MODIFY_REG(ADC3_COMMON->CCR, ADC_CCR_CKMODE, 2UL << ADC_CCR_CKMODE_Pos);	// 1: adc_hclk/2 (Synchronous clock mode)

	SET_BIT(ADC3->CFGR, ADC_CFGR_CONT);											// 1: Continuous conversion mode
	SET_BIT(ADC3->CFGR, ADC_CFGR_AUTDLY);										// 1: Auto-delayed conversion mode on

	MODIFY_REG(ADC3->CFGR2, ADC_CFGR2_OVSR, 255UL << ADC_CFGR2_OVSR_Pos);		// 256 Conventions
	MODIFY_REG(ADC3->CFGR2, ADC_CFGR2_OVSS,   8UL << ADC_CFGR2_OVSS_Pos);		// Shift right 8-bits

	SET_BIT(ADC3->CFGR2, ADC_CFGR2_ROVSE);										// 1: Regular Oversampling enabled

//	input select

	SET_BIT(ADC3->PCSEL, ADC_PCSEL_PCSEL_18);									// 1: Input Channel (temperature)

	MODIFY_REG(ADC3->SQR1, ADC_SQR1_SQ1, 18UL << ADC_SQR1_SQ1_Pos);				// 18 = Temperature

//	Calibre

	SET_BIT(ADC3->CR, ADC_CR_ADVREGEN);											// 1: ADC Voltage regulator enabled
	while((ADC3->ISR & ADC_ISR_LDORDY) == 0);

	SET_BIT(ADC3->CR, ADC_CR_ADCALLIN);											// 1: ADC Linearity calibration
	SET_BIT(ADC3->CR, ADC_CR_ADCAL);											// 1: Write 1 to calibrate the ADC
	while(ADC3->CR & ADC_CR_ADCAL);

	SET_BIT(ADC3->CR, ADC_CR_ADEN);												// 1: Write 1 to enable the ADC
	while((ADC3->ISR & ADC_ISR_ADRDY) == 0);

	SET_BIT(ADC3->CR, ADC_CR_ADSTART);											// start regular conversions
}
//-----------------------------------------------------------------------------
void TempService::Loop()
{
	if (ADC3->ISR & ADC_ISR_EOC)
	{
		mAdcBuffer = ADC3->DR;
	}
}
//-----------------------------------------------------------------------------
int16_t TempService::getTemp()
{
	if (std::abs(mOldValue - mAdcBuffer) > 50)									// 17000 ~ 42°
	{
		mOldValue = mAdcBuffer;
	}

	return 30 + (80 * (mOldValue - mCalibre30)) / mCalibre80;
}
//-----------------------------------------------------------------------------
