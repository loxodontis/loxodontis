/*
 * This file is part of the FX-4CR-V2 project.
 * See: https://github.com/f5bud/FX-4CR-V2
 *
 * Copyright (c) 2024 Daniel Nespoulous, F5BUD
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE. 
 */
//-----------------------------------------------------------------------------
//	DdsSource.cpp
//-----------------------------------------------------------------------------
#include "DspSource.h"

//-----------------------------------------------------------------------------
class SinSource
{
public:
	static constexpr int16_t SIN_SIZE = 512;

	float32_t SinArray[SIN_SIZE];

	constexpr SinSource():SinArray()
	{
		for (int16_t i = 0; i < SIN_SIZE; i ++)
		{
			SinArray[i] = sinf(PI2_f32 * i / SIN_SIZE);
		}
	}
};

//-----------------------------------------------------------------------------
static constexpr SinSource sSinSource;

//-----------------------------------------------------------------------------
void DspSource::Init(int32_t freq)
{
	mFreq = freq;
}
//-----------------------------------------------------------------------------
Complex DspSource::getSin()
{
	float value = (mPhase * PI2_f32) / L96000;

	mPhase += mFreq;
	mPhase %= L96000;

	return Complex(fastSin(value), fastSin(value + PI1_f32));
}
//-----------------------------------------------------------------------------
Complex DspSource::getCos()
{
	float value = (mPhase * PI2_f32) / L96000;

	mPhase += mFreq;
	mPhase %= L96000;

	return Complex(fastSin(value + PI1_f32), fastSin(value));
}
//-----------------------------------------------------------------------------
float32_t DspSource::fastSin(float32_t value)
{
	value = value / PI2_f32;
	value = value - (int32_t) value;					// -1.0f ... 0.0f ... 1.0f

	float32_t findex = sSinSource.SIN_SIZE * value;
	uint16_t  index  = (uint16_t) findex;

	if (index >= sSinSource.SIN_SIZE - 1)
	{
		index  = 0;
		findex = findex - sSinSource.SIN_SIZE;
	}

	float32_t fract = findex - index;

	float32_t a = sSinSource.SinArray[index + 0];
	float32_t b = sSinSource.SinArray[index + 1];

	return a * (1.0f - fract) + b * fract;
}
//-----------------------------------------------------------------------------
