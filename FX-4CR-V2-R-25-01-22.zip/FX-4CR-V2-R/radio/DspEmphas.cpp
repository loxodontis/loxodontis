/*
 * This file is part of the FX-4CR-V2 project.
 * See: https://github.com/f5bud/FX-4CR-V2
 *
 * Copyright (c) 2024 Daniel Nespoulous, F5BUD
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
//-----------------------------------------------------------------------------
//	DspEmphas.cpp
//-----------------------------------------------------------------------------
#include "DspEmphas.h"

//-----------------------------------------------------------------------------
class Emphasis
{
public:
	static constexpr float32_t EMPHASIS = 50.0e-6f;								// 50 micro secondes

	float32_t Taps[2];

	constexpr Emphasis():Taps()
	{
		float32_t temp1 = 1.0f / L96000;
		float32_t temp2 = 2.0f * (temp1 / (2.0f * tanf(temp1 / (2.0f * EMPHASIS))));

		Taps[0] =            temp1 / (temp1 + temp2);
		Taps[1] = -(temp1 - temp2) / (temp1 + temp2);
	}
};

//-----------------------------------------------------------------------------
static constexpr Emphasis sEmphasis;

//-----------------------------------------------------------------------------
float32_t DspEmphas::Process(float32_t value)
{
	float32_t result = 
		sEmphasis.Taps[0] * value +
		sEmphasis.Taps[0] * mVals[0] +
		sEmphasis.Taps[1] * mVals[1];
	
	mVals[1] = result;
	mVals[0] = value;
	
	return result;
}
//-----------------------------------------------------------------------------
