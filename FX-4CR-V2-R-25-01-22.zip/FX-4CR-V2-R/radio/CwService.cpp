/*
 * This file is part of the FX-4CR-V2 project.
 * See: https://github.com/f5bud/FX-4CR-V2
 *
 * Copyright (c) 2024 Daniel Nespoulous, F5BUD
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
//-----------------------------------------------------------------------------
//	CwService.cpp
//-----------------------------------------------------------------------------
#include "CwService.h"
#include "Kernel.h"

//-----------------------------------------------------------------------------
typedef struct
{
	int16_t rxCode;		// 0b01 = space, 0b10 = dit, 0b11 = dah
	int16_t txCode;		// 0b01 = space, 0b10 = dit, 0b11 = dah
	char letter;
} CwCodeType;

//-----------------------------------------------------------------------------
// #define NOISE_TIME 20
#define MORSE_SIZE 49

CwCodeType sCwCodeList[MORSE_SIZE] =
{
	0b00'00'00'00'00'00'00'01, 0b00'00'00'00'00'00'00'01, ' ',	//
	0b00'00'00'00'00'00'10'11, 0b00'00'00'00'00'00'11'10, 'A',	// .-
	0b00'00'00'00'11'10'10'10, 0b00'00'00'00'10'10'10'11, 'B',	// -...
	0b00'00'00'00'11'10'11'10, 0b00'00'00'00'10'11'10'11, 'C',	// -.-.
	0b00'00'00'00'00'11'10'10, 0b00'00'00'00'00'10'10'11, 'D',	// -..
	0b00'00'00'00'00'00'00'10, 0b00'00'00'00'00'00'00'10, 'E',	// .
	0b00'00'00'00'10'10'11'10, 0b00'00'00'00'10'11'10'10, 'F',	// ..-.
	0b00'00'00'00'00'11'11'10, 0b00'00'00'00'00'10'11'11, 'G',	// --.
	0b00'00'00'00'10'10'10'10, 0b00'00'00'00'10'10'10'10, 'H',	// ....
	0b00'00'00'00'00'00'10'10, 0b00'00'00'00'00'00'10'10, 'I',	// ..
	0b00'00'00'00'10'11'11'11, 0b00'00'00'00'11'11'11'10, 'J',	// .---
	0b00'00'00'00'00'11'10'11, 0b00'00'00'00'00'11'10'11, 'K',	// -.-
	0b00'00'00'00'10'11'10'10, 0b00'00'00'00'10'10'11'10, 'L',	// .-..
	0b00'00'00'00'00'00'11'11, 0b00'00'00'00'00'00'11'11, 'M',	// --
	0b00'00'00'00'00'00'11'10, 0b00'00'00'00'00'00'10'11, 'N',	// -.
	0b00'00'00'00'00'11'11'11, 0b00'00'00'00'00'11'11'11, 'O',	// ---
	0b00'00'00'00'10'11'11'10, 0b00'00'00'00'10'11'11'10, 'P',	// .--.
	0b00'00'00'00'11'11'10'11, 0b00'00'00'00'11'10'11'11, 'Q',	// --.-
	0b00'00'00'00'00'10'11'10, 0b00'00'00'00'00'10'11'10, 'R',	// .-.
	0b00'00'00'00'00'10'10'10, 0b00'00'00'00'00'10'10'10, 'S',	// ...
	0b00'00'00'00'00'00'00'11, 0b00'00'00'00'00'00'00'11, 'T',	// -
	0b00'00'00'00'00'10'10'11, 0b00'00'00'00'00'11'10'10, 'U',	// ..-
	0b00'00'00'00'10'10'10'11, 0b00'00'00'00'11'10'10'10, 'V',	// ...-
	0b00'00'00'00'00'10'11'11, 0b00'00'00'00'00'11'11'10, 'W',	// .--
	0b00'00'00'00'11'10'10'11, 0b00'00'00'00'11'10'10'11, 'X',	// -..-
	0b00'00'00'00'11'10'11'11, 0b00'00'00'00'11'11'10'11, 'Y',	// -.--
	0b00'00'00'00'11'11'10'10, 0b00'00'00'00'10'10'11'11, 'Z',	// --..
	0b00'00'00'11'11'11'11'11, 0b00'00'00'11'11'11'11'11, '0',	// -----
	0b00'00'00'10'11'11'11'11, 0b00'00'00'11'11'11'11'10, '1',	// .----
	0b00'00'00'10'10'11'11'11, 0b00'00'00'11'11'11'10'10, '2',	// ..---
	0b00'00'00'10'10'10'11'11, 0b00'00'00'11'11'10'10'10, '3',	// ...--
	0b00'00'00'10'10'10'10'11, 0b00'00'00'11'10'10'10'10, '4',	// ....-
	0b00'00'00'10'10'10'10'10, 0b00'00'00'10'10'10'10'10, '5',	// .....
	0b00'00'00'11'10'10'10'10, 0b00'00'00'10'10'10'10'11, '6',	// -....
	0b00'00'00'11'11'10'10'10, 0b00'00'00'10'10'10'11'11, '7',	// --...
	0b00'00'00'11'11'11'10'10, 0b00'00'00'10'10'11'11'11, '8',	// ---..
	0b00'00'00'11'11'11'11'10, 0b00'00'00'10'11'11'11'11, '9',	// ----.
	0b00'00'11'10'11'10'11'11, 0b00'00'11'11'10'11'10'11, '!',	// -.-.--
	0b00'00'00'11'10'11'11'10, 0b00'00'00'10'11'11'10'11, '(',	// -.--.
	0b00'00'11'10'11'11'10'11, 0b00'00'11'10'11'11'10'11, ')',	// -.--.-
	0b00'00'00'10'11'10'11'10, 0b00'00'00'10'11'10'11'10, '+',	// .-.-.
	0b00'00'11'11'10'10'11'11, 0b00'00'11'11'10'10'11'11, ',',	// --..--
	0b00'00'11'10'10'10'10'11, 0b00'00'11'10'10'10'10'11, '-',	// -....-
	0b00'00'10'11'10'11'10'11, 0b00'00'11'10'11'10'11'10, '.',	// .-.-.-
	0b00'00'00'11'10'10'11'10, 0b00'00'00'10'11'10'10'11, '/',	// -..-.
	0b00'00'11'11'11'10'10'10, 0b00'00'10'10'10'11'11'11, ':',	// ---...
	0b00'00'00'11'10'10'10'11, 0b00'00'00'11'10'10'10'11, '=',	// -...-
	0b00'00'10'10'11'11'10'10, 0b00'00'10'10'11'11'10'10, '?',	// ..--..
	0b00'00'10'11'11'10'11'10, 0b00'00'10'11'10'11'11'10, '@'	// .--.-.
};

//-----------------------------------------------------------------------------
int16_t CwService::findTxCode(char letter)
{
	for (int16_t i = 0; i < MORSE_SIZE; i ++)
	{
		if (sCwCodeList[i].letter == letter)
		{
			return sCwCodeList[i].txCode;
		}
	}

	return 0;
}
//-----------------------------------------------------------------------------
char CwService::findRxLetter(int16_t code)
{
	for (int16_t i = 0; i < MORSE_SIZE; i ++)
	{
		if (sCwCodeList[i].rxCode == code)
		{
			return sCwCodeList[i].letter;
		}
	}

	return '#';
}
//-----------------------------------------------------------------------------
void CwService::Correction(bool all)
{
	if (mEditTemp)
	{
		int16_t size = std::max((size_t) 0, strlen(mEditTemp) - 1);

		if (all) size = 0;
		mEditTemp[size] = '\0';
	}
}
//-----------------------------------------------------------------------------
void CwService::AddTemp(char value)
{
	if (mEditTemp)
	{
		int16_t size = strlen(mEditTemp);

		if (size < mEditSize)
		{
			mEditTemp[size + 0] = value;
			mEditTemp[size + 1] = '\0';
		}
	}
}
//-----------------------------------------------------------------------------
void CwService::setEditTemp(char *value, int16_t size)
{
	mEditTemp = value;
	mEditSize = size;
}
//-----------------------------------------------------------------------------
//	Encode part
//-----------------------------------------------------------------------------
void CwService::setTxMessage(char *value)
{
	for (int16_t i = strlen(value); i > 0; i --)
	{
		if (value[i] != ' ') break;

		value[i] = '\0';
	}

	mTxMessage = " ";
	mTxMessage.append(value);											// space before for timing
}
//-----------------------------------------------------------------------------
void CwService::Stop()
{
	mTxMessage = "";
}
//-----------------------------------------------------------------------------
bool CwService::isTxMessage()
{
	return (mTxCode || mTxMessage.length());
}
//-----------------------------------------------------------------------------
int16_t CwService::getNext()
{
	if (mTxCode)
	{
		mTxCode >>= 2;
		return mTxCode;
	}

	if (mTxMessage.length())
	{
		mTxCode = findTxCode(mTxMessage[0]);
		mTxMessage.erase(0, 1);
	}

	return mTxCode;
}
//-----------------------------------------------------------------------------
//	Decode part
//-----------------------------------------------------------------------------
void CwService::Reset(int32_t delay)
{
	if (mDitAvgTime != delay)
	{
		mDitAvgTime = delay;

		mLastStateReal = false;
		mLastStateFilt = false;
//		mLastStateTime = 0;

		mHiStartTime = 0;
		mLoStartTime = 0;

		mDitAvgTime = delay;
		mDahAvgTime = mDitAvgTime * 2;
		mBrkAvgTime = mDitAvgTime;

		mRxCode = 0b00;
	}
}
//-----------------------------------------------------------------------------
void CwService::CheckCode(float duration)
{
	if (mRxCode)
	{
		if (duration > mBrkAvgTime * 2.5f)
		{
			AddTemp(findRxLetter(mRxCode));

			mRxCode = 0b00;
			mSpace  = true;
		}
	}

	if (mSpace)
	{
		if (duration > mBrkAvgTime * 5.0f)
		{
			AddTemp(' ');

			mSpace = false;
		}
	}
}
//-----------------------------------------------------------------------------
void CwService::Process(bool newState)
{
	int32_t currentTime = Scheduler::GetTick();
/*
	if (mLastStateReal != newState)
	{
		mLastStateReal = newState;
		mLastStateTime = currentTime;
	}

	if ((currentTime - mLastStateTime) < NOISE_TIME)
		newState = mLastStateFilt;
*/
	if (mLastStateFilt != newState)
	{
		mLastStateFilt = newState;

		if (newState)	// signal is HI
		{
			float duration = currentTime - mLoStartTime;

			CheckCode(duration);

			if (duration > 20.0f)
			{
				if ((duration < mDitAvgTime * 1.5f) && (duration > mDitAvgTime * 0.6f))
				{
					mBrkAvgTime += (duration - mBrkAvgTime) / 4.0f;
				}
			}

			mHiStartTime = currentTime;
		}
		else	// signal is LO
		{
			float duration = currentTime - mHiStartTime;
			float middle   = (mDitAvgTime + mDahAvgTime) / 2.0f;

			if		((duration < middle) && (duration > mDitAvgTime * 0.5f))
			{
				mRxCode = (mRxCode << 2) | 0b10;									// Dit code
			}
			else if ((duration > middle) && (duration < mDahAvgTime * 3.0f))
			{
				mRxCode = (mRxCode << 2) | 0b11;									// Dah code
			}

			if ((duration > 20.0f) && (duration < mDahAvgTime * 0.4f))
			{
				mDitAvgTime += (duration - mDitAvgTime) / 4.0;
			}

			if ((duration < 500.0f) && (duration > mDitAvgTime * 2.5f))
			{
				mDahAvgTime += (duration - mDahAvgTime) / 4.0f;
			}

			mLoStartTime = currentTime;
		}
	}

	if (newState == false)
	{
		CheckCode(currentTime - mLoStartTime);
	}
}
//-----------------------------------------------------------------------------
