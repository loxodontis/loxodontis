/*
 * This file is part of the FX-4CR-V2 project.
 * See: https://github.com/f5bud/FX-4CR-V2
 *
 * Copyright (c) 2024 Daniel Nespoulous, F5BUD
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
//-----------------------------------------------------------------------------
//	AgcFunc.cpp
//-----------------------------------------------------------------------------
#include "AgcFunc.h"

//-----------------------------------------------------------------------------
#define AGC_FAST 10

static const int32_t sAgcDelay[] = { 200, 600, 900 };

//-----------------------------------------------------------------------------
void AgcFunc::Init(float32_t threshold, float32_t min, float32_t max)
{
	mCurAgc = (eAgcType) -1;

	mThreshold = threshold;

	mGainMin = min;
	mGainMax = max;

	mSmoothUp.setStep(sAgcDelay[0]);												// to prevent zero division
	mSmoothDn.setStep(AGC_FAST);

	mPeak = 0;
}
//-----------------------------------------------------------------------------
void AgcFunc::setAgcSpeed(eAgcType value)
{
	mCurAgc = value;
}
//-----------------------------------------------------------------------------
float32_t AgcFunc::getAgc(float32_t peak, float32_t gain)
{
	mPeak = peak;

	if (peak > mThreshold)
	{
		float32_t coef = (mThreshold - peak) / (float32_t) mThreshold;

		mSmoothUp.setStep(sAgcDelay[mCurAgc]);									// reset decay
		gain = mSmoothDn.incStep(gain, 1.0f / (1.0f - coef));
	}
	else
	{
		float32_t coef = (peak - mThreshold) / (float32_t) mThreshold;

		mSmoothDn.setStep(AGC_FAST);											// reset attack
		gain = mSmoothUp.incStep(gain, 1.0f - coef);
	}

	return std::max(mGainMin, std::min(mGainMax, gain));
}
//-----------------------------------------------------------------------------
float32_t AgcFunc::getPeak()
{
	return mPeak;
}
//-----------------------------------------------------------------------------
