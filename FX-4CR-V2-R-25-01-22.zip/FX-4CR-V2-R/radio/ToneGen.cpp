/*
 * This file is part of the FX-4CR-V2 project.
 * See: https://github.com/f5bud/FX-4CR-V2
 *
 * Copyright (c) 2024 Daniel Nespoulous, F5BUD
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE. 
 */
//-----------------------------------------------------------------------------
//	ToneGen.cpp
//-----------------------------------------------------------------------------
#include "ToneGen.h"
#include "DacBase.h"
#include "DmaBase.h"
#include "TimerBase.h"

//-----------------------------------------------------------------------------
#define SINE_SIZE	64
static DMAMEM uint16_t sSinWave[SINE_SIZE];

//-----------------------------------------------------------------------------
void ToneGen::Init()
{
	DacBase().Init(DAC1);
	DmaBase().Init(DMA1);
	TimerBase().Init(TIM6);

	setEnabled(false);

	GpioPin(GPIOA, 4, eAnaMode, ePushPull, eLowSpeed, ePullNone, 0); 			// A4 DAC channel1 Tone generator

// Dma
	DMAMUX1_Channel5->CCR = 67UL;												// Channel(n) = Stream(n) dac_ch1_dma

	DMA1_Stream5->CR = 0UL;
	DMA1_Stream5->FCR = 0UL;

	MODIFY_REG(DMA1_Stream5->CR, DMA_SxCR_MSIZE, 1UL << DMA_SxCR_MSIZE_Pos);	// Memory data: 01: Half-word (16-bit)
	MODIFY_REG(DMA1_Stream5->CR, DMA_SxCR_PSIZE, 1UL << DMA_SxCR_PSIZE_Pos);	// Peripheral data: 01: Half-word (16-bit)
	MODIFY_REG(DMA1_Stream5->CR, DMA_SxCR_DIR,   1UL << DMA_SxCR_DIR_Pos);		// Transfer direction: 01: Memory-to-peripheral

	SET_BIT(DMA1_Stream5->CR, DMA_SxCR_MINC);									// 1: Memory increment
	SET_BIT(DMA1_Stream5->CR, DMA_SxCR_CIRC);									// 1: Circular mode enabled

	DMA1_Stream5->M0AR = (uint32_t) &sSinWave;
	DMA1_Stream5->PAR  = (uint32_t) &DAC1->DHR12R1;
	DMA1_Stream5->NDTR = SINE_SIZE;

	SET_BIT(DMA1_Stream5->CR, DMA_SxCR_EN);

// Timer
	TIM6->CR1 = 0UL;
	TIM6->CR2 = 0UL;
	TIM6->PSC = 0UL;

	MODIFY_REG(TIM6->CR2, TIM_CR2_MMS, 2UL << TIM_CR2_MMS_Pos);					// 010: Update - The update event is selected as trigger output (TRGO)

// Dac
	MODIFY_REG(DAC1->CR,  DAC_CR_TSEL1,  5UL << DAC_CR_TSEL1_Pos);				// dac_chx_trg5 tim6_trgo

	SET_BIT(DAC1->CR, DAC_CR_DMAEN1);											// 1: DAC channel1 DMA mode enabled
	SET_BIT(DAC1->CR, DAC_CR_TEN1);												// 1: DAC channel1 trigger enabled
	SET_BIT(DAC1->CR, DAC_CR_EN1);												// 1: DAC channel1 enabled
}
//-----------------------------------------------------------------------------
void ToneGen::setCwPitch(int16_t value)
{
	if (value > 0)
	{
		TIM6->ARR = PCLK1 / (value * SINE_SIZE);								// (PCLK1 / (value * SINE_SIZE)) - 1;
		SET_BIT(TIM6->CR1, TIM_CR1_CEN);										// 1: Counter enabled
	}
	else
	{
		CLEAR_BIT(TIM6->CR1, TIM_CR1_CEN);										// 0: Counter disabled
	}
}
//-----------------------------------------------------------------------------
void ToneGen::setCwAudio(int16_t value)											// 0, 1 - 63 (0 = mute);
{
	if (mCwSpeaker != value)
	{
		mCwSpeaker = value;
	}
}
//-----------------------------------------------------------------------------
void ToneGen::setEnabled(bool flag)
{
	int16_t value = flag ? mCwSpeaker : 0;

	for (int16_t i = 0; i < SINE_SIZE; i ++)
	{
		float32_t wave = sinf((i * PI2_f32) / SINE_SIZE) * 75.0f;

		sSinWave[i] = 2048 + static_cast<int16_t>(wave) * value;
	}
}
//-----------------------------------------------------------------------------
