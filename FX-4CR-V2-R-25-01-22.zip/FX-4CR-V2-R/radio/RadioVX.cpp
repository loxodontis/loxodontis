/*
 * This file is part of the FX-4CR-V2 project.
 * See: https://github.com/f5bud/FX-4CR-V2
 *
 * Copyright (c) 2024 Daniel Nespoulous, F5BUD
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
//-----------------------------------------------------------------------------
//	RadioVx.cpp
//-----------------------------------------------------------------------------
#include "RadioVX.h"
#include "Format.h"

//-----------------------------------------------------------------------------
extern VoiceType VoiceFlash;													// audio player and recorder

static const char sFormat[] = "%3.2f / %3.2f second(s)";

//-----------------------------------------------------------------------------
void RadioVX::Init(const ParamType &param, SignalBase *signal)
{
	mThreshold = 0.4f;
	mInputType = param.InputType;

	mLoPassMF.InitLoPass(param.Filter);

	switch (mInputType)
	{
	case eVxMonitor:
	case eVxPlayer:
		memcpy(mVoiceType.buffer, VoiceFlash.buffer, sizeof(VoiceType));
		break;

	default:																	// eVxRecord
		mVoiceType.Writer = 0L;
		mVoiceType.Reader = 0L;
		break;
	}
}
//-----------------------------------------------------------------------------
void RadioVX::Finish(Thread &thread)
{
	if (mInputType == eVxRecord)
	{
		uint32_t *dst = VoiceFlash.buffer;
		uint32_t *src = mVoiceType.buffer;

		mProgress = "Erasing ...";
		thread.Delay(500L);

		Unlock();
		Erase(2UL, thread);														// 0x08040000
	//	Erase(3UL, thread);														// 0x08060000

		mVoiceType.Writer = std::max(mVoiceType.Writer - 1000L, 0L);			// (1000 = 170ms) noise at end

		for (int32_t i = 0; i <= mVoiceType.Writer; i += 8)
		{
			mProgress = Format().Fmt("Write in progress: %d%%", (i * 100L) / mVoiceType.Writer);

			Write256(dst, src, thread);

			dst += 8; src += 8;
		}

		Lock(thread);
	}

	mInputType = eRxIQ;
	mProgress  = Format().Fmt(sFormat, (VoiceFlash.Writer / 6000.0f), (VOICE_SIZE / 6000.0f)).c_str();
}
//-----------------------------------------------------------------------------
std::string RadioVX::getProgress()
{
	return mProgress;
}
//-----------------------------------------------------------------------------
bool RadioVX::getVoicePtt()
{
	return mInputType != eRxIQ;
}
//-----------------------------------------------------------------------------
void RadioVX::setVoicePtt()
{
	mInputType = eVxPlayer;
}
//-----------------------------------------------------------------------------
void RadioVX::NewData(Complex *AdcBuff, Complex *DacBuff)
{
	switch (mInputType)
	{
	case eVxRecord:
		Record(AdcBuff, DacBuff);
		break;

	default:
		Monitor(AdcBuff, DacBuff);
		break;
	}
}
//-----------------------------------------------------------------------------
void RadioVX::Record(Complex *AdcBuff, Complex *DacBuff)
{
	if (mVoiceType.Writer < VOICE_SIZE)
	{
		int16_t index = 0;

		for (int16_t i = 0; i < SAMPLE_SIZE / 16; i ++)
		{
			float32_t adc;

			for (int16_t k = 0; k < 16; k ++)									// decimate by 16, fc = 6kHz
			{
				adc = mLoPassMF.Process(AdcBuff[index ++].imag());				// imag = left channel mic or aux
			}

			mVoiceType.Wave[mVoiceType.Writer ++] = FloatToInt8(adc);

			if (std::abs(adc) < mThreshold)										// wait start of parole
			{
				if (mVoiceType.Writer > 20L) mVoiceType.Writer = 0L;

				continue;
			}

			mThreshold = 0.0f;
		}
	}

	mProgress = Format().Fmt(sFormat, (mVoiceType.Writer / 6000.0f), (VOICE_SIZE / 6000.0f)).c_str();
}
//-----------------------------------------------------------------------------
void RadioVX::Monitor(Complex *AdcBuff, Complex *DacBuff)
{
	if (mVoiceType.Reader < mVoiceType.Writer)
	{
		int16_t index = 0;

		for (int16_t i = 0; i < SAMPLE_SIZE / 16; i ++)
		{
			float32_t adc = Int8ToFloat(mVoiceType.Wave[mVoiceType.Reader ++]);

			for (int16_t k = 0; k < 16; k ++)
			{
				DacBuff[index ++].imag(adc);									// imag = left channel mic or aux
			}
		}

		for (int16_t i = 0; i < SAMPLE_SIZE; i ++)
		{
			float32_t adc = mLoPassMF.Process(DacBuff[i].imag());

			AdcBuff[i].imag(adc * 2.5f);										// imag = left channel mic or aux
			DacBuff[i].real(adc * 0.3f);
			DacBuff[i].imag(adc * 0.3f);
		}
	}
	else
		mInputType = eRxIQ;

	mProgress = Format().Fmt(sFormat, (mVoiceType.Reader / 6000.0f), (mVoiceType.Writer / 6000.0f)).c_str();
}
//-----------------------------------------------------------------------------
