/*
 * This file is part of the FX-4CR-V2 project.
 * See: https://github.com/f5bud/FX-4CR-V2
 *
 * Copyright (c) 2024 Daniel Nespoulous, F5BUD
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
//-----------------------------------------------------------------------------
//	RadioRX.cpp
//-----------------------------------------------------------------------------
#include "RadioRX.h"
#include "DacBase.h"

//-----------------------------------------------------------------------------
void RadioRX::Init(const ParamType &param, SignalBase *signal)
{
	DacBase().Init(DAC1);

	GpioPin(GPIOA, 5, eAnaMode, ePushPull, eLowSpeed, ePullNone, 0);			// A5 DAC channel2 AD-605 gain

	MODIFY_REG(DAC1->MCR, DAC_MCR_MODE2, 4UL << DAC_MCR_MODE2_Pos);				// 4: DAC channel2 is connected to external pin with Buffer enabled

	SET_BIT(DAC1->CR, DAC_CR_EN2);												// 1: DAC channel2 enabled

	mDspFft  .Init();
	mDspNotch.Init();
	mCircular.Init();

	mAdcAgcFunc.Init(0.02f, 0.50f,   2.5f);										// -10db, 30db mAdcGain in volt AD605
	mDacAgcFunc.Init(0.49f, 1.00f, 500.0f);										// 0.0db, 54db mDacGain in factor !!!

	mQuietCnt = 32 * SAMPLE_SIZE;												// 32 * 5.3 = 162ms

	mSignal = signal;
	mSignal->Init();
}
//-----------------------------------------------------------------------------
DspFft *RadioRX::getDspFft()
{
	return &mDspFft;
}
//-----------------------------------------------------------------------------
/*
#include "Format.h"
float32_t xAdc;
float32_t xDac;
*/
void RadioRX::Update(const ParamType &param)
{
	mIqMag =  1000.0f / param.SetBand.RxMag;
	mIqPha = (1000.0f - param.SetBand.RxPha) / 1000.0f;

	mAdcAgcFunc.setAgcSpeed(param.AgcSpeed);
	mDacAgcFunc.setAgcSpeed(param.AgcSpeed);

	if (param.Muted)
		mQuietCnt = 48 * SAMPLE_SIZE;

	mDspNotch.setNotch(param.DspStatus);
//	mDspNoise.setLatency  (param.DspValue);

	mSignal->Update(param);

//	puts(Format().Fmt("Adc: (%8.6f):(%8.6f), Dac: (%8.6f):(%8.6f)", xAdc, mAdcGain, xDac, mDacGain).c_str());
}
//-----------------------------------------------------------------------------
void RadioRX::NewData(Complex *AdcBuff, Complex *DacBuff)
{
	float32_t adcPeak = 0.0f;
	float32_t dacPeak = 0.0f;

	for (int16_t i = 0; i < SAMPLE_SIZE; i ++)
	{
		Complex adc = AdcBuff[i].balance(mIqPha, mIqMag);

		adcPeak = std::max(adcPeak, adc.mag());									// Agc ADC over the entire range

		mDspFft.Process(adc);

		float32_t dac = mDspNotch.Process(mSignal->ProcessRx(adc));				// SSB, AM, FM, ...

		dacPeak = std::max(dacPeak, fabsf(dac * mDacGain));						// peak of samples, Agc DAC over the audio range

		dac = mCircular.PushPop(dac) * mDacGain;								// delayed signal for AGC

		if (mQuietCnt)
		{
			mQuietCnt --;
			continue;
		}

		DacBuff[i].real(dac);
		DacBuff[i].imag(dac);
	}

	mAdcGain = mAdcAgcFunc.getAgc(adcPeak, mAdcGain);
	mDacGain = mDacAgcFunc.getAgc(dacPeak, mDacGain);
/*
	xAdc = adcPeak;
	xDac = dacPeak;

	mAdcGain = 0.20f;															// used to determine max DAC values
	mDacGain = 500.0f;

	mAdcGain = 31.62f;															// used to determine max ADC values
	mDacGain = 1.0f;
*/
	setAd605();
}
//-----------------------------------------------------------------------------
float32_t RadioRX::getAd605()
{
	return (mAdcGain - 1.0f) * 20.0f;											//  2.0v / 40.0db
}
//-----------------------------------------------------------------------------
void RadioRX::setAd605()
{
	DAC1->DHR12R2 = mAdcGain * 4095.0f / 2.5f;									// STM32H7 vRef = 2.5V
}
//-----------------------------------------------------------------------------
