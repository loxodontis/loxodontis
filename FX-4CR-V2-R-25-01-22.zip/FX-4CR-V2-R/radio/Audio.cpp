/*
 * This file is part of the FX-4CR-V2 project.
 * See: https://github.com/f5bud/FX-4CR-V2
 *
 * Copyright (c) 2024 Daniel Nespoulous, F5BUD
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
//-----------------------------------------------------------------------------
//	Audio.cpp
//-----------------------------------------------------------------------------
#include "Audio.h"

//-----------------------------------------------------------------------------
static const int16_t sSpeakerList[] =
{
	 0,																	// db to linear (AF audio)
	14, 23, 29, 33, 37, 40, 43, 45, 48, 50,
	51, 53, 55, 56, 57, 59, 60, 61, 62, 63
};

static const int16_t sHeadSetList[] =
{
	  0,
	  2,  3,  5,  6,  8,  9, 11, 12, 14, 15,
	 17, 18, 20, 21, 23, 24, 26, 27, 29, 30
};
//-----------------------------------------------------------------------------
void Audio::Init(Thread &thread)
{
	SPIBanging::Init();

	mInputType = (eInputType) -1;

	mHeadSetGain = -1;
	mSpeakerGain = -1;

	Write(0,  0b0'0000'0000);										// Reset of Wm8978
	thread.Delay(100);

	Write( 1, 0b1'1101'1111);										// Power manage’t 1: BUFDCOP, OUT4MIX, OUT3MIX, MICBEN, BUFIOEN, VMIDSEL = 11
	Write( 2, 0b1'1011'1111);										// Power manage’t 2: ROUT1EN, LOUT1EN, BOOSTR, BOOSTL, INPPGAENR, INPPGAENL, ADCENR, ADCENL
	Write( 3, 0b1'1110'1111);										// Power manage’t 3: OUT4EN, OUT3EN, LOUT2EN,  ROUT2EN, RMIXEN, LMIXEN, DACENR, DACENL

//	Write( 4, 0b0'0101'0000); 										// Audio Interface: WL = 24 bits, FMT = I2S format
	Write( 4, 0b0'0111'0000); 										// Audio Interface: WL = 32 bits, FMT = I2S format
	Write( 6, 0b0'0000'0000);										// CLKSEL: MCLK, MCLKDIV: divide by 1

	Write(10, 0b0'0000'1000);										// DACOSR 128
	Write(11, 0b1'1111'1111);										// DACVOLL gain: 0db
	Write(12, 0b1'1111'1111);										// DACVOLR gain: 0db

	Write(14, 0b0'0000'1011);										// ADCOSR 128
	Write(15, 0b1'1111'1111);										// ADCVOLL gain: 0db
	Write(16, 0b1'1111'1111);										// ADCVOLR gain: 0db

	Write(25, 0b0'0101'0000);										// LIMLVL: -6db, LIMBOOST: 0dB
/*
	Write(33, 0b0'0000'1011);										// ALCHLD: 0ms, ALCLVL: -6dbfs (ref)
	Write(34, 0b0'0100'0010);										// ALC: on, ALCDCY: 0.384s, ALCATK: 0.024s
*/
	Write(43, 0b0'0001'0000);										// INVROUT2 (for SideTone)
	Write(44, 0b0'0000'0011);										// (mic) LIN2INPPGA: on, LIP2INPPGA: on

	Write(49, 0b0'0000'0110);										// SPK BOOST, TSDEN

	SpeakerGain(0);
	HeadSetGain(0);
}
//-----------------------------------------------------------------------------
void Audio::finalMute()
{
	Write( 3, 0b0'0000'1111);										// Power manage’t 3: OUT4EN: off, OUT3EN: off, LOUT2EN: off,  ROUT2EN: off
}
//-----------------------------------------------------------------------------
void Audio::Input(const ParamType &param)
{
	if (mInputType != param.InputType)
	{
		mInputType = param.InputType;

		switch(mInputType)					// (switch ADC inputs)
		{
		case eRxIQ:
//			Write(32, 0b0'0000'0000);								// ALCSEL: off, ALCMAXGAIN: -6.75db, ALCMINGAIN: -12db

			Write(45, 0b0'1100'0000);								// INPPGAMUTEL: mute, INPPGAVOLL: -12db
			Write(46, 0b1'1100'0000);								// INPPGAMUTER: mute, INPPGAVOLR: -12db

			Write(47, 0b0'0101'0000);								// PGABOOSTL: 0db, (I) L2_2BOOSTVOL: 0db, (Digi) AUXL2BOOSTVOL: mute
			Write(48, 0b0'0101'0000);								// PGABOOSTR: 0db, (Q) R2_2BOOSTVOR: 0db, (none) AUXR2BOOSTVOR: mute
			break;

		case eTxMic:
		case eVxRecord:
//			Write(32, 0b1'0010'1010);								// ALCSEL: L, ALCMAXGAIN: +11.25db, ALCMINGAIN: 0db

			Write(45, 0b0'1001'0000);								// INPPGAMUTEL: on,   INPPGAVOLL:   0db
			Write(46, 0b1'1100'0000);								// INPPGAMUTER: mute, INPPGAVOLR: -12db

			Write(47, 0b0'0000'0000);								// PGABOOSTL: 0db, (I) L2_2BOOSTVOL: mute, (DIGI) AUXL2BOOSTVOL: mute
			Write(48, 0b0'0000'0000);								// PGABOOSTR: 0db, (Q) R2_2BOOSTVOR: mute, (none) AUXR2BOOSTVOR: mute
			break;

		case eTxAux:
//			Write(32, 0b0'0000'0000);								// ALCSEL: off, ALCMAXGAIN: -6.75db, ALCMINGAIN: -12db

			Write(47, 0b0'0000'0101);								// PGABOOSTL: 0db, (I) L2_2BOOSTVOL: mute, (DIGI) AUXL2BOOSTVOL: 0db
			Write(48, 0b0'0000'0000);								// PGABOOSTR: 0db, (Q) R2_2BOOSTVOR: mute, (none) AUXR2BOOSTVOR: mute
			break;

		default:
			break;
		}

		switch(mInputType)					// (switch DAC outputs)
		{
		case eRxIQ:
		case eVxMonitor:
			Write(50, 0b0'0000'0001);								// DACL2LMIX: enable
			Write(51, 0b1'1110'0001);								// DACR2RMIX: enable, AUXRMIXVOL: +6db, AUXR2RMIX: enable

			Write(56, 0b0'0100'0001);								// OUT3MUTE: mute, LDAC2OUT3: enable
			Write(57, 0b0'0100'0001);								// OUT4MUTE: mute, RDAC2OUT4: enable
			break;

		case eTxNone:
			Write(50, 0b0'0000'0000);								// DACL2LMIX: mute
			Write(51, 0b1'1110'0000);								// DACR2RMIX: mute, AUXRMIXVOL: +6db, AUXR2RMIX: enable

			Write(56, 0b0'0100'0001);								// OUT3MUTE: mute, LDAC2OUT3: enable
			Write(57, 0b0'0100'0001);								// OUT4MUTE: mute, RDAC2OUT4: enable
			break;

		default:
			Write(50, 0b0'0000'0000);								// DACL2LMIX: mute
			Write(51, 0b1'1110'0000);								// DACR2RMIX: mute, AUXRMIXVOL: +6db, AUXR2RMIX: enable

			Write(56, 0b0'0000'0001);								// OUT3MUTE: enable, LDAC2OUT3: enable
			Write(57, 0b0'0000'0001);								// OUT4MUTE: enable, RDAC2OUT4: enable
			break;
		}
	}

	HeadSetGain(param.DacAux);										// Aux level, usb & bt
	SpeakerGain(param.Speaker);										// Speaker & headset
}
//-----------------------------------------------------------------------------
void Audio::HeadSetGain(int16_t value)									// 0 = mute, (1, 64) -> (-57dB, +6dB) 1dB steps
{
	if (mHeadSetGain != value)
	{
		mHeadSetGain = value;

		if (value > 0)
		{
			value = sHeadSetList[value];

			Write(52, 0b0'0000'0000 | value);							// LOUT1VOL, -57db ... +6db
			Write(53, 0b1'0000'0000 | value);							// ROUT1VOL, -57db ... +6db
		}
		else
		{
			Write(52, 0b0'0100'0000);
			Write(53, 0b1'0100'0000);
		}
	}
}
//-----------------------------------------------------------------------------
void Audio::SpeakerGain(int16_t value)									// 0 = mute, 1 - 64 -> -57dB - +6dB 1dB steps
{
	if (mSpeakerGain != value)
	{
		mSpeakerGain = value;

		if (value > 0)
		{
			value = sSpeakerList[value];

			Write(54, 0b0'0000'0000 | value);							// LOUT2VOL, -57db ... +6db
			Write(55, 0b1'0000'0000 | value);							// ROUT2VOL, -57db ... +6db
		}
		else
		{
			Write(54, 0b0'0100'0000);
			Write(55, 0b1'0100'0000);
		}
	}
}
//-----------------------------------------------------------------------------
