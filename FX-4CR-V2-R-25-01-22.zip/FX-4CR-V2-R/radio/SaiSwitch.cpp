/*
 * This file is part of the FX-4CR-V2 project.
 * See: https://github.com/f5bud/FX-4CR-V2
 *
 * Copyright (c) 2024 Daniel Nespoulous, F5BUD
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE. 
 */
//-----------------------------------------------------------------------------
//	SaiSwitch.cpp
//-----------------------------------------------------------------------------
#include "SaiSwitch.h"

//-----------------------------------------------------------------------------
static RadioRX sRadioRX;
static RadioTX sRadioTX;
static RadioVX sRadioVX;

static SignalCW  sSignalCW;
static SignalLSB sSignalLSB;
static SignalUSB sSignalUSB;
static SignalAM  sSignalAM;
static SignalFM  sSignalFM;

//-----------------------------------------------------------------------------
static SignalBase *sSignalList[7] =
{
	&sSignalCW, &sSignalLSB, &sSignalUSB, &sSignalAM, &sSignalFM, &sSignalLSB, &sSignalUSB
};

//-----------------------------------------------------------------------------
void SaiSwitch::Init(Thread &thread)
{
	mThread	 = &thread;

	mRadioRX  = nullptr;
	mRadioTX  = nullptr;
	mRadioVX  = nullptr;
	mQuietCnt = 30;																// 30 * 5.33 ms

	SaiService::Init();
	mAudio.Init(thread);

	mHiPassMF.Clear();
	mHiPassMF.InitHiPass(50L);
}
//-----------------------------------------------------------------------------
void SaiSwitch::stopSignal()
{
	mRadioRX  = nullptr;
	mRadioTX  = nullptr;
	mRadioVX  = nullptr;
	mQuietCnt = 30;																// 30 * 5.33 ms

	sRadioVX.Finish(*mThread);													// finish and fill mProgress
}
//-----------------------------------------------------------------------------
void SaiSwitch::FinalMute()
{
	mAudio.finalMute();
}
//-----------------------------------------------------------------------------
std::string SaiSwitch::getProgress()
{
	return sRadioVX.getProgress();
}
//-----------------------------------------------------------------------------
bool SaiSwitch::getVoicePtt()
{
	return sRadioVX.getVoicePtt();
}
//-----------------------------------------------------------------------------
void SaiSwitch::setVoicePtt()
{
	sRadioVX.setVoicePtt();
}
//-----------------------------------------------------------------------------
void SaiSwitch::setAdcGain(const ParamType &param)
{
	switch(param.InputType)
	{
	case eRxIQ:
		mAdcGain = 1.0f;
		break;

	case eTxMic:
	case eVxRecord:
		mAdcGain = param.AdcMic;
	break;

	case eTxAux:
		mAdcGain = param.AdcAux;
		break;

	case eTxKey:																// no gain but start immediately
		mQuietCnt = 0;
	//	continue
	default:								// eTxNone, eTxKey, eVxMonitor, eVxPlayer
		mAdcGain = 0.0f;
		break;
	}
}
//-----------------------------------------------------------------------------
void SaiSwitch::setRecept(const ParamType &param)
{
	if (mRadioRX == nullptr)
	{
		setAdcGain(param);
		mAudio.Input(param);

		sRadioRX.Init(param, sSignalList[param.Mode]);
		mRadioRX = &sRadioRX;
	}

	mAudio.Input(param);
	mRadioRX->Update(param);
}
//-----------------------------------------------------------------------------
void SaiSwitch::setTransmit(const ParamType &param)
{
	if (param.InputType == eVxPlayer)
	{
		setVoice(param);
	}

	if (mRadioTX == nullptr)
	{
		setAdcGain(param);
		mAudio.Input(param);

		sRadioTX.Init(param, sSignalList[param.Mode]);
		mRadioTX = &sRadioTX;
	}

	mAudio.Input(param);
	mRadioTX->Update(param);
}
//-----------------------------------------------------------------------------
void SaiSwitch::setVoice(const ParamType &param)
{
	if (mRadioVX == nullptr)
	{
		setAdcGain(param);
		mAudio.Input(param);

		sRadioVX.Init(param, nullptr);
		mRadioVX = &sRadioVX;
	}

	mAudio.Input(param);
}
//-----------------------------------------------------------------------------
void SaiSwitch::SaiData(int32_t *AdcBuff, int32_t *DacBuff)						// 512 / 96000 = 5.33 ms
{
	for (int16_t i = 0; i < SAMPLE_SIZE; i ++)
	{
		float32_t adc1 = Int24ToFloat(*(AdcBuff ++)) * mAdcGain;				// right = Q
		float32_t adc2 = Int24ToFloat(*(AdcBuff ++)) * mAdcGain;				// left  = I, Mic, Aux

		mAdcBuffer[i] = mHiPassMF.Process(Complex(adc2, adc1));					// DC remover

		mDacBuffer[i].real(0.0f);												// silence if no signal
		mDacBuffer[i].imag(0.0f);
	}

	if (mQuietCnt == 0)
	{
		if (mRadioVX) mRadioVX->NewData(mAdcBuffer, mDacBuffer);				// first
		if (mRadioRX) mRadioRX->NewData(mAdcBuffer, mDacBuffer);
		if (mRadioTX) mRadioTX->NewData(mAdcBuffer, mDacBuffer);
	}
	else
		mQuietCnt = mQuietCnt - 1;

	for (int16_t i = 0; i < SAMPLE_SIZE; i ++)
	{
		*(DacBuff ++) = FloatToInt24(mDacBuffer[i].real());
		*(DacBuff ++) = FloatToInt24(mDacBuffer[i].imag());
	}
}
//-----------------------------------------------------------------------------
