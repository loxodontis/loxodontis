//-----------------------------------------------------------------------------
/*
 * This file is part of the FX-4CR-V2 project.
 * See: https://github.com/f5bud/FX-4CR-V2
 *
 * Copyright (c) 2024 Daniel Nespoulous, F5BUD
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE. 
 */
//-----------------------------------------------------------------------------
//	SaiSwitch.h
//-----------------------------------------------------------------------------
#ifndef INC_SAISWITCH_H_
#define INC_SAISWITCH_H_

//-----------------------------------------------------------------------------
#include "SaiService.h"
#include "Audio.h"
#include "RadioRX.h"
#include "RadioTX.h"
#include "RadioVX.h"
#include "Kernel.h"

//-----------------------------------------------------------------------------
class SaiSwitch: public SaiService
{
private:
	float32_t	mAdcGain;
	int16_t		mQuietCnt;

	Audio		mAudio;
	Thread 		*mThread;

	BiCascade<Complex, 3> mHiPassMF;

	Complex mAdcBuffer[SAMPLE_SIZE];
	Complex mDacBuffer[SAMPLE_SIZE];

	void setAdcGain(const ParamType &param);

	void SaiData(int32_t *AdcBuff, int32_t *DacBuff) override;

protected:
	RadioRX	*mRadioRX;
	RadioTX	*mRadioTX;
	RadioVX *mRadioVX;

public:
	std::string getProgress ();
	bool		getVoicePtt	();
	void		setVoicePtt	();

	void Init		(Thread &thread);
	void stopSignal	();
	void FinalMute	();

	void setRecept	(const ParamType &param);
	void setTransmit(const ParamType &param);
	void setVoice   (const ParamType &param);
};
//-----------------------------------------------------------------------------

#endif
