/*
 * This file is part of the FX-4CR-V2 project.
 * See: https://github.com/f5bud/FX-4CR-V2
 *
 * Copyright (c) 2024 Daniel Nespoulous, F5BUD
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE. 
 */
//-----------------------------------------------------------------------------
//	SideTone.h
//-----------------------------------------------------------------------------
#ifndef INC_SIDETONE_H_
#define INC_SIDETONE_H_

//-----------------------------------------------------------------------------
#include "CwService.h"
#include "GpioPin.h"
#include "ToneGen.h"

//-----------------------------------------------------------------------------
enum eStateType
{
	eWaitDit, eToneDit, eQuietDit,
	eWaitDah, eToneDah, eQuietDah
};

//-----------------------------------------------------------------------------
class SideTone: public CwService
{
private:
	GpioPin		mDitKey = GpioPin(GPIOD, 10, eInMode, eOpenDrain, eLowSpeed, ePullUp, 0);
	GpioPin		mDahHey = GpioPin(GPIOD, 11, eInMode, eOpenDrain, eLowSpeed, ePullUp, 0);

	ToneGen		mToneGen;

	eStateType	mStateType;
	eInputType	mInputType;
	int32_t		mToneDelay;
	int16_t		mTxRxDelay;
	int16_t		mCounter;

	eCwKeyType	mCwKeyType;
	bool		mReverse;
	bool		mIambicAB;

	bool		mNewDit;
	bool		mNewDah;
	bool		mNewPtt;

	bool		getDitKey	();
	bool		getDahKey	();
	bool		getPttKey	();

	void		setDitTime	();
	void		setDahTime	();
	void		setQuietTime(eStateType state, int16_t mult = 1);
	void		setWaitTime	(eStateType state);

	void		setKeyTone	(eInputType value);

	void		simpleKeyer	();
	void		paddleKeyer	();
	void		messageKeyer();

	void		sideToneOn	();
	void		sideToneOff	();

	void		updateKeys	();

public:
	void		Init();
	void		setEditTemp(char *value, int16_t size);

	void		Handler		();
	eInputType getKeyTone	();
};
//-----------------------------------------------------------------------------
#endif
