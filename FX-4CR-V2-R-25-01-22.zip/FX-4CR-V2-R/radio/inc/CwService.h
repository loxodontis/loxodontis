/*
 * This file is part of the FX-4CR-V2 project.
 * See: https://github.com/f5bud/FX-4CR-V2
 *
 * Copyright (c) 2024 Daniel Nespoulous, F5BUD
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
//-----------------------------------------------------------------------------
//	CwService.h
//-----------------------------------------------------------------------------
#ifndef INC_CWSERVICE_H_
#define INC_CWSERVICE_H_
//-----------------------------------------------------------------------------
#include "Defines.h"

//-----------------------------------------------------------------------------
class CwService
{
	typedef void (*RxCharType)(const char value);

private:
	bool		mSpace;
	int16_t		mRxCode;

	char *		mEditTemp;
	int16_t		mEditSize;

	int16_t		mTxCode;
	std::string mTxMessage;

	bool		mLastStateReal;
	bool		mLastStateFilt;
//	int32_t		mLastStateTime;

	int32_t		mHiStartTime;
	int32_t		mLoStartTime;

	int32_t		mDitAvgTime;
	int32_t		mDahAvgTime;
	int32_t		mBrkAvgTime;

	void CheckCode		(float duration);
	void AddTemp		(char value);

protected:
	int16_t getNext		();

	bool	isTxMessage	();
	int16_t findTxCode	(char letter);
	char	findRxLetter(int16_t code);

	void Process		(bool newState);

public:
	void Correction		(bool all);
	void setEditTemp	(char *value, int16_t size);
	void setTxMessage	(char *value);

	void Reset 			(int32_t delay);
	void Stop			();
};

//-----------------------------------------------------------------------------
#endif
