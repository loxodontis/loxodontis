/*
 * This file is part of the FX-4CR-V2 project.
 * See: https://github.com/f5bud/FX-4CR-V2
 *
 * Copyright (c) 2024 Daniel Nespoulous, F5BUD
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE. 
 */
//-----------------------------------------------------------------------------
//	RadioTask.h
//-----------------------------------------------------------------------------
#ifndef INC_RADIOTASK_H_
#define INC_RADIOTASK_H_

//-----------------------------------------------------------------------------
#include "Kernel.h"
#include "GpioPin.h"
#include "SaiSwitch.h"
#include "Si5351.h"

#define RADIOSTACK_SIZE 256				// (size * 4)
//-----------------------------------------------------------------------------
class RadioTask: public Thread, public SaiSwitch
{
private:
	GpioPin		mRxAtt    = GpioPin(GPIOB,  8, eOutMode, eOpenDrain, eLowSpeed, ePullUp, 0);

	GpioPin		mFilter0  = GpioPin(GPIOD,  6, eOutMode, eOpenDrain, eLowSpeed, ePullUp, 0);	// BCD bit0
	GpioPin		mFilter1  = GpioPin(GPIOD,  5, eOutMode, eOpenDrain, eLowSpeed, ePullUp, 0);	// BCD bit1
	GpioPin		mFilter2  = GpioPin(GPIOD,  4, eOutMode, eOpenDrain, eLowSpeed, ePullUp, 0);	// BCD bit2
	GpioPin		mFilter3  = GpioPin(GPIOD,  3, eOutMode, eOpenDrain, eLowSpeed, ePullUp, 0);	// BCD bit3

	GpioPin		mTxRelay0 = GpioPin(GPIOD,  0, eOutMode, eOpenDrain, eLowSpeed, ePullUp, 0);	// 80 M
	GpioPin		mTxRelay1 = GpioPin(GPIOC, 12, eOutMode, eOpenDrain, eLowSpeed, ePullUp, 0);	// 60 M / 40 M
	GpioPin		mTxRelay2 = GpioPin(GPIOD,  1, eOutMode, eOpenDrain, eLowSpeed, ePullUp, 0);	// 30 M / 20 M
	GpioPin		mTxRelay3 = GpioPin(GPIOC, 10, eOutMode, eOpenDrain, eLowSpeed, ePullUp, 0);	// 17 M / 15 M
	GpioPin		mTxRelay4 = GpioPin(GPIOD,  2, eOutMode, eOpenDrain, eLowSpeed, ePullUp, 0);	// 12 M / 10 M
	GpioPin		mTxRelay5 = GpioPin(GPIOA, 14, eOutMode, eOpenDrain, eLowSpeed, ePullUp, 0);	//  6 M

	GpioPin		mTransmit = GpioPin(GPIOD,  7, eOutMode, eOpenDrain, eLowSpeed, ePullUp, 0);	// Low = TX, Hight = RX
	GpioPin		mPttOut   = GpioPin(GPIOC, 11, eOutMode, eOpenDrain, eLowSpeed, ePullUp, 0);
	GpioPin		mSi5351AB = GpioPin(GPIOE, 10, eOutMode, eOpenDrain, eLowSpeed, ePullUp, 0);

	Si5351		mSi5351;

	ParamType	mParamType;

	eModeType	mCurMode;
	eBandType	mCurBand;
	bool		mCurRxAtt;

	int16_t		mRssiDb;
	int32_t		mRssiArray[SCREEN_SIZE];

	static void Handler();

	void		Loop   	();
	void		RadioRx	();
	void		RadioTx	();
	void		RadioVx	();
	float32_t	FftToWf	(float32_t value);
	void		ComputeRssi();

public:
	RadioTask():Thread(Handler, RADIOSTACK_SIZE) { }

	int16_t		getAlc		();
	int32_t *	getRssiArray();
	int16_t		getRssiDb	();
	std::string	getRssiDbStr();
	int16_t		getSmeter	();
	float32_t	getSwr		();
	std::string	getSwrAlcStr();
	std::string	getTempStr	();
	float32_t 	getVolt		();
	std::string	getVoltStr	();
	float32_t	getWatt		();
	std::string	getWattStr	();

	void		finalMute	();
	bool		isOnAir		();
};
//-----------------------------------------------------------------------------
extern RadioTask gRadioTask;

#endif
