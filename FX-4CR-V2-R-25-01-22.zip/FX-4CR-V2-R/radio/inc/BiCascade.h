/*
 * This file is part of the FX-4CR-V2 project.
 * See: https://github.com/f5bud/FX-4CR-V2
 *
 * Copyright (c) 2024 Daniel Nespoulous, F5BUD
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE. 
 */
//-----------------------------------------------------------------------------
//	BiCascade.h
//-----------------------------------------------------------------------------
#ifndef INC_BICASCADE_H_
#define INC_BICASCADE_H_

//-----------------------------------------------------------------------------
#include "Defines.h"

//-----------------------------------------------------------------------------
template<class T, int16_t SIZE>
class BiCascade
{
private:
	int32_t		mFc;
	
	float32_t	mBiqA[SIZE * 2];
	float32_t	mBiqB[SIZE * 3];
	T		 	mData[SIZE * 2 + 2];

public:
	__attribute__ ((noinline)) void Clear()
	{
		for (int16_t i = 0; i < SIZE * 2 + 2; i ++)
		{
			mData[i] = 0;
		}
	}

	__attribute__ ((noinline)) void InitLoPass(int32_t fc)
	{
		if (fc != mFc)
		{
			float32_t *a = mBiqA;
			float32_t *b = mBiqB;
			float32_t w = (fc * PI2_f32) / L96000;

			for (int16_t i = 0; i < SIZE; i ++)
			{
				int16_t k = SIZE - i - 1;
				float32_t phi = PI_f32 / (4 * SIZE) * (k * 2 + 1);
				float32_t alpha = sinf(w) * cosf(phi);

				b[0] = (1.0f - cosf(w)) / (2.0f * (1.0 + alpha));
				b[1] = (1.0f - cosf(w)) / (1.0f + alpha);
				b[2] = (1.0f - cosf(w)) / (2.0f * (1.0 + alpha));

				a[0] = -2.0f * cosf(w) / (1.0f + alpha);
				a[1] = (1.0f - alpha)  / (1.0f + alpha);

				a = a + 2;
				b = b + 3;
			}

			mFc = fc;
		}
	}

	__attribute__ ((noinline)) void InitHiPass(int32_t fc)
	{
		if (fc != mFc)
		{
			float32_t *a = mBiqA;
			float32_t *b = mBiqB;
			float32_t w = (fc * PI2_f32) / L96000;

			for (int16_t i = 0; i < SIZE; i ++)
			{
				int16_t k = SIZE - i - 1;
				float32_t phi = PI_f32 / (4 * SIZE) * (k * 2 + 1);
				float32_t alpha = sinf(w) * cosf(phi);

				b[0] =  (1.0f + cosf(w)) / (2.0f * (1.0 + alpha));
				b[1] = -(1.0f + cosf(w)) / (1.0f + alpha);
				b[2] =  (1.0f + cosf(w)) / (2.0f * (1.0 + alpha));

				a[0] =  -2.0f * cosf(w)  / (1.0f + alpha);
				a[1] =  (1.0f - alpha)   / (1.0f + alpha);

				a = a + 2;
				b = b + 3;
			}

			mFc = fc;
		}
	}

	__attribute__ ((noinline)) T Process(T value)
	{
		float32_t *a = mBiqA;
		float32_t *b = mBiqB;
		T		  *d = mData;

		for (int16_t k = 0; k < SIZE; k ++)
		{
			T y = value * b[0];

			y = y + (d[0] * b[1] + d[1] * b[2]);
			y = y - (d[2] * a[0] + d[3] * a[1]);

			d[1] = d[0];
			d[0] = value;
			value = y;

			d = d + 2;
			a = a + 2;
			b = b + 3;
		}

		d[1] = d[0];
		d[0] = value;

		return value;
	}
};
//-----------------------------------------------------------------------------

#endif
