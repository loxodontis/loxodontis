
/*
 * This file is part of the FX-4CR-V2 project.
 * See: https://github.com/f5bud/FX-4CR-V2
 *
 * Copyright (c) 2024 Daniel Nespoulous, F5BUD
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE. 
 */
//-----------------------------------------------------------------------------
//	AlcFunc.h
//-----------------------------------------------------------------------------
#ifndef INC_ALCFUNC_H_
#define INC_ALCFUNC_H_

//-----------------------------------------------------------------------------
#include "Defines.h"

//-----------------------------------------------------------------------------
static constexpr float32_t sKp = 0.010f;										// PIC coeffs
static constexpr float32_t sKi = 0.001f;
static constexpr float32_t sKd = 0.060f;

//-----------------------------------------------------------------------------
class AlcFunc
{
private:
	float32_t	mPowerRef;
	float32_t	mPeak;

	float32_t	mAlcGain;
	float32_t	mInteg;
	float32_t	mError;

public:
	//-----------------------------------------------------------------------------
	void Init()
	{
		mPowerRef = 0L;
		mAlcGain  = 0.0f;
	}
	//-----------------------------------------------------------------------------
	void setPower(float32_t value)
	{
		if (mPowerRef != value)
		{
			mPowerRef = value;
			mAlcGain  = value;

			mError = 0.0f;
			mInteg = 0.0f;
		}
	}
	//-----------------------------------------------------------------------------
	float32_t getAlc(float32_t peak)
	{
		if (mPowerRef)
		{
			float32_t error = mPowerRef - peak;

			mPeak  = peak;
			mInteg = mInteg + error;

			float32_t deriv = error - mError;

			mError = error;

//			mAlcGain = mAlcGain + (sKp * error + sKi * mInteg + sKd * deriv);
			mAlcGain = mAlcGain + (sKp * error + sKd * deriv);

			mAlcGain = std::max(mAlcGain, 0.001f);
			mAlcGain = std::min(mAlcGain, mPowerRef);
		}

		return mAlcGain;
	}
	//-----------------------------------------------------------------------------
	int16_t getRate()
	{
		int16_t result = (mPeak * 100L) / mPowerRef;

		return std::min((int16_t) 100, result);
	}
};
//-----------------------------------------------------------------------------

#endif
