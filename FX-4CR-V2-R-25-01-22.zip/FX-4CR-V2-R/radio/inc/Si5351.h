/*
 * This file is part of the FX-4CR-V2 project.
 * See: https://github.com/f5bud/FX-4CR-V2
 *
 * Copyright (c) 2024 Daniel Nespoulous, F5BUD
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE. 
 */
//-----------------------------------------------------------------------------
//	Si5351.h
//-----------------------------------------------------------------------------
#ifndef INC_SI5351_H_
#define INC_SI5351_H_

//-----------------------------------------------------------------------------
#include "System.h"
#include "Kernel.h"

//-----------------------------------------------------------------------------
#define SI5351_CLK0		16
#define SI5351_CLK1		17
#define SI5351_CLK2		18

#define SI5351_PLLA		26
#define SI5351_PLLB		34

#define SI5351_MS0		42
#define SI5351_MS1		50
#define SI5351_MS2		58

#define SI5351_RESET	177

//-----------------------------------------------------------------------------
class Si5351
{
private:
	int32_t mTcxo;
	int32_t	mFrequency;

	void Pll	(uint8_t reg, int32_t P1, int32_t P2);
	void Synth	(uint8_t reg, int32_t P1);

public:
	void Init	(Thread &thread);
	void SetFreq(int32_t tcxo, int32_t freq);
};
//-----------------------------------------------------------------------------
#endif
