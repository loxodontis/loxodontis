/*
 * This file is part of the FX-4CR-V2 project.
 * See: https://github.com/f5bud/FX-4CR-V2
 *
 * Copyright (c) 2024 Daniel Nespoulous, F5BUD
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
//-----------------------------------------------------------------------------
//	DspNotch.h
//-----------------------------------------------------------------------------
#ifndef INC_DSPNOTCH_H_
#define INC_DSPNOTCH_H_

//-----------------------------------------------------------------------------
#include "Defines.h"

//-----------------------------------------------------------------------------
#define FILTER_SIZE 128

static constexpr float32_t sBeta = 0.03f;
static constexpr float32_t sDecay = 0.999999f;

//-----------------------------------------------------------------------------
class DspNotch
{
private:
	bool	  mNotch;

	int16_t   mCoeffIndex;
	float32_t mCoeffData[FILTER_SIZE];

	int16_t   mFilterIndex;
	float32_t mFilterData[FILTER_SIZE];
public:
	void Init();

	void setNotch(bool value)
	{
		mNotch = value;
	}

	float32_t Process(float32_t data);
};
//-----------------------------------------------------------------------------

#endif
