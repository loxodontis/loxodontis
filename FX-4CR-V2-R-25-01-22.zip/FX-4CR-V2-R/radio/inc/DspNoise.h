/*
 * This file is part of the FX-4CR-V2 project.
 * See: https://github.com/f5bud/FX-4CR-V2
 *
 * Copyright (c) 2024 Daniel Nespoulous, F5BUD
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE. 
 */
//-----------------------------------------------------------------------------
//	DspNoise.h
//-----------------------------------------------------------------------------
#ifndef INC_DSPNOISE_H_
#define INC_DSPNOISE_H_

//-----------------------------------------------------------------------------
#include "Circular.h"
#include "Complex.h"

//-----------------------------------------------------------------------------
#define COEFF_SIZE 64		// 16, 32, 64, 128 max !!

//-----------------------------------------------------------------------------
class DspNoise
{
private:
	int16_t   mLatency;
	int16_t   mIndex;
	
	float32_t mEnergy;
	float32_t mFactor;

	float32_t mCoeffs[COEFF_SIZE];
	Complex   mBuffer[COEFF_SIZE];
	Circular<Complex, COEFF_SIZE + 20> mCircular;

	Complex   getBuffer(int16_t index);

public:
	void	Init		();
	void	setLatency	(int16_t value);
	Complex Process		(Complex value);
};

//-----------------------------------------------------------------------------
#endif
