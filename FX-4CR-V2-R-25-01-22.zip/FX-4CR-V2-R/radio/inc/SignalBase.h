/*
 * This file is part of the FX-4CR-V2 project.
 * See: https://github.com/f5bud/FX-4CR-V2
 *
 * Copyright (c) 2024 Daniel Nespoulous, F5BUD
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE. 
 */
//-----------------------------------------------------------------------------
//	SignalBase.h
//-----------------------------------------------------------------------------
#ifndef INC_SIGNALBASE_H_
#define INC_SIGNALBASE_H_

//-----------------------------------------------------------------------------
#include "BiCascade.h"
#include "DspSource.h"
#include "DspEmphas.h"

//-----------------------------------------------------------------------------
class SignalBase
{
protected:
	DspSource mDdsMix;
	BiCascade<Complex, 7> mLoPassMF;

public:
	void Init()
	{
		mLoPassMF.Clear();
	}

	virtual void      Update   (const ParamType &param) = 0;
	virtual float32_t ProcessRx(Complex value)			= 0;
	virtual Complex   ProcessTx(float32_t value)		= 0;
};
//-----------------------------------------------------------------------------
//	RxTx modes Process
//-----------------------------------------------------------------------------
class SignalCW: public SignalBase
{
private:
	DspSource mDdsBfo;

public:
	void	  Update   (const ParamType &param) override;
	float32_t ProcessRx(Complex value)			override;
	Complex   ProcessTx(float32_t value)		override;
};
//-----------------------------------------------------------------------------
class SignalLSB: public SignalBase
{
private:
	DspSource mDdsBfo;

public:
	void	  Update   (const ParamType &param) override;
	float32_t ProcessRx(Complex value)			override;
	Complex   ProcessTx(float32_t value)		override;
};
//-----------------------------------------------------------------------------
class SignalUSB: public SignalBase
{
private:
	DspSource mDdsBfo;

public:
	void	  Update   (const ParamType &param) override;
	float32_t ProcessRx(Complex value)			override;
	Complex   ProcessTx(float32_t value)		override;
};
//-----------------------------------------------------------------------------
class SignalAM: public SignalBase
{
private:
	DspEmphas mEmphasis;

public:
	void	  Update   (const ParamType &param) override;
	float32_t ProcessRx(Complex value)			override;
	Complex   ProcessTx(float32_t value)		override;
};
//-----------------------------------------------------------------------------
class SignalFM: public SignalBase
{
private:
	float32_t mPhase;
	Complex	  mDelayed;

public:
	void	  Update   (const ParamType &param) override;
	float32_t ProcessRx(Complex value)			override;
	Complex   ProcessTx(float32_t value)		override;
};
//-----------------------------------------------------------------------------

#endif
