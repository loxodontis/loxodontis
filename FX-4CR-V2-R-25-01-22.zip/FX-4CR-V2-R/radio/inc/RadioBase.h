/*
 * This file is part of the FX-4CR-V2 project.
 * See: https://github.com/f5bud/FX-4CR-V2
 *
 * Copyright (c) 2024 Daniel Nespoulous, F5BUD
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE. 
 */
//-----------------------------------------------------------------------------
//	RadioBase.h
//-----------------------------------------------------------------------------
#ifndef INC_RADIOBASE_H_
#define INC_RADIOBASE_H_

//-----------------------------------------------------------------------------
#include "SignalBase.h"

//-----------------------------------------------------------------------------
constexpr int32_t FloatToInt24(float value)
{
	return value * (1 << 23);
}
//-----------------------------------------------------------------------------
constexpr float32_t Int24ToFloat(int32_t value)
{
	return (value << 8) * (1.0f / (1 << 31));			// ajust sign and convert
}
//-----------------------------------------------------------------------------
constexpr int8_t FloatToInt8(float value)
{
	return value * (1 << 7);
}
//-----------------------------------------------------------------------------
constexpr float32_t Int8ToFloat(int8_t value)
{
	return (value << 24) * (1.0f / (1 << 31));			// ajust sign and convert
}
//-----------------------------------------------------------------------------
class RadioBase
{
protected:
	float32_t	mIqMag;
	float32_t	mIqPha;

	float32_t	mAdcGain;
	float32_t	mDacGain;

	SignalBase	*mSignal;

public:
	virtual void Init   (const ParamType &param, SignalBase *signal) = 0;
	virtual void Update (const ParamType &param)					 = 0;
	virtual void NewData(Complex *AdcBuff, Complex *DacBuff)		 = 0;
};
//-----------------------------------------------------------------------------

#endif
