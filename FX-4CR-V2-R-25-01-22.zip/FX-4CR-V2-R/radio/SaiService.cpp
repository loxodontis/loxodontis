/*
 * This file is part of the FX-4CR-V2 project.
 * See: https://github.com/f5bud/FX-4CR-V2
 *
 * Copyright (c) 2024 Daniel Nespoulous, F5BUD
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE. 
 */
//-----------------------------------------------------------------------------
//	SaiService.cpp
//-----------------------------------------------------------------------------
#include "SaiService.h"
#include "DmaBase.h"
#include "SaiBase.h"

//-----------------------------------------------------------------------------
static SaiService *sSaiService;

static DMAMEM int32_t	sAdcBuffer0[SAMPLE_SIZE * 2];
static DMAMEM int32_t	sAdcBuffer1[SAMPLE_SIZE * 2];

static DMAMEM int32_t	sDacBuffer0[SAMPLE_SIZE * 2];
static DMAMEM int32_t	sDacBuffer1[SAMPLE_SIZE * 2];

//-----------------------------------------------------------------------------
extern "C" void DMA1_Stream1_IRQHandler()		// ADC, slave, Stream1, interrupt
{
	DMA1->LIFCR = 0b0000'111101'000000;												// CTCIF(1), CHTIF(1), CTEIF(1), CDMEIF(1), CFEIF(1)
	sSaiService->IRQHandler();
}
//-----------------------------------------------------------------------------
void SaiService::IRQHandler()
{
	if (DMA1_Stream1->CR & DMA_SxCR_CT)
	{
		SaiData(sAdcBuffer0, sDacBuffer0);
	}
	else
	{
		SaiData(sAdcBuffer1, sDacBuffer1);
	}

	mAdcService.Loop();
	mTempService.Loop();
}
//-----------------------------------------------------------------------------
void SaiService::Init()
{
	sSaiService = this;

	SaiBase().Init(SAI1);
	DmaBase().Init(DMA1);

	mAdcService.Init();
	mTempService.Init();

	GpioPin(GPIOE, 2, eAltMode, ePushPull, eHi2Speed, ePullNone, 6);					// SaiMclka
	GpioPin(GPIOE, 3, eAltMode, ePushPull, eHi2Speed, ePullNone, 6);					// SaiSdb
	GpioPin(GPIOE, 4, eAltMode, ePushPull, eHi2Speed, ePullNone, 6);					// SaiFsa
	GpioPin(GPIOE, 5, eAltMode, ePushPull, eHi2Speed, ePullNone, 6);					// SaiScka
	GpioPin(GPIOE, 6, eAltMode, ePushPull, eHi2Speed, ePullNone, 6);					// SaiSda

	NVIC_SetPriority(DMA1_Stream1_IRQn, 6);												// 5 is for SysTick_IRQn
	NVIC_EnableIRQ  (DMA1_Stream1_IRQn);

	InitStream0();
	InitStream1();

	InitBlockA();
	InitBlockB();
}
//-----------------------------------------------------------------------------
void SaiService::InitBlockA()		// DAC, master, Stream0
{
	SAI1_Block_A->CR1   = 0;															// 00: Master transmitter
	SAI1_Block_A->CR2   = 0;
	SAI1_Block_A->FRCR  = 0;
	SAI1_Block_A->SLOTR = 0;
	SAI1_Block_A->CLRFR = 0b0111'0111;													// clear all errors

	MODIFY_REG(SAI1_Block_A->FRCR, SAI_xFRCR_FSALL,   31UL << SAI_xFRCR_FSALL_Pos);		// 32: Frame synchronization
	MODIFY_REG(SAI1_Block_A->FRCR, SAI_xFRCR_FRL,     63UL << SAI_xFRCR_FRL_Pos);		// 64: Frame length

	SET_BIT(SAI1_Block_A->FRCR, SAI_xFRCR_FSOFF);										// 1: FS is asserted one bit before the first bit of the slot 0
	SET_BIT(SAI1_Block_A->FRCR, SAI_xFRCR_FSDEF);										// 1: FS signal is a start of frame signal + channel side identification

	MODIFY_REG(SAI1_Block_A->SLOTR, SAI_xSLOTR_SLOTEN, 3UL << SAI_xSLOTR_SLOTEN_Pos);	// 0b0000'0011: Slot enable
	MODIFY_REG(SAI1_Block_A->SLOTR, SAI_xSLOTR_NBSLOT, 1UL << SAI_xSLOTR_NBSLOT_Pos);	//  2: Number of slots in an audio frame
	MODIFY_REG(SAI1_Block_A->SLOTR, SAI_xSLOTR_SLOTSZ, 2UL << SAI_xSLOTR_SLOTSZ_Pos);	// 10: 32-bit

	MODIFY_REG(SAI1_Block_A->CR1, SAI_xCR1_MCKDIV,     4UL << SAI_xCR1_MCKDIV_Pos);		//   4: Divides by 4 the kernel clock input
	MODIFY_REG(SAI1_Block_A->CR1, SAI_xCR1_DS,         6UL << SAI_xCR1_DS_Pos);			// 110: 24 bits

	SET_BIT(SAI1_Block_A->CR1, SAI_xCR1_DMAEN);											// 1: DMA enabled
	SET_BIT(SAI1_Block_A->CR1, SAI_xCR1_SAIEN);											// 1: SAI master next
}
//-----------------------------------------------------------------------------
void SaiService::InitBlockB()		// ADC, slave, Stream1, interrupt
{
	SAI1_Block_B->CR1   = 0;															// SAI1_Block_A in master mode
	SAI1_Block_B->CR2   = 0;
	SAI1_Block_B->FRCR  = 0;
	SAI1_Block_B->SLOTR = 0;
	SAI1_Block_B->CLRFR = 0b0111'0111;													// clear all errors

	MODIFY_REG(SAI1_Block_B->FRCR, SAI_xFRCR_FSALL,   31UL << SAI_xFRCR_FSALL_Pos);		// 32: Frame synchronization
	MODIFY_REG(SAI1_Block_B->FRCR, SAI_xFRCR_FRL,     63UL << SAI_xFRCR_FRL_Pos);		// 64: Frame length

	SET_BIT(SAI1_Block_B->FRCR, SAI_xFRCR_FSOFF);										// 1: FS is asserted one bit before the first bit of the slot 0
	SET_BIT(SAI1_Block_B->FRCR, SAI_xFRCR_FSDEF);										// 1: FS signal is a start of frame signal + channel side identification

	MODIFY_REG(SAI1_Block_B->SLOTR, SAI_xSLOTR_SLOTEN, 3UL << SAI_xSLOTR_SLOTEN_Pos);	// 0b0000'0011: Slot enable
	MODIFY_REG(SAI1_Block_B->SLOTR, SAI_xSLOTR_NBSLOT, 1UL << SAI_xSLOTR_NBSLOT_Pos);	//  2: Number of slots in an audio frame
	MODIFY_REG(SAI1_Block_B->SLOTR, SAI_xSLOTR_SLOTSZ, 2UL << SAI_xSLOTR_SLOTSZ_Pos);	// 10: 32-bit

	MODIFY_REG(SAI1_Block_B->CR1, SAI_xCR1_SYNCEN,     1UL << SAI_xCR1_SYNCEN_Pos);		//  01: audio subblock synchro with other subblock
	MODIFY_REG(SAI1_Block_B->CR1, SAI_xCR1_DS,         6UL << SAI_xCR1_DS_Pos);			// 110: 24 bits
	MODIFY_REG(SAI1_Block_B->CR1, SAI_xCR1_MODE,       3UL << SAI_xCR1_MODE_Pos);		//  11: Slave receiver (before DMAEN !!!)

	SET_BIT(SAI1_Block_B->CR1, SAI_xCR1_DMAEN);											// 1: DMA enabled
	SET_BIT(SAI1_Block_B->CR1, SAI_xCR1_SAIEN);											// 1: SAI slave first
}
//-----------------------------------------------------------------------------
void SaiService::InitStream0()		// DAC, master, Stream0
{
	DMAMUX1_Channel0->CCR = 87;															// 87: SAI1_Block_A DMA (page: 694)

	DMA1_Stream0->CR  = 0;
	DMA1_Stream0->FCR = 0;
	DMA1->LIFCR       = 0b0000'000000'111101;											// clear CTCIF(0), CHTIF(0), CTEIF(0), CDMEIF(0), CFEIF(0)

	DMA1_Stream0->PAR  = (uint32_t) &SAI1_Block_A->DR;									// DAC
	DMA1_Stream0->M0AR = (uint32_t) sDacBuffer0;
	DMA1_Stream0->M1AR = (uint32_t) sDacBuffer1;
	DMA1_Stream0->NDTR = SAMPLE_SIZE * 2;

	MODIFY_REG(DMA1_Stream0->CR, DMA_SxCR_PL,    2UL << DMA_SxCR_PL_Pos);				// 10: High priority
	MODIFY_REG(DMA1_Stream0->CR, DMA_SxCR_MSIZE, 2UL << DMA_SxCR_MSIZE_Pos);			// 10: Word (32-bit)
	MODIFY_REG(DMA1_Stream0->CR, DMA_SxCR_PSIZE, 2UL << DMA_SxCR_PSIZE_Pos);			// 10: Word (32-bit)
	MODIFY_REG(DMA1_Stream0->CR, DMA_SxCR_DIR,   1UL << DMA_SxCR_DIR_Pos);				// 01: Memory-to-peripheral

	SET_BIT(DMA1_Stream0->CR, DMA_SxCR_DBM);											// 1: Memory target switched at the end of the DMA transfer
	SET_BIT(DMA1_Stream0->CR, DMA_SxCR_MINC);											// 1: Memory address pointer incremented
	SET_BIT(DMA1_Stream0->CR, DMA_SxCR_CIRC);											// 1: Circular mode enabled
	SET_BIT(DMA1_Stream0->CR, DMA_SxCR_EN);												// 1: Stream enabled
}
//-----------------------------------------------------------------------------
void SaiService::InitStream1()		// ADC, slave, Stream1, interrupt
{
	DMAMUX1_Channel1->CCR = 88;															// 88: SAI1_Block_B DMA (page: 694)

	DMA1_Stream1->CR  = 0;
	DMA1_Stream1->FCR = 0;
	DMA1->LIFCR       = 0b0000'111101'000000;											// clear CTCIF(1) CHTIF(1) CTEIF(1) CDMEIF(1) CFEIF(1)

	DMA1_Stream1->PAR  = (uint32_t) &SAI1_Block_B->DR;									// ADC
	DMA1_Stream1->M0AR = (uint32_t) sAdcBuffer0;
	DMA1_Stream1->M1AR = (uint32_t) sAdcBuffer1;
	DMA1_Stream1->NDTR = SAMPLE_SIZE * 2;

	MODIFY_REG(DMA1_Stream1->CR, DMA_SxCR_PL,    2UL << DMA_SxCR_PL_Pos);				// 10: High priority
	MODIFY_REG(DMA1_Stream1->CR, DMA_SxCR_PSIZE, 2UL << DMA_SxCR_PSIZE_Pos);			// 10: Word (32-bit)
	MODIFY_REG(DMA1_Stream1->CR, DMA_SxCR_MSIZE, 2UL << DMA_SxCR_MSIZE_Pos);			// 10: Word (32-bit)

	SET_BIT(DMA1_Stream1->CR, DMA_SxCR_DBM);											// 1: Memory target switched at the end of the DMA transfer
	SET_BIT(DMA1_Stream1->CR, DMA_SxCR_MINC);											// 1: Memory address pointer incremented
	SET_BIT(DMA1_Stream1->CR, DMA_SxCR_CIRC);											// 1: Circular mode enabled
	SET_BIT(DMA1_Stream1->CR, DMA_SxCR_TCIE);											// 1: TC interrupt enabled
	SET_BIT(DMA1_Stream1->CR, DMA_SxCR_EN);												// 1: Stream enabled
}
//-----------------------------------------------------------------------------
