/*
 * This file is part of the FX-4CR-V2 project.
 * See: https://github.com/f5bud/FX-4CR-V2
 *
 * Copyright (c) 2024 Daniel Nespoulous, F5BUD
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE. 
 */
//-----------------------------------------------------------------------------
//	DspFft.cpp
//-----------------------------------------------------------------------------
#include "DspFft.h"

//-----------------------------------------------------------------------------
class FftFormat
{
public:
	static constexpr int16_t FFT_LOG2 = std::log2(FFT_SIZE);

	int16_t		Permute[FFT_SIZE];
//	float32_t	Hamming[FFT_SIZE];
	Complex		PreCalc[FFT_LOG2 + 1];

	constexpr FftFormat() : Permute(), PreCalc() //, Hamming()
	{
		for (int16_t i = 0; i < FFT_SIZE; i ++)
		{
//			Hamming[i] = 0.54f - 0.46f * cosf((PI2_f32 * i) / SIZE);
//			Hamming[i] = 0.34f - 0.66f * cosf((PI2_f32 * i) / SIZE);
			Permute[i] = bitReverse(i);
		}

		for (int16_t i = 1; i <= FFT_LOG2; i ++)
		{
			int16_t m  = 1 << i;
			int16_t m2 = m / 2;

			PreCalc[i].real(cosf(-PI_f32 / m2));
			PreCalc[i].imag(sinf(-PI_f32 / m2));
		}
	}

	constexpr int16_t bitReverse(int16_t x)
	{
		int16_t n = 0;

		for (int16_t i = 0; i < FFT_LOG2; i ++)
		{
			n <<= 1;
			n |= (x & 1);
			x >>= 1;
		}

		return n;
	}
};

//-----------------------------------------------------------------------------
static constexpr FftFormat sFormat;

//-----------------------------------------------------------------------------
void DspFft::Init()
{
	mIndex = 0;
}
//-----------------------------------------------------------------------------
void DspFft::Process(Complex value)
{
	if (mIndex < FFT_SIZE)
	{
		mData[sFormat.Permute[mIndex]] = value, // * sFormat.Hamming[mIndex];

		mIndex ++;
	}
}
//-----------------------------------------------------------------------------
Complex	*DspFft::Compute()
{
	if (mIndex < FFT_SIZE)
		return nullptr;

	for (int16_t i = 1; i <= sFormat.FFT_LOG2; i ++)
	{
		int16_t m  = 1 << i;
		int16_t m2 = m / 2;
		Complex w(1.0f, 0.0f);

		for (int16_t j = 0; j < m2; j ++)
		{
			for (int16_t k = j; k < FFT_SIZE; k += m)
			{
				Complex t = mData[k + m2] * w;
				Complex u = mData[k];

				mData[k     ] = u + t;
				mData[k + m2] = u - t;
			}

			w = w * sFormat.PreCalc[i];
		}
	}

	return mData;
}
//-----------------------------------------------------------------------------
