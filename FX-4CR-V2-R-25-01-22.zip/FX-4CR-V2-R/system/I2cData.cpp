/*
 * This file is part of the FX-4CR-V2 project.
 * See: https://github.com/f5bud/FX-4CR-V2
 *
 * Copyright (c) 2024 Daniel Nespoulous, F5BUD
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE. 
 */
//-----------------------------------------------------------------------------
//	I2cData.cpp
//-----------------------------------------------------------------------------
#include "Eeprom.h"
#include "Kernel.h"

Eeprom gI2cData;

//-----------------------------------------------------------------------------
void I2cBase::Init(I2C_TypeDef *i2c)
{
	if 		(i2c == I2C1) RCC_I2C1_CLK_ENABLE();
	else if (i2c == I2C2) RCC_I2C2_CLK_ENABLE();
	else if (i2c == I2C3) RCC_I2C3_CLK_ENABLE();

	mI2c = i2c;
	mI2c->CR1 = 0;

//	mI2c->TIMINGR = 0x307075B1;	// (100Khz)
	mI2c->TIMINGR = 0x00B03FDB;	// (400Khz)								// magic number from stm32CubeIDE

	SET_BIT(mI2c->CR1, I2C_CR1_PE);										// 1: Peripheral enable
}
//-----------------------------------------------------------------------------
void I2cData::Init()
{
	GpioPin(GPIOB, 6, eAltMode, eOpenDrain, eHi2Speed, ePullNone, 4);			// (I2C1 Slk)
	GpioPin(GPIOB, 7, eAltMode, eOpenDrain, eHi2Speed, ePullNone, 4);			// (I2C1 Sda)

	I2cBase::Init(I2C1);
}
//-----------------------------------------------------------------------------
void I2cData::WriteByte(uint8_t addr, uint8_t reg, uint8_t data)
{
	if (mMutex.Lock())
	{
		addr &= 0b1111'1110;													// bit write

		mI2c->CR2 = 0;

		MODIFY_REG(mI2c->CR2, I2C_CR2_SADD, addr << I2C_CR2_SADD_Pos);
		MODIFY_REG(mI2c->CR2, I2C_CR2_NBYTES,  2 << I2C_CR2_NBYTES_Pos);

		SET_BIT(mI2c->CR2, I2C_CR2_AUTOEND);									// 1: STOP condition is sent when NBYTES data are transferred
		SET_BIT(mI2c->CR2, I2C_CR2_START);

		WaitOnFlag(I2C_ISR_TXIS, false);										// Set by hardware when the TXDR is empty
		mI2c->TXDR = reg;

		WaitOnFlag(I2C_ISR_TXIS, false);										// Set by hardware when the TXDR is empty
		mI2c->TXDR = data;

		WaitOnFlag(I2C_ISR_BUSY, true);

		mMutex.Unlock();
	}
}
//-----------------------------------------------------------------------------
void I2cData::WaitOnFlag(uint32_t flag, bool state)
{
	uint32_t temp = 0x00FF'FFFF;												// long delay to eeprom write page

	while (READ_BIT(mI2c->ISR, flag) == state)
	{
		asm("nop");

		if (temp == 0) BusFault_Handler();

		temp --;
	}
}
//-----------------------------------------------------------------------------
