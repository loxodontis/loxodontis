/*
 * This file is part of the FX-4CR-V2 project.
 * See: https://github.com/f5bud/FX-4CR-V2
 *
 * Copyright (c) 2024 Daniel Nespoulous, F5BUD
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
//-----------------------------------------------------------------------------
//	Format.cpp
//-----------------------------------------------------------------------------
#include "Format.h"

#include <cstdarg>
#include <cmath>

//-----------------------------------------------------------------------------
char * Format::ArgToStr(char *writer, const char *value, char padChar, bool padBool, int16_t width)
{
	if (padBool)
	{
		width -= strlen(value);

		while (width > 0)
		{
			*(writer ++) = padChar;
			width --;
		}
	}

	while (*(value))
	{
		*(writer ++) = *(value ++);
		width --;
	}

	while (width > 0)
	{
		*(writer ++) = padChar;
		width --;
	}

	return writer;
}
//-----------------------------------------------------------------------------
char * Format::ArgToInt(char *writer, int32_t value, char padChar, bool padBool, int16_t width)
{
	char buffer[32];
	bool sign = (value < 0);
	char *str = buffer + sizeof buffer;

	*(-- str) = 0;

	if (sign) value *= -1;

	if (value == 0) *(-- str) = '0';

	while (value != 0)
	{
		*(-- str) = '0' + (value % 10);
		value /= 10;
	}

	if (sign)
	{
		if (padChar == '0')
		{
			width --;

			*(writer ++) = '-';

			return ArgToStr(writer, str, padChar, padBool, width);
		}

		*(-- str) = '-';
	}

	return ArgToStr(writer, str, padChar, padBool, width);
}
//-----------------------------------------------------------------------------
char * Format::ArgToFloat(char *writer, float32_t value, char padChar, bool padBool, int16_t width, int16_t decim)
{
	char buffer[32];
	bool sign = (value < 0.0f);
	char *str = buffer + sizeof buffer;

	*(-- str) = 0;

	if (sign) value *= -1.0f;

	int32_t part0 = powf(10.0f, decim);
	int32_t part1 = (int32_t) value;
	int32_t part2 = (int32_t) (value * part0) % part0;

	if (decim > 0)
	{
		while (decim != 0)
		{
			*(-- str) = '0' + (part2 % 10);

			part2 /= 10;
			decim --;
		}

		*(-- str) = '.';
	}

	if (part1 == 0)
	{
		*(-- str) = '0';
	}

	while (part1 > 0)
	{
		*(-- str) = '0' + (part1 % 10);

		part1 /= 10;
	}

	if (sign)
	{
		if (padChar == '0')
		{
			*(writer ++) = '-';

			return ArgToStr(writer, str, padChar, padBool, width);
		}

		*(-- str) = '-';
	}

	return ArgToStr(writer, str, padChar, padBool, width);
}
//-----------------------------------------------------------------------------
std::string Format::Fmt(const char *format, ...)
{
	char *writer = mBuffer;

	int16_t decim = 0;
	int16_t width = 0;
	char padChar  = ' ';
	bool padBool  = true;

	va_list args;
	va_start(args, format);

	while (*(format))
	{
		if (*(format) != '%')
		{
			*(writer ++) = *(format ++);
			continue;
		}

		format ++;

		if (*(format) == '%')
		{
			*(writer ++) = *(format ++);
			continue;
		}

		if (*(format) == '-')
		{
			format ++;
			padBool = false;
		}

		if (*(format) == '0')
		{
			format ++;
			if (padBool) padChar = '0';
		}

		while (*(format) >= '0' && *(format) <= '9')
		{
			width *= 10;
			width += *(format ++) - '0';
		}

		if (*(format) == '.')
		{
			format ++;

			while (*(format) >= '0' && *(format) <= '9')
			{
				decim *= 10;
				decim += *(format ++) - '0';
			}
		}

		switch(*(format ++))
		{
		case 's':
			writer = ArgToStr(writer, (char *) va_arg(args, char *), ' ', padBool, width);
			break;

		case 'd':
			writer = ArgToInt(writer, va_arg(args, int32_t), padChar, padBool, width);
			break;

		case 'f':
			writer = ArgToFloat(writer, (float32_t) va_arg(args, double), padChar, padBool, width, decim);
			break;
		default:
			*(writer ++) = '?';
			break;
		}

		decim = 0;
		width = 0;
		padChar = ' ';
		padBool = true;
	}

	va_end(args);

	*(writer) = '\0';

	return mBuffer;
}
//-----------------------------------------------------------------------------
