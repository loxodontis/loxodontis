/*
 * This file is part of the FX-4CR-V2 project.
 * See: https://github.com/f5bud/FX-4CR-V2
 *
 * Copyright (c) 2024 Daniel Nespoulous, F5BUD
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE. 
 */
//-----------------------------------------------------------------------------
//	FlashBase.cpp
//-----------------------------------------------------------------------------
#include "FlashBase.h"
#include "Format.h"

#define FLASH_KEY1	0x45670123U
#define FLASH_KEY2	0xCDEF89ABU

//-----------------------------------------------------------------------------
void FlashBase::Unlock()
{
	if (READ_BIT(FLASH->CR1, FLASH_CR_LOCK))
	{
		WRITE_REG(FLASH->KEYR1, FLASH_KEY1);
		WRITE_REG(FLASH->KEYR1, FLASH_KEY2);
	}
}
//-----------------------------------------------------------------------------
void FlashBase::Lock(Thread &thread)
{
	while (READ_BIT(FLASH->SR1, FLASH_SR_QW))
	{
		thread.Delay(2L);
	}

	SET_BIT(FLASH->CR1, FLASH_CR_LOCK);

	while (READ_BIT(FLASH->SR1, FLASH_SR_QW))
	{
		thread.Delay(2L);
	}
}
//-----------------------------------------------------------------------------
void FlashBase::Erase(uint32_t sector, Thread &thread)
{
	while (READ_BIT(FLASH->SR1, FLASH_SR_QW))
	{
		thread.Delay(2L);
	}

	MODIFY_REG(FLASH->CR1, FLASH_CR_PSIZE, 2UL  << FLASH_CR_PSIZE_Pos);		// 2: 32 bits
	MODIFY_REG(FLASH->CR1, FLASH_CR_SNB, sector << FLASH_CR_SNB_Pos);

	SET_BIT  (FLASH->CR1, FLASH_CR_SER);									// 1: sector erase requested
	CLEAR_BIT(FLASH->CR1, FLASH_CR_BER);									// 0: bank erase not requested
	SET_BIT  (FLASH->CR1, FLASH_CR_START);									// start erase

	while (READ_BIT(FLASH->SR1, FLASH_SR_QW))
	{
		thread.Delay(2L);
	}
}
//-----------------------------------------------------------------------------
void FlashBase::Write256(uint32_t *dst, uint32_t *src, Thread &thread)
{
	while (READ_BIT(FLASH->SR1, FLASH_SR_QW))
	{
		thread.Delay(1L);
	}

	MODIFY_REG(FLASH->CR1, FLASH_CR_PSIZE, 2UL << FLASH_CR_PSIZE_Pos);		// 2: 32 bits (4 * 8)

	CLEAR_BIT(FLASH->CR1, FLASH_CR_SER);									// 0: sector erase not requested
	CLEAR_BIT(FLASH->CR1, FLASH_CR_BER);									// 0: bank erase not requested

	SET_BIT(FLASH->CR1, FLASH_CR_PG);										// 1: Internal buffer enabled for write operations

	asm volatile (
		".thumb_func				\n"
		"dsb						\n"										// flushes pipeline data
		"isb						\n"										// flushes pipeline instructions
	);

	for (int16_t i = 0; i < 8; i ++)										// (4 * 8 * 8 = 256 bits)
	{
		*(dst ++) = *(src ++);
	}

	asm volatile (
		".thumb_func				\n"
		"dsb						\n"										// flushes pipeline data
		"isb						\n"										// flushes pipeline instructions
	);

	CLEAR_BIT(FLASH->CR1, FLASH_CR_PG);										// 0: Internal buffer disabled for write operations

	while (READ_BIT(FLASH->SR1, FLASH_SR_QW))
	{
		thread.Delay(1L);
	}
}
//-----------------------------------------------------------------------------
