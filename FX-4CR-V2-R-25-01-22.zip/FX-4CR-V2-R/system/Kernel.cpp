/*
 * This file is part of the FX-4CR-V2 project.
 * See: https://github.com/f5bud/FX-4CR-V2
 *
 * Copyright (c) 2024 Daniel Nespoulous, F5BUD
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
//-----------------------------------------------------------------------------
//	Kernel.cpp
//-----------------------------------------------------------------------------
#include "Kernel.h"
#include "stm32h750xx.h"

//-----------------------------------------------------------------------------
static volatile uint64_t sSysTick;

//-----------------------------------------------------------------------------
extern "C"
{
	__attribute__((used)) TaskType *sCurTask   = nullptr;
	__attribute__((used)) TaskType *sNextTask  = nullptr;
	__attribute__((used)) TaskType *sHeadTasks = nullptr;
}
//-----------------------------------------------------------------------------
extern "C" void Schedule()
{
	bool idle = false;

	sNextTask = sCurTask;

	while(sNextTask)
	{
		sNextTask = sNextTask->Next;

		if (sNextTask == nullptr)
		{
			sNextTask = sHeadTasks;

			if (idle) asm volatile ("wfi" ::: "memory");						// sleep
			idle = true;
		}

		if (sNextTask->State == READY)
		{
			idle = false;
			SET_BIT(SCB->ICSR, SCB_ICSR_PENDSVSET_Msk);							// switch task
			break;
		}
	}
}
//-----------------------------------------------------------------------------
extern "C" void SysTick_Handler()
{
	sSysTick = sSysTick + 1ULL;

	Schedule();

	NVIC_SetPendingIRQ(CEC_IRQn);						// chose unused interrupt
}
//-----------------------------------------------------------------------------
extern "C" void __attribute__((naked)) PendSV_Handler()
{
	asm volatile(
		".thumb_func				\n"

		"mrs r12, psp				\n"					// save psp in r12
		"isb						\n"					// flushes pipeline instructions

		"ldr r0, =sCurTask			\n"					// r0 used at end !
		"ldr r1, [r0, #0]			\n"					// r1 = sCurTask

		"tst lr, #0x00000010		\n"
		"it eq						\n"
		"vstmdbeq r12!, {s16-s31}	\n"					// save {s16-s31} in [r12 ++]
		"str lr, [r1, #4]			\n"					// save lr in r1->Exception

		"vmrs r2, fpscr				\n"					// save fpscr in r2
		"str r2, [r1, #8]			\n"					// save r2 in r1->Fpscr

		"stmfd r12!, {r4-r11}		\n"					// save {r4-r11} in [r12 ++]
		"str r12, [r1, #0]			\n"					// save r12 in r1->StackPtr (CurStack)

		/* change context here */

		"ldr r1, =sNextTask			\n"
		"ldr r1, [r1, #0]			\n"					// r3 = sNextTask
		"str r1, [r0, #0]			\n"					// sCurTask = sNextTask

		"ldr r12, [r1, #0]			\n"					// load r3->StackPtr in r12 (NextStack)
		"ldmfd r12!, {r4-r11}		\n"					// load {r4-r11} from [r12 ++]

		"ldr r2, [r1, #8]			\n"					// load r2 from r1->Fpscr
		"vmsr fpscr, r2				\n"					// load fpscr from r2

		"ldr lr, [r1, #4]			\n"					// load lr from r1->Exception
		"tst lr, #0x00000010		\n"
		"it eq						\n"
		"vldmiaeq r12!, {s16-s31}	\n"					// load {s16-s31} from [r12 ++]

		"msr psp, r12				\n"					// load psp from r12 (top stack)
		"isb						\n"					// flushes pipeline instructions

		"bx lr						\n"
	);
}
//-----------------------------------------------------------------------------
// MSP is kernel stack pointer
// PSP is user thread stack pointer
//-----------------------------------------------------------------------------
extern "C" void __attribute__((naked)) Launcher()
{
	asm volatile (
		".thumb_func				\n"

		"mov r0, #2					\n"
		"msr control, r0			\n"					// The threads should use psp

		"ldr r0, =sCurTask			\n"
		"ldr r1, [r0, #0]			\n"					// r1 = sCurTask
		"ldr r1, [r1, #0]			\n"					// load r1->StackPtr in r1 (CurTask)

		"msr psp, r1				\n"					// load psp from r1 (top stack)

		"pop {r4-r11}				\n"
		"pop {r0-r3}				\n"
		"pop {r12}					\n"
		"add sp, sp, #4				\n"					// skeep return addr
		"pop {lr}					\n"					// lr = handler
		"add sp, sp, #4				\n"					// skeep

		"dmb						\n"
		"dsb						\n"					// flushes pipeline data
		"isb						\n"					// flushes pipeline instructions

		"bx lr						\n"
	);
}
//-----------------------------------------------------------------------------
//	Thread
//-----------------------------------------------------------------------------
Thread::Thread(FuncType handler, int16_t stackSize)
{
	TaskStack.StackPtr = new uint32_t[stackSize] + stackSize;

	*(-- TaskStack.StackPtr) = 0x01000000UL;				// enable Thumb State bit;
	*(-- TaskStack.StackPtr) = (uint32_t) handler;			// space for R15 (PC)
	*(-- TaskStack.StackPtr) = 0x14141414UL;				// space for R14 (LR return addr)
	*(-- TaskStack.StackPtr) = 0x12121212UL;				// space for R12 (IP)
	*(-- TaskStack.StackPtr) = 0x03030303UL;				// space for R3
	*(-- TaskStack.StackPtr) = 0x02020202UL;				// space for R2
	*(-- TaskStack.StackPtr) = 0x01010101UL;				// space for R1
	*(-- TaskStack.StackPtr) = 0x00000000UL;				// space for R0

	*(-- TaskStack.StackPtr) = 0x11111111UL;				// space for R11
	*(-- TaskStack.StackPtr) = 0x10101010UL;				// space for R10
	*(-- TaskStack.StackPtr) = 0x09090909UL;				// space for R9
	*(-- TaskStack.StackPtr) = 0x08080808UL;				// space for R8
	*(-- TaskStack.StackPtr) = 0x07070707UL;				// space for R7
	*(-- TaskStack.StackPtr) = 0x06060606UL;				// space for R6
	*(-- TaskStack.StackPtr) = 0x05050505UL;				// space for R5
	*(-- TaskStack.StackPtr) = 0x04040404UL;				// space for R4

	TaskStack.Exception = 0xFFFFFFFDUL;
	TaskStack.State = READY;
	TaskStack.Next = nullptr;
}
//-----------------------------------------------------------------------------
void Thread::setState(StateType state)
{
	TaskStack.State = state;

	if (state == SUSPENDED)
		Schedule();
}
//-----------------------------------------------------------------------------
void Thread::Delay(int32_t delay)
{
	uint64_t tickEnd = sSysTick + delay;

	while (tickEnd > sSysTick)
	{
		Schedule();
	}
}
//-----------------------------------------------------------------------------
//	Mutex
//-----------------------------------------------------------------------------
bool Mutex::Lock()
{
	while (true)
	{
		if (__LDREXW(&mMemory) == 0)
		{
			__DMB();

			if (__STREXW(1L, &mMemory) == 0)
			{
				__DMB();

				return true;
			}
		}

		Schedule();
	}

	return false;
}
//-----------------------------------------------------------------------------
void Mutex::Unlock()
{
	__DMB();

	mMemory = 0;
}
//-----------------------------------------------------------------------------
//	Scheduler
//-----------------------------------------------------------------------------
uint64_t Scheduler::GetTick()
{
	return sSysTick;
}
//-----------------------------------------------------------------------------
void Scheduler::Run()
{
	if (sHeadTasks)
	{
		sCurTask = sHeadTasks;

		NVIC_SetPriority(PendSV_IRQn, 255);
		NVIC_EnableIRQ  (PendSV_IRQn);
		Launcher();
	}
}
//-----------------------------------------------------------------------------
void Scheduler::Append(Thread &thread, StateType state)
{
	thread.TaskStack.State = state;
	thread.TaskStack.Next  = sHeadTasks;

	sHeadTasks = &(thread.TaskStack);
}
//-----------------------------------------------------------------------------
