/*
 * This file is part of the FX-4CR-V2 project.
 * See: https://github.com/f5bud/FX-4CR-V2
 *
 * Copyright (c) 2024 Daniel Nespoulous, F5BUD
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE. 
 */
//-----------------------------------------------------------------------------
//	GpioPin.cpp
//-----------------------------------------------------------------------------
#include "GpioPin.h"

//-----------------------------------------------------------------------------
GpioPin::GpioPin(GPIO_TypeDef* port, uint8_t pin, eModeState mode, eTypeState type, eSpeedState speed, ePullState pull, uint32_t afr)
{
	uint32_t temp;

	mPort = port;
	mPin = pin;

	if		(mPort == GPIOA) RCC_GPIOA_CLK_ENABLE();
	else if (mPort == GPIOB) RCC_GPIOB_CLK_ENABLE();
	else if (mPort == GPIOC) RCC_GPIOC_CLK_ENABLE();
	else if (mPort == GPIOD) RCC_GPIOD_CLK_ENABLE();
	else if (mPort == GPIOE) RCC_GPIOE_CLK_ENABLE();
	else if (mPort == GPIOF) RCC_GPIOF_CLK_ENABLE();
	else if (mPort == GPIOG) RCC_GPIOG_CLK_ENABLE();
	else if (mPort == GPIOH) RCC_GPIOH_CLK_ENABLE();
	else if (mPort == GPIOI) RCC_GPIOI_CLK_ENABLE();
	else if (mPort == GPIOJ) RCC_GPIOJ_CLK_ENABLE();
	else if (mPort == GPIOK) RCC_GPIOK_CLK_ENABLE();

	if ((mode == eOutMode) || (mode == eAltMode))
	{
		temp = mPort->OSPEEDR;													// Speed type
		temp &= ~(GPIO_OSPEEDR_OSPEED0 << (pin * 2U));
		temp |= (speed << (pin * 2U));
		mPort->OSPEEDR = temp;

		temp = mPort->OTYPER;													// Open drain or Push-pull
		temp &= ~(GPIO_OTYPER_OT0 << pin) ;
		temp |= (type << pin);
		mPort->OTYPER = temp;

		switch(pull)
		{
		case ePullUp:
			setHigh();
			break;

		case ePullDown:
			setLow();

		default:
			break;
		}
	}

	if (mode != eAnaMode)
	{
		temp = mPort->PUPDR;													// Pull-up, Pull down or none
		temp &= ~(GPIO_PUPDR_PUPD0 << (pin * 2U));
		temp |= (pull << (pin * 2U));
		mPort->PUPDR = temp;
	}

	if (mode == eAltMode)
	{
		temp = mPort->AFR[pin >> 3U];											// Alternate function
		temp &= ~(0x0FU << ((pin & 0x07U) * 4U));
		temp |= (afr    << ((pin & 0x07U) * 4U));
		mPort->AFR[pin >> 3U] = temp;
	}

	temp = mPort->MODER;
	temp &= ~(GPIO_MODER_MODE0 << (pin * 2U));
	temp |= (mode << (pin * 2U));
	mPort->MODER = temp;
}
//-----------------------------------------------------------------------------
bool GpioPin::getPin()
{
	return (mPort->IDR & (1 << mPin));
}
//-----------------------------------------------------------------------------
void GpioPin::setPin(bool value)
{
	if (value)
		setHigh();
	else
		setLow();
}
//-----------------------------------------------------------------------------
void GpioPin::toggle()
{
	mPort->ODR = mPort->ODR ^ (1 << mPin);
}
//-----------------------------------------------------------------------------
void GpioPin::setHigh()
{
	mPort->BSRR = (1 << mPin);
}
//-----------------------------------------------------------------------------
void GpioPin::setLow()
{
	mPort->BSRR = (1 << (mPin + 16U));
}
//-----------------------------------------------------------------------------
