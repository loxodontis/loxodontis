/*
 * This file is part of the FX-4CR-V2 project.
 * See: https://github.com/f5bud/FX-4CR-V2
 *
 * Copyright (c) 2024 Daniel Nespoulous, F5BUD
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE. 
 */
//-----------------------------------------------------------------------------
//	SpiBase.h
//-----------------------------------------------------------------------------
#ifndef INC_SPIBASE_H_
#define INC_SPIBASE_H_

//-----------------------------------------------------------------------------
#include "GpioPin.h"

//-----------------------------------------------------------------------------
#define RCC_SPI1_CLK_ENABLE()	do { \
								__IO uint32_t tmpreg; \
								SET_BIT(RCC->APB2ENR, RCC_APB2ENR_SPI1EN);\
								tmpreg = READ_BIT(RCC->APB2ENR, RCC_APB2ENR_SPI1EN);\
								(void) tmpreg; \
								} while(0)

#define RCC_SPI2_CLK_ENABLE()	do { \
								__IO uint32_t tmpreg; \
								SET_BIT(RCC->APB1LENR, RCC_APB1LENR_SPI2EN);\
								tmpreg = READ_BIT(RCC->APB1LENR, RCC_APB1LENR_SPI2EN);\
								(void) tmpreg; \
								} while(0)

#define RCC_SPI3_CLK_ENABLE()	do { \
								__IO uint32_t tmpreg; \
								SET_BIT(RCC->APB1LENR, RCC_APB1LENR_SPI3EN);\
								tmpreg = READ_BIT(RCC->APB1LENR, RCC_APB1LENR_SPI3EN);\
								(void) tmpreg; \
								} while(0)

#define RCC_SPI4_CLK_ENABLE()	do { \
								__IO uint32_t tmpreg; \
								SET_BIT(RCC->APB2ENR, RCC_APB2ENR_SPI4EN);\
								tmpreg = READ_BIT(RCC->APB2ENR, RCC_APB2ENR_SPI4EN);\
								(void) tmpreg; \
								} while(0)

#define RCC_SPI5_CLK_ENABLE()	do { \
								__IO uint32_t tmpreg; \
								SET_BIT(RCC->APB2ENR, RCC_APB2ENR_SPI5EN);\
								tmpreg = READ_BIT(RCC->APB2ENR, RCC_APB2ENR_SPI5EN);\
								(void) tmpreg; \
								} while(0)

#define RCC_SPI6_CLK_ENABLE()	do { \
								__IO uint32_t tmpreg; \
								SET_BIT(RCC->APB4ENR, RCC_APB4ENR_SPI6EN);\
								tmpreg = READ_BIT(RCC->APB4ENR, RCC_APB4ENR_SPI6EN);\
								(void) tmpreg; \
								} while(0)

//-----------------------------------------------------------------------------
class SpiBase
{
public:
	void Init(SPI_TypeDef * spi);
};
//-----------------------------------------------------------------------------

#endif
