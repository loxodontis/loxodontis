/*
 * This file is part of the FX-4CR-V2 project.
 * See: https://github.com/f5bud/FX-4CR-V2
 *
 * Copyright (c) 2024 Daniel Nespoulous, F5BUD
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE. 
 */
//-----------------------------------------------------------------------------
//	I2cData.h
//-----------------------------------------------------------------------------
#ifndef INC_I2CDATA_H_
#define INC_I2CDATA_H_

//-----------------------------------------------------------------------------
#include "GpioPin.h"
#include "Kernel.h"

//-----------------------------------------------------------------------------
static constexpr uint8_t SI5351	 = 0xC0;				// 60 => 0b0110'0000+(r/w) = 0b1100'0000 = 0xC0
static constexpr uint8_t WM8978	 = 0x34;				// 1A => 0b0001'1010+(r/w) = 0b0011'0100 = 0x34
static constexpr uint8_t AT24C16 = 0xA0;

static constexpr int16_t PAGE_SIZE = 0x10;				// EEPROM page size

//-----------------------------------------------------------------------------
#define RCC_I2C1_CLK_ENABLE()	do { \
								__IO uint32_t tmpreg; \
								SET_BIT(RCC->APB1LENR, RCC_APB1LENR_I2C1EN);\
								tmpreg = READ_BIT(RCC->APB1LENR, RCC_APB1LENR_I2C1EN);\
								(void) tmpreg; \
								} while(0)

#define RCC_I2C2_CLK_ENABLE()	do { \
								__IO uint32_t tmpreg; \
								SET_BIT(RCC->APB1LENR, RCC_APB1LENR_I2C2EN);\
								tmpreg = READ_BIT(RCC->APB1LENR, RCC_APB1LENR_I2C2EN);\
								(void) tmpreg; \
								} while(0)

#define RCC_I2C3_CLK_ENABLE()	do { \
								__IO uint32_t tmpreg; \
								SET_BIT(RCC->APB1LENR, RCC_APB1LENR_I2C3EN);\
								tmpreg = READ_BIT(RCC->APB1LENR, RCC_APB1LENR_I2C3EN);\
								(void) tmpreg; \
								} while(0)

//-----------------------------------------------------------------------------
class I2cBase
{
protected:
	I2C_TypeDef * mI2c;

	void Init(I2C_TypeDef * i2c);
};
//-----------------------------------------------------------------------------
class I2cData : public I2cBase
{
protected:
	Mutex		mMutex;

	void WaitOnFlag	(uint32_t flag, bool state);

public:
	void Init();

	void WriteByte	(uint8_t addr, uint8_t reg, uint8_t  data);
};
//-----------------------------------------------------------------------------

#endif
