/*
 * This file is part of the FX-4CR-V2 project.
 * See: https://github.com/f5bud/FX-4CR-V2
 *
 * Copyright (c) 2024 Daniel Nespoulous, F5BUD
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE. 
 */
//-----------------------------------------------------------------------------
//	GpioPin.h
//-----------------------------------------------------------------------------
#ifndef INC_GPIOPIN_H_
#define INC_GPIOPIN_H_

//-----------------------------------------------------------------------------
#include "System.h"

//-----------------------------------------------------------------------------
#define RCC_GPIOA_CLK_ENABLE()	do { \
								__IO uint32_t tmpreg; \
								SET_BIT(RCC->AHB4ENR, RCC_AHB4ENR_GPIOAEN);\
								tmpreg = READ_BIT(RCC->AHB4ENR, RCC_AHB4ENR_GPIOAEN);\
								(void) tmpreg; \
								} while(0)

#define RCC_GPIOB_CLK_ENABLE()	do { \
								__IO uint32_t tmpreg; \
								SET_BIT(RCC->AHB4ENR, RCC_AHB4ENR_GPIOBEN);\
								tmpreg = READ_BIT(RCC->AHB4ENR, RCC_AHB4ENR_GPIOBEN);\
								(void) tmpreg; \
								} while(0)

#define RCC_GPIOC_CLK_ENABLE()	do { \
								__IO uint32_t tmpreg; \
								SET_BIT(RCC->AHB4ENR, RCC_AHB4ENR_GPIOCEN);\
								tmpreg = READ_BIT(RCC->AHB4ENR, RCC_AHB4ENR_GPIOCEN);\
								(void) tmpreg; \
								} while(0)

#define RCC_GPIOD_CLK_ENABLE()	do { \
								__IO uint32_t tmpreg; \
								SET_BIT(RCC->AHB4ENR, RCC_AHB4ENR_GPIODEN);\
								tmpreg = READ_BIT(RCC->AHB4ENR, RCC_AHB4ENR_GPIODEN);\
								(void) tmpreg; \
								} while(0)

#define RCC_GPIOE_CLK_ENABLE()	do { \
								__IO uint32_t tmpreg; \
								SET_BIT(RCC->AHB4ENR, RCC_AHB4ENR_GPIOEEN);\
								tmpreg = READ_BIT(RCC->AHB4ENR, RCC_AHB4ENR_GPIOEEN);\
								(void) tmpreg; \
								} while(0)

#define RCC_GPIOF_CLK_ENABLE()	do { \
								__IO uint32_t tmpreg; \
								SET_BIT(RCC->AHB4ENR, RCC_AHB4ENR_GPIOFEN);\
								tmpreg = READ_BIT(RCC->AHB4ENR, RCC_AHB4ENR_GPIOFEN);\
								(void) tmpreg; \
								} while(0)

#define RCC_GPIOG_CLK_ENABLE()	do { \
								__IO uint32_t tmpreg; \
								SET_BIT(RCC->AHB4ENR, RCC_AHB4ENR_GPIOGEN);\
								tmpreg = READ_BIT(RCC->AHB4ENR, RCC_AHB4ENR_GPIOGEN);\
								(void) tmpreg; \
								} while(0)

#define RCC_GPIOH_CLK_ENABLE()	do { \
								__IO uint32_t tmpreg; \
								SET_BIT(RCC->AHB4ENR, RCC_AHB4ENR_GPIOHEN);\
								tmpreg = READ_BIT(RCC->AHB4ENR, RCC_AHB4ENR_GPIOHEN);\
								(void) tmpreg; \
								} while(0)

#define RCC_GPIOI_CLK_ENABLE()	do { \
								__IO uint32_t tmpreg; \
								SET_BIT(RCC->AHB4ENR, RCC_AHB4ENR_GPIOIEN);\
								tmpreg = READ_BIT(RCC->AHB4ENR, RCC_AHB4ENR_GPIOIEN);\
								(void) tmpreg; \
								} while(0)

#define RCC_GPIOJ_CLK_ENABLE()	do { \
								__IO uint32_t tmpreg; \
								SET_BIT(RCC->AHB4ENR, RCC_AHB4ENR_GPIOJEN);\
								tmpreg = READ_BIT(RCC->AHB4ENR, RCC_AHB4ENR_GPIOJEN);\
								(void) tmpreg; \
								} while(0)

#define RCC_GPIOK_CLK_ENABLE()	do { \
								__IO uint32_t tmpreg; \
								SET_BIT(RCC->AHB4ENR, RCC_AHB4ENR_GPIOKEN);\
								tmpreg = READ_BIT(RCC->AHB4ENR, RCC_AHB4ENR_GPIOKEN);\
								(void) tmpreg; \
								} while(0)

//-----------------------------------------------------------------------------
#define GPIO_GET_INDEX(gpio)   (((gpio) == (GPIOA))? 0UL : \
								((gpio) == (GPIOB))? 1UL : \
								((gpio) == (GPIOC))? 2UL : \
								((gpio) == (GPIOD))? 3UL : \
								((gpio) == (GPIOE))? 4UL : \
								((gpio) == (GPIOF))? 5UL : \
								((gpio) == (GPIOG))? 6UL : \
								((gpio) == (GPIOH))? 7UL : \
								((gpio) == (GPIOI))? 8UL : \
								((gpio) == (GPIOJ))? 9UL : 10UL)

//-----------------------------------------------------------------------------
typedef enum
{
	ePullNone,
	ePullUp,
	ePullDown
} ePullState;

//-----------------------------------------------------------------------------
typedef enum
{
	ePushPull,
	eOpenDrain
} eTypeState;

//-----------------------------------------------------------------------------
typedef enum
{
	eInMode,
	eOutMode,
	eAltMode,
	eAnaMode,
	eExt1Mode,			// rising trigger
	eExt2Mode,			// falling trigger
	eExt3Mode			// both trigger
} eModeState;

//-----------------------------------------------------------------------------
typedef enum
{
	eLowSpeed,
	eMidSpeed,
	eHi1Speed,
	eHi2Speed
} eSpeedState;

//-----------------------------------------------------------------------------
class GpioPin
{
private:
//	GPIO_TypeDef* mPort;
//	uint8_t mPin;

public:
	GPIO_TypeDef* mPort;
	uint8_t mPin;

	GpioPin(GPIO_TypeDef* port, uint8_t pin, eModeState mode, eTypeState type, eSpeedState speed, ePullState pull, uint32_t afr);

	bool getPin();
	void setPin(bool value);
	void toggle();
	void setHigh();
	void setLow();
};

//-----------------------------------------------------------------------------
#endif
