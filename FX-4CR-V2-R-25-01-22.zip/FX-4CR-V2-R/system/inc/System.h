/*
 * This file is part of the FX-4CR-V2 project.
 * See: https://github.com/f5bud/FX-4CR-V2
 *
 * Copyright (c) 2024 Daniel Nespoulous, F5BUD
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE. 
 */
//-----------------------------------------------------------------------------
//	System.h
//-----------------------------------------------------------------------------
#ifndef INC_SYSTEM_H_
#define INC_SYSTEM_H_

#include "stm32h7xx.h"

#include <cmath>
#include <string>
#include <cstring>

//-----------------------------------------------------------------------------
typedef float float32_t;

static constexpr float32_t  PI_f32 = acosf(-1.0f);
static constexpr float32_t PI1_f32 = acosf(-1.0f) / 2.0f;
static constexpr float32_t PI2_f32 = acosf(-1.0f) * 2.0f;

extern "C" void BusFault_Handler();

//-----------------------------------------------------------------------------
//	from 'STM32H750VBTX_FLASH.ld'
//	.NoBuffed(NOLOAD) : { . = ALIGN(4); KEEP(*(.NoBuffed)) } > RAM_D2

#define DMAMEM __attribute__((section(".NoBuffed"), used))

//-----------------------------------------------------------------------------
#define PCLK1 (SystemCoreClock / 4UL)
#define PCLK2 (SystemCoreClock / 4UL)

#define RCC_SYSCFG_CLK_ENABLE()	do { \
								__IO uint32_t tmpreg; \
								SET_BIT(RCC->APB4ENR, RCC_APB4ENR_SYSCFGEN); \
								tmpreg = READ_BIT(RCC->APB4ENR, RCC_APB4ENR_SYSCFGEN); \
								(void) tmpreg; \
								} while(0)

//-----------------------------------------------------------------------------
void SystemClockSetup();
void SystemCacheEnable();

//-----------------------------------------------------------------------------
#endif
