/*
 * This file is part of the FX-4CR-V2 project.
 * See: https://github.com/f5bud/FX-4CR-V2
 *
 * Copyright (c) 2024 Daniel Nespoulous, F5BUD
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE. 
 */
//-----------------------------------------------------------------------------
//	LcdService.h
//-----------------------------------------------------------------------------
#ifndef INC_LCDSERVICE_H_
#define INC_LCDSERVICE_H_

//-----------------------------------------------------------------------------
#include "GpioPin.h"
#include "Kernel.h"
#include "LcdFont.h"

extern LCDFont Liquid12pt;
extern LCDFont Symbole6pt;

extern LCDFont Trebuchet5pt;
extern LCDFont Trebuchet6pt;
extern LCDFont Trebuchet9pt;

//-----------------------------------------------------------------------------
static constexpr LCDFont *DIGI1 = &Liquid12pt;
static constexpr LCDFont *SYMB1 = &Symbole6pt;			// 19px height

static constexpr LCDFont *FONT4 = &Trebuchet5pt;		// 16px height
static constexpr LCDFont *FONT5 = &Trebuchet6pt;		// 19px heigt
static constexpr LCDFont *FONT6 = &Trebuchet9pt;		// 29px height

//-----------------------------------------------------------------------------
static constexpr int16_t LCD_WIDTH  = 320;
static constexpr int16_t LCD_HEIGHT = 240;

//-----------------------------------------------------------------------------
enum eAlign
{
	eLeft,
	eCenter,
	eRight
};

enum eWrite
{
	eNone,
	eByte,
	eWord
};
//-----------------------------------------------------------------------------
class LcdService
{
private:
	Thread	*mMainThread;
	eWrite	mWriteMode;

	GpioPin	mDc    = GpioPin(GPIOB, 10, eOutMode, ePushPull, eHi2Speed, ePullNone, 0);
	GpioPin	mCs    = GpioPin(GPIOB, 11, eOutMode, ePushPull, eHi2Speed, ePullNone, 0);
	GpioPin	mReset = GpioPin(GPIOB, 12, eOutMode, ePushPull, eHi2Speed, ePullNone, 0);

	int16_t mX0;
	int16_t mY0;

	void InitSpi	();
	void InitDma	();
	void InitLcd	();

	void WriteByte	(const uint8_t  *data, int32_t count);
	void WriteWord	(const uint16_t *data, int32_t count);
	void WriteBlock	(const uint8_t *data);

protected:
	uint16_t	mBdColor;		// border color
	uint16_t	mFgColor;		// text color
	uint16_t	mBgColor;		// background color
	LCDFont		*mLcdFont;		// font type

	uint16_t	*getLine	(int16_t y);

	int16_t		getTextWidth(const char *text);

public:
	void Init		(Thread &thread);
	void IRQHandler	();
	void DrawBuffer	();

	void ClearBuffer(int16_t y, int16_t h, uint16_t color);
	void DrawText	(const char *text, int16_t xGapp, int16_t yGapp, int16_t width, eAlign align);
	void DrawPixel	(int16_t x, int16_t y, uint16_t color);
	void DrawVLine	(int16_t x, int16_t y, int16_t h, uint16_t color);
	void DrawHLine	(int16_t x, int16_t y, int16_t w, uint16_t color);
	void DrawRect	(int16_t x, int16_t y, int16_t w, int16_t h, uint16_t color);
	void DrawBox	(int16_t x, int16_t y, int16_t w, int16_t h);

	void MoveTo		(int16_t x, int16_t y);
	void LineTo		(int16_t x, int16_t y, uint16_t color);
};
//-----------------------------------------------------------------------------

#endif
