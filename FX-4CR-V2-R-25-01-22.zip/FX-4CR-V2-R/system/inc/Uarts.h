/*
 * This file is part of the FX-4CR-V2 project.
 * See: https://github.com/f5bud/FX-4CR-V2
 *
 * Copyright (c) 2024 Daniel Nespoulous, F5BUD
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE. 
 */
//-----------------------------------------------------------------------------
//	UartBase.h
//-----------------------------------------------------------------------------
#ifndef INC_UARTS_H_
#define INC_UARTS_H_

//-----------------------------------------------------------------------------
#include "GpioPin.h"
#include "RingBuffer.h"

//-----------------------------------------------------------------------------
typedef void (*FuncType)();

static constexpr int32_t SERIAL_SPEED = 115200L;

//-----------------------------------------------------------------------------
#define RCC_USART1_CLK_ENABLE()   do { \
									__IO uint32_t tmpreg; \
									SET_BIT(RCC->APB2ENR, RCC_APB2ENR_USART1EN);\
									tmpreg = READ_BIT(RCC->APB2ENR, RCC_APB2ENR_USART1EN);\
									(void) tmpreg; \
									} while(0)

#define RCC_USART2_CLK_ENABLE()   do { \
									__IO uint32_t tmpreg; \
									SET_BIT(RCC->APB1LENR, RCC_APB1LENR_USART2EN);\
									tmpreg = READ_BIT(RCC->APB1LENR, RCC_APB1LENR_USART2EN);\
									(void) tmpreg; \
									} while(0)

#define RCC_USART3_CLK_ENABLE()   do { \
									__IO uint32_t tmpreg; \
									SET_BIT(RCC->APB1LENR, RCC_APB1LENR_USART3EN);\
									tmpreg = READ_BIT(RCC->APB1LENR, RCC_APB1LENR_USART3EN);\
									(void) tmpreg; \
									} while(0)

#define RCC_UART4_CLK_ENABLE()   do { \
									__IO uint32_t tmpreg; \
									SET_BIT(RCC->APB1LENR, RCC_APB1LENR_UART4EN);\
									tmpreg = READ_BIT(RCC->APB1LENR, RCC_APB1LENR_UART4EN);\
									(void) tmpreg; \
									} while(0)

#define RCC_UART5_CLK_ENABLE()   do { \
									__IO uint32_t tmpreg; \
									SET_BIT(RCC->APB1LENR, RCC_APB1LENR_UART5EN);\
									tmpreg = READ_BIT(RCC->APB1LENR, RCC_APB1LENR_UART5EN);\
									(void) tmpreg; \
									} while(0)


#define RCC_USART6_CLK_ENABLE()   do { \
									__IO uint32_t tmpreg; \
									SET_BIT(RCC->APB2ENR, RCC_APB2ENR_USART6EN);\
									tmpreg = READ_BIT(RCC->APB2ENR, RCC_APB2ENR_USART6EN);\
									(void) tmpreg; \
									} while(0)

//-----------------------------------------------------------------------------
class UartBase
{
private:
	USART_TypeDef * mUart;

	RingBuffer mRxBuffer;
	RingBuffer mTxBuffer;

	FuncType   mRxCallBack;

protected:
	void Init(USART_TypeDef * uart);

public:
	virtual void Init	() = 0;

	void IRQHandler		();

	void setRxCallBack	(FuncType callBack);

	std::string peek	();
	std::string read	(int16_t size);
	void write			(std::string value);

	char read			();
	void write			(char value);
};

//-----------------------------------------------------------------------------
class Uart1 : public UartBase
{
public:
	void Init() override;
};
//-----------------------------------------------------------------------------
class Uart3 : public UartBase
{
public:
	void Init() override;
};
//-----------------------------------------------------------------------------
extern Uart1 gUart1;
extern Uart3 gUart3;

#endif
