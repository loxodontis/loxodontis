/*
 * This file is part of the FX-4CR-V2 project.
 * See: https://github.com/f5bud/FX-4CR-V2
 *
 * Copyright (c) 2024 Daniel Nespoulous, F5BUD
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE. 
 */
//-----------------------------------------------------------------------------
//	TimerBase.h
//-----------------------------------------------------------------------------
#ifndef INC_TIMERBASE_H_
#define INC_TIMERBASE_H_

//-----------------------------------------------------------------------------
#include "GpioPin.h"

//-----------------------------------------------------------------------------
#define RCC_TIM1_CLK_ENABLE()	do { \
								__IO uint32_t tmpreg; \
								SET_BIT(RCC->APB2ENR, RCC_APB2ENR_TIM1EN);\
								tmpreg = READ_BIT(RCC->APB2ENR, RCC_APB2ENR_TIM1EN);\
								(void) tmpreg; \
								} while(0)

#define RCC_TIM2_CLK_ENABLE()	do { \
								__IO uint32_t tmpreg; \
								SET_BIT(RCC->APB1LENR, RCC_APB1LENR_TIM2EN);\
								tmpreg = READ_BIT(RCC->APB1LENR, RCC_APB1LENR_TIM2EN);\
								(void) tmpreg; \
								} while(0)

#define RCC_TIM3_CLK_ENABLE()	do { \
								__IO uint32_t tmpreg; \
								SET_BIT(RCC->APB1LENR, RCC_APB1LENR_TIM3EN);\
								tmpreg = READ_BIT(RCC->APB1LENR, RCC_APB1LENR_TIM3EN);\
								(void) tmpreg; \
								} while(0)

#define RCC_TIM4_CLK_ENABLE()	do { \
								__IO uint32_t tmpreg; \
								SET_BIT(RCC->APB1LENR, RCC_APB1LENR_TIM4EN);\
								tmpreg = READ_BIT(RCC->APB1LENR, RCC_APB1LENR_TIM4EN);\
								(void) tmpreg; \
								} while(0)

#define RCC_TIM5_CLK_ENABLE()	do { \
								__IO uint32_t tmpreg; \
								SET_BIT(RCC->APB1LENR, RCC_APB1LENR_TIM5EN);\
								tmpreg = READ_BIT(RCC->APB1LENR, RCC_APB1LENR_TIM5EN);\
								(void) tmpreg; \
								} while(0)

#define RCC_TIM6_CLK_ENABLE()	do { \
								__IO uint32_t tmpreg; \
								SET_BIT(RCC->APB1LENR, RCC_APB1LENR_TIM6EN);\
								tmpreg = READ_BIT(RCC->APB1LENR, RCC_APB1LENR_TIM6EN);\
								(void) tmpreg; \
								} while(0)

#define RCC_TIM7_CLK_ENABLE()	do { \
								__IO uint32_t tmpreg; \
								SET_BIT(RCC->APB1LENR, RCC_APB1LENR_TIM7EN);\
								tmpreg = READ_BIT(RCC->APB1LENR, RCC_APB1LENR_TIM7EN);\
								(void) tmpreg; \
								} while(0)

#define RCC_TIM12_CLK_ENABLE()	do { \
								__IO uint32_t tmpreg; \
								SET_BIT(RCC->APB1LENR, RCC_APB1LENR_TIM12EN);\
								tmpreg = READ_BIT(RCC->APB1LENR, RCC_APB1LENR_TIM12EN);\
								(void) tmpreg; \
								} while(0)

#define RCC_TIM13_CLK_ENABLE()	do { \
								__IO uint32_t tmpreg; \
								SET_BIT(RCC->APB1LENR, RCC_APB1LENR_TIM13EN);\
								tmpreg = READ_BIT(RCC->APB1LENR, RCC_APB1LENR_TIM13EN);\
								(void) tmpreg; \
								} while(0)

#define RCC_TIM14_CLK_ENABLE()	do { \
								__IO uint32_t tmpreg; \
								SET_BIT(RCC->APB1LENR, RCC_APB1LENR_TIM14EN);\
								tmpreg = READ_BIT(RCC->APB1LENR, RCC_APB1LENR_TIM14EN);\
								(void) tmpreg; \
								} while(0)

#define RCC_TIM23_CLK_ENABLE()	do { \
								__IO uint32_t tmpreg; \
								SET_BIT(RCC->APB1HENR, RCC_APB1HENR_TIM23EN);\
								tmpreg = READ_BIT(RCC->APB1HENR, RCC_APB1HENR_TIM23EN);\
								(void) tmpreg; \
								} while(0)

#define RCC_TIM24_CLK_ENABLE()	do { \
								__IO uint32_t tmpreg; \
								SET_BIT(RCC->APB1HENR, RCC_APB1HENR_TIM24EN);\
								tmpreg = READ_BIT(RCC->APB1HENR, RCC_APB1HENR_TIM24EN);\
								(void) tmpreg; \
								} while(0)

//-----------------------------------------------------------------------------
class TimerBase
{
public:
	void Init(TIM_TypeDef * timer);
};

//-----------------------------------------------------------------------------
#endif
