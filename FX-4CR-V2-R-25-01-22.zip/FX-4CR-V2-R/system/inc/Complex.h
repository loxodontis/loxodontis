/*
 * This file is part of the FX-4CR-V2 project.
 * See: https://github.com/f5bud/FX-4CR-V2
 *
 * Copyright (c) 2024 Daniel Nespoulous, F5BUD
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
//-----------------------------------------------------------------------------
//	Complex.h
//-----------------------------------------------------------------------------
#ifndef INC_COMPLEX_H_
#define INC_COMPLEX_H_

//-----------------------------------------------------------------------------
class Complex
{
private:
	float32_t mReal;
	float32_t mImag;

public:
	constexpr Complex(): mReal(0.0f), mImag(0.0f)	{	}

	constexpr Complex(const float32_t real): mReal(real), mImag(0.0f)	{	}

	constexpr Complex(const float32_t real, const float32_t imag): mReal(real), mImag(imag)	{	}

	constexpr Complex(const Complex & z): mReal(z.mReal), mImag(z.mImag)	{	}

	Complex & balance(float32_t pha, float32_t mag)
	{
		mReal = mReal + pha * mImag;											// Pha correction
		mImag = mImag * mag;													// Mag correction

		return *this;
	}

	float32_t real()
	{
		return mReal;
	}

	float32_t imag()
	{
		return mImag;
	}

	constexpr void real(float32_t real)
	{
		mReal = real;
	}

	constexpr void imag(float32_t imag)
	{
		mImag = imag;
	}

	Complex & operator = (const float32_t n)
	{
		mReal = n;
		mImag = 0.0f;

		return *this;
	}

	Complex & operator = (const Complex & z)
	{
		mReal = z.mReal;
		mImag = z.mImag;

		return *this;
	}

	Complex operator + (const float32_t n)
	{
		return Complex(mReal + n, mImag);
	}

	Complex operator + (const Complex &b)
	{
		return Complex(mReal + b.mReal, mImag + b.mImag);
	}

	Complex operator - (const float32_t n)
	{
		return Complex(mReal - n, mImag);
	}

	Complex operator - (const Complex &b)
	{
		return Complex(mReal - b.mReal, mImag - b.mImag);
	}

	Complex operator * (const float32_t n)
	{
		return Complex(mReal * n, mImag * n);
	}

	Complex operator * (const Complex &b)
	{
		return Complex
		(
			mReal * b.mReal - mImag * b.mImag,
			mReal * b.mImag + mImag * b.mReal
		);
	}

	Complex operator / (const Complex &b)
	{
//		temp.real = ((x.real * y.real) + (x.imag * y.imag)) / (y.real * y.real + y.imag * y.imag);
//		temp.imag = ((x.imag * y.real) - (x.real * y.imag)) / (y.real * y.real + y.imag * y.imag);

		return Complex
		(
			(mReal * b.mReal + mImag * b.mImag) / (b.mReal * b.mReal + b.mImag * b.mImag),
			(mImag * b.mReal - mReal * b.mImag) / (b.mReal * b.mReal + b.mImag * b.mImag)
		);
	}

	Complex conj()
	{
		return Complex(mReal, -mImag);
	}

	float32_t mag()
	{
		return sqrtf(mReal * mReal + mImag * mImag);
	}

	float32_t arg()
	{
		return atan2f(mImag, mReal);
	}
};

//-----------------------------------------------------------------------------
#endif
