/*
 * This file is part of the FX-4CR-V2 project.
 * See: https://github.com/f5bud/FX-4CR-V2
 *
 * Copyright (c) 2024 Daniel Nespoulous, F5BUD
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE. 
 */
//-----------------------------------------------------------------------------
//	LcdService.cpp
//-----------------------------------------------------------------------------
#include "LcdService.h"
#include "DmaBase.h"
#include "SpiBase.h"

#include "fonts/Liquid12pt.h"
#include "fonts/Symbole6pt.h"

#include "fonts/Trebuchet5pt.h"
#include "fonts/Trebuchet6pt.h"
#include "fonts/Trebuchet9pt.h"

//-----------------------------------------------------------------------------
#define WriteTXDR(data) *((volatile uint8_t *) &(SPI2->TXDR)) = (data);

//-----------------------------------------------------------------------------
#define LCD_SLPOUT		0x11
#define LCD_INVON		0x21
#define LCD_DISPON		0x29
#define LCD_COLADDRSET	0x2A
#define LCD_PAGEADDRSET	0x2B
#define LCD_MEMORYWRITE	0x2C
#define LCD_MADCTL		0x36
#define LCD_COLMOD		0x3A
#define LCD_WRDISBV		0x51
#define LCD_WRCTRLD		0x53
#define LCD_WRCACE		0x55
#define LCD_WRCABCMB	0x5E
#define LCD_VCOMS		0xBB
#define LCD_CABCCTRL	0xC7
#define LCD_PVGAMCTRL	0xE0
#define LCD_NVGAMCTRL	0xE1

//-----------------------------------------------------------------------------
static const uint8_t sLcdInit[] =
{
	LCD_MADCTL,			1, 0x70,						// orientation
	LCD_COLMOD,			1, 0x05,						// format of RGB
	LCD_VCOMS,			1, 0x32,						// Vcom = 1.32V

	LCD_PVGAMCTRL,		14, 0xD0, 0x08, 0x0E, 0x09, 0x09, 0x15, 0x31, 0x33, 0x48, 0x17, 0x14, 0x15, 0x31, 0x34,
	LCD_NVGAMCTRL,		14, 0xD0, 0x08, 0x0E, 0x09, 0x09, 0x15, 0x31, 0x33, 0x48, 0x17, 0x14, 0x15, 0x31, 0x34,

	LCD_SLPOUT, 		120,							// Sleep Out (5ms min)
	LCD_INVON,			102,
	LCD_DISPON,	 		102,
	LCD_COLADDRSET,		4, 0, 0, 0x01, 0x3F,			// 0, 320 - 1
	LCD_PAGEADDRSET,	4, 0, 0, 0x00, 0xEF,			// 0, 240 - 1
	LCD_MEMORYWRITE,	102,
	0
};

//-----------------------------------------------------------------------------
static LcdService *sLcdService;

static DMAMEM uint16_t sLcdBuffer[LCD_HEIGHT][LCD_WIDTH];
static DMAMEM int32_t  sBaseLine;

//-----------------------------------------------------------------------------
extern "C" void DMA1_Stream4_IRQHandler()
{
	sLcdService->IRQHandler();
}
//-----------------------------------------------------------------------------
void LcdService::Init(Thread &thread)
{
	sLcdService = this;
	mMainThread = &thread;

	SpiBase().Init(SPI2);
	DmaBase().Init(DMA1);													// init global

	GpioPin(GPIOB, 13, eAltMode, ePushPull, eHi2Speed, ePullNone, 5);		// sck
	GpioPin(GPIOB, 15, eAltMode, ePushPull, eHi2Speed, ePullNone, 5);		// mosi

	mWriteMode = eNone;
	sBaseLine = LCD_HEIGHT;													// to skeep IRQHandler

	InitDma();
	InitSpi();
	InitLcd();
}
//-----------------------------------------------------------------------------
void LcdService::InitSpi()
{
	SPI2->CR1  = 0;
	SPI2->CR2  = 0;
	SPI2->CFG1 = 0;
	SPI2->CFG2 = 0;

	SET_BIT(SPI2->CR1,  SPI_CR1_SSI);											// 1: forced onto the peripheral SS
	SET_BIT(SPI2->CFG1, SPI_CFG1_TXDMAEN);										// 1: Tx DMA enabled
	SET_BIT(SPI2->CFG2, SPI_CFG2_AFCNTR);										// 1: the peripheral keeps always control
	SET_BIT(SPI2->CFG2, SPI_CFG2_SSM);											// 1: SS input value is determined by the SSI bit
	SET_BIT(SPI2->CFG2, SPI_CFG2_CPOL);											// 1: SCK signal is at 1 when idle
	SET_BIT(SPI2->CFG2, SPI_CFG2_CPHA);											// 1: the second clock transition is the first data capture edge
	SET_BIT(SPI2->CFG2, SPI_CFG2_MASTER);										// 1: SPI Master

	MODIFY_REG(SPI2->CFG2, SPI_CFG2_COMM,  1UL << SPI_CFG2_COMM_Pos);			// 1: simplex transmitter
}
//-----------------------------------------------------------------------------
void LcdService::InitDma()
{
//	NVIC_SetPriority(DMA1_Stream4_IRQn, 16);									// 5 is for SysTick_IRQn
	NVIC_EnableIRQ  (DMA1_Stream4_IRQn);

	DMAMUX1_Channel4->CCR = 40UL;												// Channel(n) = Stream(n) spi2_tx_dma

	DMA1_Stream4->CR  = 0UL;
	DMA1_Stream4->FCR = 0UL;
	DMA1_Stream4->PAR = (uint32_t) &SPI2->TXDR;

	MODIFY_REG(DMA1_Stream4->CR, DMA_SxCR_DIR, 1UL << DMA_SxCR_DIR_Pos);		// Transfer direction: 01: Memory-to-peripheral

	SET_BIT(DMA1_Stream4->CR, DMA_SxCR_TCIE);									// 1: TC interrupt enabled
	SET_BIT(DMA1_Stream4->CR, DMA_SxCR_MINC);									// 1: Memory address pointer incremented
}
//-----------------------------------------------------------------------------
void LcdService::InitLcd()
{
	mReset.setLow();
	mMainThread->Delay(2);
	mReset.setHigh();

	mCs.setLow();																// select shipSet
	mMainThread->Delay(150);													// 5 + 120mS minimum

	WriteBlock(sLcdInit);
}
//-----------------------------------------------------------------------------
uint16_t *LcdService::getLine(int16_t y)
{
	return sLcdBuffer[y];
}
//-----------------------------------------------------------------------------
void LcdService::IRQHandler()													// from DMA1_Stream4
{
	DMA1->HIFCR = 0b0000'000000'111101;											// TCIF4 HTIF4 TEIF4 DMEIF4 FEIF4

	if (sBaseLine < 3L * 80L)
	{
		WriteWord(getLine(sBaseLine), LCD_WIDTH * 80L);

		sBaseLine = sBaseLine + 80L;
	}
}
//-----------------------------------------------------------------------------
void LcdService::DrawBuffer()
{
	while(DMA1_Stream4->CR & DMA_SxCR_EN)										// 0: SxCR_EN dma ended
	{
		asm volatile ("nop");													// generate a delay
	}

	sBaseLine = 0L;

	IRQHandler();																// start for 3 times
}
//-----------------------------------------------------------------------------
void LcdService::ClearBuffer(int16_t y, int16_t h, uint16_t color)
{
	uint16_t *ptr = getLine(y);
	int32_t count = h * LCD_WIDTH;

	while (count > 0)
	{
		*(ptr ++) = color;
		count --;
	}
}
//-----------------------------------------------------------------------------
void LcdService::WriteByte(const uint8_t *data, int32_t count)
{
	while(DMA1_Stream4->CR & DMA_SxCR_EN)										// 0: SxCR_EN dma ended
	{
		asm volatile ("nop");													// generate a delay
	}

	if (mWriteMode != eByte)
	{
		mWriteMode = eByte;

		MODIFY_REG(DMA1_Stream4->CR, DMA_SxCR_MSIZE, 0UL << DMA_SxCR_MSIZE_Pos);	// 0: Memory data    : 8-bit
		MODIFY_REG(DMA1_Stream4->CR, DMA_SxCR_PSIZE, 0UL << DMA_SxCR_PSIZE_Pos);	// 0: Peripheral data: 8-bit

		CLEAR_BIT (SPI2->CR1,  SPI_CR1_SPE);										// 0: serial peripheral disable
		MODIFY_REG(SPI2->CFG1, SPI_CFG1_DSIZE, 7UL << SPI_CFG1_DSIZE_Pos);			// 7: 8-bits
	}

	DMA1_Stream4->M0AR = (uint32_t) data;
	DMA1_Stream4->NDTR = count;

	SET_BIT(DMA1_Stream4->CR, DMA_SxCR_EN);											// 1: Stream enabled

	SET_BIT(SPI2->CR1,  SPI_CR1_SPE);												// 1: serial peripheral enabled
	SET_BIT(SPI2->CR1,  SPI_CR1_CSTART);											// 1: master transfer is on-going
}
//-----------------------------------------------------------------------------
void LcdService::WriteWord(const uint16_t *data, int32_t count)
{
	while(DMA1_Stream4->CR & DMA_SxCR_EN)											// 0: SxCR_EN dma ended
	{
		asm volatile ("nop");														// generate a delay
	}

	if (mWriteMode != eWord)
	{
		mWriteMode = eWord;

		MODIFY_REG(DMA1_Stream4->CR, DMA_SxCR_MSIZE, 1UL << DMA_SxCR_MSIZE_Pos);	// 1: Memory data    : 16-bit
		MODIFY_REG(DMA1_Stream4->CR, DMA_SxCR_PSIZE, 1UL << DMA_SxCR_PSIZE_Pos);	// 1: Peripheral data: 16-bit

		CLEAR_BIT (SPI2->CR1,  SPI_CR1_SPE);										// 0: serial peripheral disable
		MODIFY_REG(SPI2->CFG1, SPI_CFG1_DSIZE, 15UL << SPI_CFG1_DSIZE_Pos);			// 15: 16-bits
	}

	DMA1_Stream4->M0AR = (uint32_t) data;
	DMA1_Stream4->NDTR = count;

	SET_BIT(DMA1_Stream4->CR, DMA_SxCR_EN);											// 1: Stream enabled

	SET_BIT(SPI2->CR1,  SPI_CR1_SPE);												// 1: serial peripheral enabled
	SET_BIT(SPI2->CR1,  SPI_CR1_CSTART);											// 1: master transfer is on-going
}
//-----------------------------------------------------------------------------
void LcdService::WriteBlock(const uint8_t *data)
{
	while (*(data))
	{
		mDc.setLow();															// Cmde mode

		WriteByte(data ++, 1);

		for (int16_t i = 0; i < 5000; i ++)										// for DC transfert
		{
			while(DMA1_Stream4->CR & DMA_SxCR_EN)								// 0: SxCR_EN dma ended
			{
				asm volatile ("nop");											// generate a delay
			}

			asm volatile ("nop");												// generate a delay
		}

		mDc.setHigh();															// Data mode

		uint32_t count = *(data ++);

		if (count < 100L)
		{
			WriteByte(data, count);

			for (int16_t i = 0; i < 5000; i ++)									// for DC transfert
			{
				while(DMA1_Stream4->CR & DMA_SxCR_EN)							// 0: SxCR_EN dma ended
				{
					asm volatile ("nop");										// generate a delay
				}

				asm volatile ("nop");											// generate a delay
			}

			data += count;
			continue;
		}

		mMainThread->Delay(100L - count);										// long delay
	}
}
//-----------------------------------------------------------------------------
//#############################################################################
//-----------------------------------------------------------------------------
int16_t LcdService::getTextWidth(const char *text)
{
	int16_t result = 0;

	do
	{
		if (*(text) > mLcdFont->last) continue;
		if (*(text) < mLcdFont->first) continue;

		LCDGlyph *glyph = mLcdFont->glyph + (*(text) - mLcdFont->first);

		result += glyph->xAdvance;
	}
	while (*(text ++));

	return result;
}
//-----------------------------------------------------------------------------
void LcdService::DrawText(const char *text, int16_t xGapp, int16_t yGapp, int16_t width, eAlign align)
{
	int16_t textWidth = getTextWidth(text);

	switch (align)
	{
	case eRight:
		while (textWidth > width)
		{
			textWidth = getTextWidth(text ++);									// skeep begin of string
		}

		xGapp += (width - textWidth);
		break;

	case eCenter:
		xGapp += ((width - textWidth) / 2);

	default:
		break;
	}

	while (width > 0)
	{
		char c = *(text ++);

		if (c == 0) break;
		if (c > mLcdFont->last) continue;
		if (c < mLcdFont->first) continue;

		LCDGlyph *glyph = mLcdFont->glyph + (c - mLcdFont->first);
		uint8_t *bitmap = mLcdFont->bitmap + glyph->offset;

		if (c != '_')															// fixed size space
		{
			uint8_t  bits = 0, bit = 0;
			int16_t yo = yGapp + glyph->yOffset;
			int16_t xo = xGapp + glyph->xOffset;

			for (int16_t yy = yo; yy < yo + glyph->height; yy ++)
			{
				uint16_t *ptr = getLine(yy) + xo;

				for (int16_t xx = xo; xx < xo + glyph->width; xx ++)
				{
					if ((bit ++ & 0x07) == 0) bits = *(bitmap ++);

					if (bits & 0x80) *(ptr) = mFgColor;

					bits <<= 1;
					ptr ++;
				}
			}
		}

		xGapp += glyph->xAdvance;
		width -= glyph->xAdvance;
	}
}
//-----------------------------------------------------------------------------
void LcdService::DrawPixel(int16_t x, int16_t y, uint16_t color)
{
	getLine(y)[x] = color;
}
//-----------------------------------------------------------------------------
void LcdService::DrawVLine(int16_t x, int16_t y, int16_t h, uint16_t color)
{
	while (h > 0)
	{
		getLine(y ++)[x] = color;
		h --;
	}
}
//-----------------------------------------------------------------------------
void LcdService::DrawHLine(int16_t x, int16_t y, int16_t w, uint16_t color)
{
	uint16_t* ptr = getLine(y) + x;

	while (w > 0)
	{
		*(ptr ++) = color;
		w --;
	}
}
//-----------------------------------------------------------------------------
void LcdService::DrawRect(int16_t x, int16_t y, int16_t w, int16_t h, uint16_t color)
{
	while (h > 0)
	{
		DrawHLine(x, y ++, w, color);
		h --;
	}
}
//-----------------------------------------------------------------------------
void LcdService::DrawBox(int16_t x, int16_t y, int16_t w, int16_t h)
{
	if (mBdColor == mBgColor)
	{
		DrawRect(x, y, w, h, mBgColor);
	}
	else
	{
		DrawRect (x + 1, y + 1, w - 2, h - 2, mBgColor);

		DrawHLine(x + 2, y,         w - 4, mBdColor);
		DrawHLine(x + 2, y + h - 1, w - 4, mBdColor);

		DrawVLine(x,         y + 2, h - 4, mBdColor);
		DrawVLine(x + w - 1, y + 2, h - 4, mBdColor);

		DrawPixel(x + 1,     y + 1,        mBdColor);
		DrawPixel(x + w - 2, y + 1,        mBdColor);

		DrawPixel(x + 1,     y + h - 2,    mBdColor);
		DrawPixel(x + w - 2, y + h - 2,    mBdColor);
	}
}
//-----------------------------------------------------------------------------
void LcdService::MoveTo(int16_t x, int16_t y)
{
	mX0 = x;
	mY0 = y;
}
//-----------------------------------------------------------------------------
void LcdService::LineTo(int16_t x, int16_t y, uint16_t color)
{
	int16_t dx = std::abs(x - mX0);
	int16_t dy = std::abs(y - mY0);

	int16_t	sx = (mX0 < x) ? 1 : -1;
	int16_t	sy = (mY0 < y) ? 1 : -1;

	int16_t err = dx - dy;

	for (;;)
	{
		DrawPixel(mX0, mY0, color);

		if (mX0 == x && mY0 == y) break;

		int16_t e2 = err << 1;

		if (e2 > -dy)
		{
			err = err - dy;
			mX0 = mX0 + sx;
		}

		if (e2 < dx)
		{
			err = err + dx;
			mY0 = mY0 + sy;
		}
	}
}
//-----------------------------------------------------------------------------
