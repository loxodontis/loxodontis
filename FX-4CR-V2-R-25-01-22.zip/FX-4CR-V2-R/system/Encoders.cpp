/*
 * This file is part of the FX-4CR-V2 project.
 * See: https://github.com/f5bud/FX-4CR-V2
 *
 * Copyright (c) 2024 Daniel Nespoulous, F5BUD
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE. 
 */
//-----------------------------------------------------------------------------
//	Encoders.cpp
//-----------------------------------------------------------------------------
#include "Encoders.h"

//-----------------------------------------------------------------------------
void EncoderAf::Init()
{
	GpioPin(GPIOD, 12, eAltMode, eOpenDrain, eLowSpeed, ePullUp, 2);			// (TIM4_CH1) Af encoder
	GpioPin(GPIOD, 13, eAltMode, eOpenDrain, eLowSpeed, ePullUp, 2);			// (TIM4_CH2)

	EncoderBase::Init(TIM4, false);
}
//-----------------------------------------------------------------------------
void EncoderTune::Init()
{
	GpioPin(GPIOA, 15, eAltMode, eOpenDrain, eLowSpeed, ePullUp, 1);			// (TIM2_CH1) Tune encoder
	GpioPin(GPIOB,  3, eAltMode, eOpenDrain, eLowSpeed, ePullUp, 1);			// (TIM2_CH2)

	EncoderBase::Init(TIM2, true);
}
//-----------------------------------------------------------------------------
void EncoderBase::Init(TIM_TypeDef * timer, bool flag)
{
	TimerBase::Init(timer);

	mTim = timer;

	mTim->CR1   = 0;
	mTim->CCER  = 0;
	mTim->SMCR  = 0;
	mTim->CCMR1 = 0;

	if (flag)
	{
		SET_BIT(mTim->CCER, TIM_CCER_CC2P);										// 1: OC2 active low
		MODIFY_REG(mTim->SMCR, TIM_SMCR_SMS, 0x02 << TIM_SMCR_SMS_Pos);			// 0001: Encoder mode 2
	}
	else
		MODIFY_REG(mTim->SMCR, TIM_SMCR_SMS, 0x01 << TIM_SMCR_SMS_Pos);			// 0001: Encoder mode 1

	MODIFY_REG(mTim->CCMR1, TIM_CCMR1_CC1S, 0x01 << TIM_CCMR1_CC1S_Pos);		// 01: CC1 channel is configured as input, IC1 is mapped on TI1
	MODIFY_REG(mTim->CCMR1, TIM_CCMR1_CC2S, 0x01 << TIM_CCMR1_CC2S_Pos);		// 01: CC2 channel is configured as input, IC2 is mapped on TI2

	MODIFY_REG(mTim->CCMR1, TIM_CCMR1_OC1M, 0x03 << TIM_CCMR1_OC1M_Pos);		// 0011: Toggle - OC1REF toggles when TIMx_CNT=TIMx_CCR1
	MODIFY_REG(mTim->CCMR1, TIM_CCMR1_OC2M, 0x03 << TIM_CCMR1_OC2M_Pos);		// 0011: Toggle - OC1REF toggles when TIMx_CNT=TIMx_CCR2

	mTim->CNT = 0;																// 0: counter = 0
	mTim->EGR = 1;																// 1: Reinitialize counter
	mTim->CR1 = 1;																// 1: Counter enabled
}
//-----------------------------------------------------------------------------
int32_t EncoderBase::getValue()
{
	int32_t result = mTim->CNT;

	mTim->CNT = 0;

	return result;
}
//-----------------------------------------------------------------------------
bool EncoderBase::isChanged()
{
	return mTim->CNT != 0;
}
//-----------------------------------------------------------------------------
