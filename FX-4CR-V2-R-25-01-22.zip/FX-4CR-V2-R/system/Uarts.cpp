/*
 * This file is part of the FX-4CR-V2 project.
 * See: https://github.com/f5bud/FX-4CR-V2
 *
 * Copyright (c) 2024 Daniel Nespoulous, F5BUD
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE. 
 */
//-----------------------------------------------------------------------------
//	Uarts.cpp
//-----------------------------------------------------------------------------
#include "Uarts.h"

Uart1 gUart1;
Uart3 gUart3;

//-----------------------------------------------------------------------------
extern "C" void USART1_IRQHandler()
{
	gUart1.IRQHandler();
}
//-----------------------------------------------------------------------------
extern "C" void USART3_IRQHandler()
{
	gUart3.IRQHandler();
}
//-----------------------------------------------------------------------------
void Uart1::Init()
{
	GpioPin(GPIOA,  9, eAltMode, eOpenDrain, eLowSpeed, ePullNone, 7);	// Tx
	GpioPin(GPIOA, 10, eAltMode, eOpenDrain, eLowSpeed, ePullNone, 7);	// Rx

	UartBase::Init(USART1);

	NVIC_SetPriority(USART1_IRQn, 4);											// 5 is for SysTick_IRQn
	NVIC_EnableIRQ  (USART1_IRQn);
}
//-----------------------------------------------------------------------------
void Uart3::Init()
{
	GpioPin(GPIOD, 8, eAltMode, eOpenDrain, eLowSpeed, ePullNone, 7);	// Tx
	GpioPin(GPIOD, 9, eAltMode, eOpenDrain, eLowSpeed, ePullNone, 7);	// Rx

	UartBase::Init(USART3);

	NVIC_SetPriority(USART3_IRQn, 4);											// 5 is for SysTick_IRQn
	NVIC_EnableIRQ  (USART3_IRQn);
}
//-----------------------------------------------------------------------------
void UartBase::Init(USART_TypeDef * uart)
{
	mUart = uart;

	if 		(mUart == USART1) RCC_USART1_CLK_ENABLE();
	else if (mUart == USART2) RCC_USART2_CLK_ENABLE();
	else if (mUart == USART3) RCC_USART3_CLK_ENABLE();
//	else if (mUart == USART4) RCC_USART4_CLK_ENABLE();
//	else if (mUart == USART5) RCC_USART5_CLK_ENABLE();
	else if (mUart == USART6) RCC_USART6_CLK_ENABLE();

	mUart->CR1 = 0;
	mUart->CR2 = 0;
	mUart->CR3 = 0;

	mUart->ICR = 0xFFFF'FFFF;										// clear all

	mUart->BRR = (PCLK2 + SERIAL_SPEED / 2L) / SERIAL_SPEED;

	SET_BIT(mUart->CR3, USART_CR3_OVRDIS);							// 1: Overrun functionality is disabled

	SET_BIT(mUart->CR1, USART_CR1_RXNEIE_RXFNEIE);					// 1: USART interrupt generated whenever ORE = 1 or RXFNE = 1

	SET_BIT(mUart->CR1, USART_CR1_FIFOEN);							// 1: FIFO mode is enabled
	SET_BIT(mUart->CR1, USART_CR1_TE);								// 1: Transmitter is enabled
	SET_BIT(mUart->CR1, USART_CR1_RE);								// 1: Receiver is enabled
	SET_BIT(mUart->CR1, USART_CR1_UE);								// 1: USART enabled
}
//-----------------------------------------------------------------------------
void UartBase::IRQHandler()
{
	if (READ_BIT(mUart->ISR, USART_ISR_RXNE_RXFNE))					// 1: Received data is ready to be read
	{
		while (READ_BIT(mUart->ISR, USART_ISR_RXNE_RXFNE))
		{
			mRxBuffer.write((char) mUart->RDR);
		}

		if (mRxCallBack) mRxCallBack();								// received data signal
	}

	if (READ_BIT(mUart->ISR, USART_ISR_TXE_TXFNF))					// 1: Transmit FIFO is not full
	{
		char c = mTxBuffer.read();

		if (c > '\0')
			mUart->TDR = c;
		else
			CLEAR_BIT(mUart->CR1, USART_CR1_TXEIE_TXFNFIE); 		// 0: stop interrupt
	}
}
//-----------------------------------------------------------------------------
void UartBase::setRxCallBack(FuncType callBack)
{
	mRxCallBack = callBack;
}
//-----------------------------------------------------------------------------
std::string UartBase::peek()
{
	return mRxBuffer.peek();
}
//-----------------------------------------------------------------------------
std::string UartBase::read(int16_t size)
{
	return mRxBuffer.read(size);
}
//-----------------------------------------------------------------------------
void UartBase::write(std::string value)
{
	mTxBuffer.write(value);

	SET_BIT(mUart->CR1, USART_CR1_TXEIE_TXFNFIE); 					// 1: USART interrupt generated when TXFNF = 1
}
//-----------------------------------------------------------------------------
char UartBase::read()
{
	return mRxBuffer.read();
}
//-----------------------------------------------------------------------------
void UartBase::write(char value)
{
	mTxBuffer.write(value);

	SET_BIT(mUart->CR1, USART_CR1_TXEIE_TXFNFIE); 					// 1: USART interrupt generated when TXFNF = 1
}
//-----------------------------------------------------------------------------

//#############################################################################
//	Used for debug only !!! redirect I/O to SerialA
//#############################################################################
#ifdef DEBUG
//-----------------------------------------------------------------------------
extern "C" int __io_putchar(int ch)
{
	gUart1.write(ch);

	return ch;
}
//-----------------------------------------------------------------------------
extern "C" int __io_getchar(void)
{
	return gUart1.read();
}
//-----------------------------------------------------------------------------
#endif
