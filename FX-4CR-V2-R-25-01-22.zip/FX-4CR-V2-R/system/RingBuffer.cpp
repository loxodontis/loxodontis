/*
 * This file is part of the FX-4CR-V2 project.
 * See: https://github.com/f5bud/FX-4CR-V2
 *
 * Copyright (c) 2024 Daniel Nespoulous, F5BUD
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
//-----------------------------------------------------------------------------
//	RingBuffer.cpp
//-----------------------------------------------------------------------------
#include "RingBuffer.h"

//-----------------------------------------------------------------------------
std::string RingBuffer::peek()
{
	return mBuffer;
}
//-----------------------------------------------------------------------------
std::string RingBuffer::read(int16_t count)
{
	std::string result;

	if (count <= (int16_t) mBuffer.length())
	{
		result = mBuffer.substr(0, count);
		mBuffer.erase(0, count);
	}

	return result;
}
//-----------------------------------------------------------------------------
void RingBuffer::write(std::string value)
{
	mBuffer.append(value);
}
//-----------------------------------------------------------------------------
char RingBuffer::read()
{
	char result = mBuffer[0];

	if (mBuffer.length() > 0)
		mBuffer.erase(0, 1);

	return result;
}
//-----------------------------------------------------------------------------
void RingBuffer::write(char value)
{
	mBuffer.append(1, value);
}
//-----------------------------------------------------------------------------
