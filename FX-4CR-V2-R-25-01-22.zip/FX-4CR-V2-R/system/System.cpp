/*
 * This file is part of the FX-4CR-V2 project.
 * See: https://github.com/f5bud/FX-4CR-V2
 *
 * Copyright (c) 2024 Daniel Nespoulous, F5BUD
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE. 
 */
//-----------------------------------------------------------------------------
//	System.h
//-----------------------------------------------------------------------------
#include "System.h"

//-----------------------------------------------------------------------------
//	SystemClockSetup
//-----------------------------------------------------------------------------
static void configPll1()
{
	MODIFY_REG(RCC->PLLCKSELR, RCC_PLLCKSELR_DIVM1, 5UL << RCC_PLLCKSELR_DIVM1_Pos);	// 25 / 5 * 192 / 2 = 480Mhz

	MODIFY_REG(RCC->PLL1DIVR,  RCC_PLL1DIVR_N1, 191UL << RCC_PLL1DIVR_N1_Pos);			// (n - 1)
	MODIFY_REG(RCC->PLL1DIVR,  RCC_PLL1DIVR_P1,   1UL << RCC_PLL1DIVR_P1_Pos);			// (n - 1) (480Mhz)  CPU
	MODIFY_REG(RCC->PLL1DIVR,  RCC_PLL1DIVR_Q1,  24UL << RCC_PLL1DIVR_Q1_Pos);			// (n - 1) (38.4Mhz) SPI 19.2Mbits/s
//	MODIFY_REG(RCC->PLL1DIVR,  RCC_PLL1DIVR_R1,   1UL << RCC_PLL1DIVR_R1_Pos);			// (n - 1) not use

	MODIFY_REG(RCC->PLLCFGR, RCC_PLLCFGR_PLL1RGE, RCC_PLLCFGR_PLL1RGE_3);

	SET_BIT(RCC->PLLCFGR, RCC_PLLCFGR_DIVP1EN);											// 1: pll1_p_ck output is enabled
	SET_BIT(RCC->PLLCFGR, RCC_PLLCFGR_DIVQ1EN);											// 1: pll1_q_ck output is enabled
//	SET_BIT(RCC->PLLCFGR, RCC_PLLCFGR_DIVR1EN);											// 1: pll1_r_ck output is disable

	SET_BIT(RCC->CR, RCC_CR_PLL1ON);													// Enable PLL
	while(READ_BIT(RCC->CR, RCC_CR_PLL1RDY) == 0);										// wait for PPL to be enabled
}
//-----------------------------------------------------------------------------
static void configPll2()
{
	// M:13, N:409, P:8, Freq: 98.317307

	MODIFY_REG(RCC->PLLCKSELR, RCC_PLLCKSELR_DIVM2, 13UL << RCC_PLLCKSELR_DIVM2_Pos);

	MODIFY_REG(RCC->PLL2DIVR,  RCC_PLL2DIVR_N2, 408UL << RCC_PLL2DIVR_N2_Pos);			// (n - 1)
	MODIFY_REG(RCC->PLL2DIVR,  RCC_PLL2DIVR_P2,   7UL << RCC_PLL2DIVR_P2_Pos);			// (n - 1) (98.317307 -> 96012) SAI
//	MODIFY_REG(RCC->PLL2DIVR,  RCC_PLL2DIVR_Q2,   1UL << RCC_PLL2DIVR_Q2_Pos);			// (n - 1) not use
//	MODIFY_REG(RCC->PLL2DIVR,  RCC_PLL2DIVR_R2,   1UL << RCC_PLL2DIVR_R2_Pos);			// (n - 1) not use

//	MODIFY_REG(RCC->PLLCFGR, RCC_PLLCFGR_PLL2RGE, RCC_PLLCFGR_PLL2RGE_2);

	SET_BIT(RCC->PLLCFGR, RCC_PLLCFGR_DIVP2EN);											// 1: pll2_p_ck output is enabled
//	SET_BIT(RCC->PLLCFGR, RCC_PLLCFGR_DIVQ2EN);											// 1: pll2_q_ck output is disable
//	SET_BIT(RCC->PLLCFGR, RCC_PLLCFGR_DIVR2EN);											// 1: pll2_r_ck output is disable

	SET_BIT(RCC->CR, RCC_CR_PLL2ON);													// Enable PLL
	while(READ_BIT(RCC->CR, RCC_CR_PLL2RDY) == 0);										// wait for PPL to be enabled
}
//-----------------------------------------------------------------------------
static void configPll3()
{
	MODIFY_REG(RCC->PLLCKSELR, RCC_PLLCKSELR_DIVM3, 20UL << RCC_PLLCKSELR_DIVM3_Pos);	// 25 / 20 * 120 / 50 = 3Mhz

	MODIFY_REG(RCC->PLL3DIVR,  RCC_PLL3DIVR_N3, 119UL << RCC_PLL3DIVR_N3_Pos);			// (n - 1)
//	MODIFY_REG(RCC->PLL3DIVR,  RCC_PLL3DIVR_P3,   1UL << RCC_PLL3DIVR_P3_Pos);			// (n - 1) not use
//	MODIFY_REG(RCC->PLL3DIVR,  RCC_PLL3DIVR_Q3,   1UL << RCC_PLL3DIVR_Q3_Pos);			// (n - 1) not use (possible USB port !!!)
	MODIFY_REG(RCC->PLL3DIVR,  RCC_PLL3DIVR_R3,   9UL << RCC_PLL3DIVR_R3_Pos);			// (n - 1) (15Mhz) ADC

//	MODIFY_REG(RCC->PLLCFGR, RCC_PLLCFGR_PLL3RGE, RCC_PLLCFGR_PLL3RGE_2);
	SET_BIT (RCC->PLLCFGR, RCC_PLLCFGR_PLL3VCOSEL);										// 1: Medium VCO range: 150 to 420 MHz

//	SET_BIT(RCC->PLLCFGR, RCC_PLLCFGR_DIVP3EN);											// 1: pll3_p_ck output is enabled
//	SET_BIT(RCC->PLLCFGR, RCC_PLLCFGR_DIVQ3EN);											// 1: pll3_q_ck output is enabled
	SET_BIT(RCC->PLLCFGR, RCC_PLLCFGR_DIVR3EN);											// 1: pll3_r_ck output is enabled

	SET_BIT(RCC->CR, RCC_CR_PLL3ON);													// Enable PLL
	while(READ_BIT(RCC->CR, RCC_CR_PLL3RDY) == 0);										// wait for PPL to be enabled
}
//-----------------------------------------------------------------------------
void SystemClockSetup()
{
	RCC_SYSCFG_CLK_ENABLE();

	CLEAR_BIT(PWR->CR3, PWR_CR3_SCUEN);												// 0: Supply configuration update locked.

	MODIFY_REG(PWR->D3CR, PWR_D3CR_VOS, 3L << PWR_D3CR_VOS_Pos);					// 11: Scale 1
	while((PWR->D3CR & PWR_D3CR_VOSRDY) != PWR_D3CR_VOSRDY);						// Wait for VOS to be ready

// 2) Oscillator initialisation

	SET_BIT(RCC->CR, RCC_CR_HSEON);													// Enable HSE
	while (READ_BIT(RCC->CR, RCC_CR_HSERDY) == 0);									// Wait until HSE is ready

	MODIFY_REG(RCC->CFGR, RCC_CFGR_SW, RCC_CFGR_SW_HSE);							// 010: HSE used as system clock (hse_ck)
	while(READ_BIT(RCC->CFGR, RCC_CFGR_SWS) != RCC_CFGR_SWS_HSE);

// 3) Pll init

	RCC->PLLCFGR = 0UL;
	RCC->PLLCKSELR = 0UL;

	SET_BIT(RCC->PLLCKSELR, RCC_PLLCKSELR_PLLSRC_HSE);								// HSE selected as PLL clock

	configPll1();
	configPll2();
	configPll3();

// 4) Clock initialization

	RCC->D1CFGR = 0UL;
	RCC->D2CFGR = 0UL;
	RCC->D3CFGR = 0UL;

	RCC->D3CCIPR  = 0UL;
	RCC->D2CCIP1R = 0UL;															// 000: SPI123 = pll1_q_ck (120Mhz)
	RCC->D2CCIP2R = 0UL;															//  00: USART1 = rcc_pclk2, USART3, I2C123 = rcc_pclk1 (120Mhz)

	MODIFY_REG(RCC->D1CFGR,   RCC_D1CFGR_HPRE,       RCC_D1CFGR_HPRE_DIV4);			// 1001: rcc_hclk3 = 480 / 4 (120Mhz)
	MODIFY_REG(RCC->D3CCIPR,  RCC_D3CCIPR_ADCSEL,    RCC_D3CCIPR_ADCSEL_0);			//   01: pll3_r_ck (15Mhz)
	MODIFY_REG(RCC->D2CCIP1R, RCC_D2CCIP1R_SAI1SEL,  RCC_D2CCIP1R_SAI1SEL_0);		//  001: pll2_p_ck (98.317307Mhz)

	MODIFY_REG(RCC->CFGR, RCC_CFGR_SW, RCC_CFGR_SW_PLL1);							// 011: PLL1 selected as system clock
	while(READ_BIT(RCC->CFGR, RCC_CFGR_SWS) != RCC_CFGR_SWS_PLL1);

	SystemCoreClockUpdate();
	SysTick_Config(SystemCoreClock / 1000);											// one tick per ms

	NVIC_EnableIRQ  (SysTick_IRQn);
}
//-----------------------------------------------------------------------------
void SystemCacheEnable()
{
/*
	ITCMRAM (xrw)  : ORIGIN = 0x00000000, LENGTH = 64K
	DTCMRAM (xrw)  : ORIGIN = 0x20000000, LENGTH = 128K		// ._user_heap_stack
	RAM_D1  (xrw)  : ORIGIN = 0x24000000, LENGTH = 512K		// .data, .bss
	RAM_D2  (xrw)  : ORIGIN = 0x30000000, LENGTH = 320K		// .NoBuffered
	RAM_D3  (xrw)  : ORIGIN = 0x38000000, LENGTH = 64K

	ARM_MPU_RASR(DisableExec, AccessPermission, TypeExtField, IsShareable, IsCacheable, IsBufferable, SubRegionDisable, Size)
*/
	ARM_MPU_SetRegionEx(0UL, 0x30000000UL, ARM_MPU_RASR(1UL, ARM_MPU_AP_FULL, 0UL, 1UL, 1UL, 0UL, 0UL, ARM_MPU_REGION_SIZE_512KB));

	ARM_MPU_Enable(MPU_CTRL_PRIVDEFENA_Msk);

	SCB_EnableICache();
	SCB_EnableDCache();

//	SCB->CACR = SCB->CACR | (1 << 2);											// 1: Enables Force Write-Through.
}
//-----------------------------------------------------------------------------
