/*
 * This file is part of the FX-4CR-V2 project.
 * See: https://github.com/f5bud/FX-4CR-V2
 *
 * Copyright (c) 2024 Daniel Nespoulous, F5BUD
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
//-----------------------------------------------------------------------------
//	SerialTask.cpp
//-----------------------------------------------------------------------------
#include "SerialTask.h"
#include "UserTask.h"
#include "RadioTask.h"
#include "Uarts.h"
#include "Format.h"

//-----------------------------------------------------------------------------
static const MsgControlType sRqstList[] =
{
	{ "AG0%03d;",			SerialTask::getGain,	SerialTask::setGain },
	{ "AC000;", 			SerialTask::getNone,	SerialTask::setNone },
	{ "AI%1d;",				SerialTask::getInfo,	SerialTask::setInfo },
	{ "BD%02d;",			SerialTask::getBand,	SerialTask::setBand },
	{ "BU%02d;",			SerialTask::getBand,	SerialTask::setBand },
	{ "DA%1d;",				SerialTask::getData,	SerialTask::setData },
	{ "EX%03d000000;",		SerialTask::getNone,	SerialTask::setMenu },
	{ "FA%011d;",			SerialTask::getVfoA,	SerialTask::setVfoA },
	{ "FB%011d;",			SerialTask::getVfoB,	SerialTask::setVfoB },
	{ "FL%1d;",				SerialTask::getNone,	SerialTask::setNone },
	{ "FR%1d;",				SerialTask::getVfoM,	SerialTask::setVfoM },
	{ "FT%1d;",				SerialTask::getVfoM,	SerialTask::setVfoM },
	{ "FV%s;",				SerialTask::getVer,		SerialTask::setNone },
	{ "ID021;",				SerialTask::getNone,	SerialTask::setNone },
	{ "IF%s;",				SerialTask::getStat,	SerialTask::setNone },
	{ "MD%1d;",				SerialTask::getMode,	SerialTask::setMode },
	{ "RA%02d00;",			SerialTask::getAtte,	SerialTask::setAtte },
	{ "RM%d%04d;",			SerialTask::getMeter,	SerialTask::setMeter },
	{ "RX;",				SerialTask::getRxRx,	SerialTask::setNone },
	{ "PA%1d0;",			SerialTask::getPrea,	SerialTask::setPrea },
	{ "PS%1d;",				SerialTask::getPwr,		SerialTask::setNone },
	{ "SM0%04d;",			SerialTask::getSmtr,	SerialTask::setNone },
	{ "TO%1d;",				SerialTask::getNone,	SerialTask::setNone },
	{ "TX%1d;",				SerialTask::getNone,	SerialTask::setTxTx, true },

	{ "::%s;",				SerialTask::getNone,	SerialTask::Calibre, true },

	{ nullptr, nullptr, nullptr }
};

//-----------------------------------------------------------------------------
SerialTask gSerialTask;

static bool			sSsbDig;
static eModeType	sMode;
static int16_t		sAiInfo;
static eRMCmd		sRMCmd;

//-----------------------------------------------------------------------------
void SerialTask::Handler()
{
	gSerialTask.Loop();
}
//-----------------------------------------------------------------------------
void SerialTask::CallBack()
{
	gSerialTask.setState(READY);
}
//-----------------------------------------------------------------------------
void SerialTask::Loop()
{
	gUart1.setRxCallBack(CallBack);
	gUart3.setRxCallBack(CallBack);

	sSsbDig = true;
	sMode = eSSBL;
	sAiInfo = 0;
	sRMCmd = eNset;

	while (1)
	{
		setState(SUSPENDED);

		for(;;)
		{
			size_t index = gUart1.peek().find(';');

			if (index == std::string::npos) break;

			std::string result = execute(gUart1.read(index + 1));

			if (result.length()) gUart1.write(result);
		}

		for(;;)
		{
			size_t index = gUart3.peek().find(';');

			if (index == std::string::npos) break;

			std::string result = execute(gUart3.read(index + 1));

			if (result.length()) gUart3.write(result);
		}
	}
}
//-----------------------------------------------------------------------------
std::string SerialTask::execute(std::string cmde)
{
	if (cmde.length() > 2)
	{
		const MsgControlType *catMsg = sRqstList;
		std::string arg1 = cmde.substr(0, 2);
		std::string arg2 = cmde.substr(2);

		while(catMsg->Masq)
		{
			if (std::string(catMsg->Masq).substr(0, 2).compare(arg1) == 0)
			{
				if (catMsg->Flag || arg2.length() > 1)				// possible ';'
				{
					return catMsg->SetFunc(catMsg->Masq, arg2.c_str());
				}
				else
					return catMsg->GetFunc(catMsg->Masq);
			}

			catMsg ++;
		}
	}

	return "";
//	return "?;";
}
//-----------------------------------------------------------------------------
int16_t SerialTask::getTS590SMode()
{
	static const int16_t catModes[] = { 3, 1, 2, 5, 4, 1, 2 };	// 	eCW=0, eSSBL=1, eSSBU=2, eAM=3, eFM=4, eDIGL=5, eDIGU=6

	return catModes[gUserTask.getMode()];
}
//-----------------------------------------------------------------------------
int16_t SerialTask::getTS590SVfo()
{
/*	if (gFXRadio.getMemory() > 1)								// 0=vfoA, 1=vfoB, x= mem as vfo
	{
		return 2;												// 2 = MEM
	}
*/
	switch(gUserTask.getVfo())
	{
	case eVfoA:
		return 0;												// 0 = VFOA
	default:
		return 1;												// 1 = VFOB
	}
}
//-----------------------------------------------------------------------------
int16_t SerialTask::getTS590SMem()
{
	return std::max((int16_t) 1, gUserTask.getMemory());
}
//-----------------------------------------------------------------------------
std::string SerialTask::getTS590SRit()
{
	int16_t rit = gUserTask.getRitValue();
	std::string result = Format().Fmt("%04d", std::abs(rit));	// P3 RIT/XIT frequency ±9990 Hz

	return ((rit >= 0) ? "+" : "-") + result;
}
//-----------------------------------------------------------------------------
//	get
//-----------------------------------------------------------------------------
std::string SerialTask::getAtte(const char *masq)
{
	return Format().Fmt(masq, 0);
}
//-----------------------------------------------------------------------------
std::string SerialTask::getBand(const char *masq)
{
	static const int16_t bands[] = { 1, 10, 2, 3, 4, 5, 6, 7, 8, 9 };

	return Format().Fmt(masq, bands[gUserTask.getBand()]);
}
//-----------------------------------------------------------------------------
std::string SerialTask::getData(const char *masq)
{
	return Format().Fmt(masq, sSsbDig);
}
//-----------------------------------------------------------------------------
std::string SerialTask::getGain(const char *masq)
{
	return Format().Fmt(masq, (gUserTask.getSpeaker() * 255) / 20);
}
//-----------------------------------------------------------------------------
std::string SerialTask::getInfo(const char *masq)
{
	return Format().Fmt(masq, sAiInfo);
}
//-----------------------------------------------------------------------------
std::string SerialTask::getMode(const char *masq)
{
	return Format().Fmt(masq, getTS590SMode());
}
//-----------------------------------------------------------------------------
std::string SerialTask::getNone(const char *masq)
{
	return Format().Fmt(masq, 0);
}
//-----------------------------------------------------------------------------
std::string SerialTask::getPrea(const char *masq)
{
	return Format().Fmt(masq, gUserTask.getRxAtt() ? 1 : 0);
}
//-----------------------------------------------------------------------------
std::string SerialTask::getPwr(const char *masq)
{
	return Format().Fmt(masq, 1);
}
//-----------------------------------------------------------------------------
std::string SerialTask::getRxRx(const char *masq)
{
	gUserTask.setCatPtt(false);

	return sAiInfo ? masq : "";
}
//-----------------------------------------------------------------------------
std::string SerialTask::getSmtr(const char *masq)
{
	return Format().Fmt(masq, std::abs(gRadioTask.getSmeter()));
}
//-----------------------------------------------------------------------------
std::string SerialTask::getStat(const char *masq)
{
	std::string temp = Format().Fmt("%011d", gUserTask.getRxFrequency());	// P1 Freq

	temp += "     ";													// P2 Spaces (5)
	temp += getTS590SRit();												// P3 RIT/XIT frequency ±9990 Hz
	temp += (gUserTask.getRitKey() == eRit) ? "1" : "0";				// P4 0: RIT OFF
	temp += (gUserTask.getRitKey() == eXit) ? "1" : "0";				// P5 0: XIT OFF
	temp += Format().Fmt("%03d", getTS590SMem());						// P6-P7 Memory channel number
	temp += gUserTask.getPttKey() ? "1" : "0";							// P8 0: RX, 1: TX
	temp += Format().Fmt("%1d", getTS590SMode());						// P9 Operating mode (refer to the MD command)
	temp += Format().Fmt("%1d", getTS590SVfo());						// P10 0 = VFOA, 2 = VFOB, 2 = MEM (refer to the FR/FT commands)
	temp += "0";														// P11 Scan status (refer to the SC command)
	temp += "0";														// P12 0: Simplex operation
	temp += "0";														// P13 0: CTCSS or TONE
	temp += "00";														// P14 00: CTCSS frequ
	temp += "0";														// P15 0: Always 0

	return Format().Fmt(masq, temp.c_str());
}
//-----------------------------------------------------------------------------
std::string SerialTask::getMeter(const char *masq)
{
	int16_t result = 0;
	float32_t value = gRadioTask.getSwr();

	switch(sRMCmd)
	{
	case eSwr:
		result = std::min((int16_t) 30, (int16_t) (30.0f - 60.0f / (value + 1.0f)));

		break;

	case eAlc:
		result = gRadioTask.getAlc() / 33;									// [0 ... 100%] => 0 ... 30
		break;

	default:
		break;
	}

	return Format().Fmt(masq, sRMCmd, result);
}
//-----------------------------------------------------------------------------
std::string SerialTask::getVer(const char *masq)
{
	return Format().Fmt(masq, VERSION);
}
//-----------------------------------------------------------------------------
std::string SerialTask::getVfoA(const char *masq)
{
	return Format().Fmt(masq, gUserTask.getVfoAfreq());
}
//-----------------------------------------------------------------------------
std::string SerialTask::getVfoB(const char *masq)
{
	return Format().Fmt(masq, gUserTask.getVfoBfreq());
}
//-----------------------------------------------------------------------------
std::string SerialTask::getVfoM(const char *masq)
{
	return Format().Fmt(masq, getTS590SVfo());
}
//-----------------------------------------------------------------------------
//	set
//-----------------------------------------------------------------------------
std::string SerialTask::setAtte(const char *masq, const char *cmde)
{
//	gUserTask.setAttenuator(atoi(cmde) == 1 ? eAtt2 : eAtt1);

	return getAtte(masq);
}
//-----------------------------------------------------------------------------
std::string SerialTask::setBand(const char *masq, const char *cmde)
{
	switch(atoi(cmde))
	{
	case 1:
		gUserTask.setBand(eBand80m);
		break;
	case 2:
		gUserTask.setBand(eBand40m);
		break;
	case 3:
		gUserTask.setBand(eBand30m);
		break;
	case 4:
		gUserTask.setBand(eBand20m);
		break;
	case 5:
		gUserTask.setBand(eBand17m);
		break;
	case 6:
		gUserTask.setBand(eBand15m);
		break;
	case 7:
		gUserTask.setBand(eBand12m);
		break;
	case 8:
		gUserTask.setBand(eBand10m);
		break;
	case 9:
		gUserTask.setBand(eBand6m);
		break;
	default:
		break;
	}

	return getBand(masq);
}
//-----------------------------------------------------------------------------
std::string SerialTask::setData(const char *masq, const char *cmde)
{
	sSsbDig = atoi(cmde);

	switch(sMode)
	{
	case eSSBL:														// LSB
		gUserTask.setMode(sSsbDig ? eDIGL : eSSBL);
		break;
	case eSSBU:														// USB
		gUserTask.setMode(sSsbDig ? eDIGU : eSSBU);
		break;
	default:
		break;
	}

	return getData(masq);
}
//-----------------------------------------------------------------------------
std::string SerialTask::setGain(const char *masq, const char *cmde)
{
	int16_t value = atoi(cmde);

	if (value > 0)
		gUserTask.setSpeaker((value * 20) / 255);

	return getGain(masq);
}
//-----------------------------------------------------------------------------
std::string SerialTask::setInfo(const char *masq, const char *cmde)
{
	sAiInfo = atoi(cmde);

	return getInfo(masq);
}
//-----------------------------------------------------------------------------
std::string SerialTask::setMenu(const char *masq, const char *cmde)
{
	char buffer[4];

	buffer[0] = *(cmde ++);
	buffer[1] = *(cmde ++);
	buffer[2] = *(cmde ++);
	buffer[3] = 0;

	int16_t value = atoi(buffer);

	return Format().Fmt(masq, value);							// P1 = 003, P2 = 00, P3 = 0, P4 = 0, P5 = 00
}
//-----------------------------------------------------------------------------
std::string SerialTask::setMode(const char *masq, const char *cmde)
{
	switch(atoi(cmde))											//1: LSB, 2: USB, 3: CW, 4: FM, 5: AM, 6: FSK, 7: CW-R, 9: FSK-R
	{
	case 1:														// LSB
		sMode = eSSBL;
		gUserTask.setMode(sSsbDig ? eDIGL : eSSBL);
		break;
	case 2:														// USB
		sMode = eSSBU;
		gUserTask.setMode(sSsbDig ? eDIGU : eSSBU);
		break;
	case 3:														// CW
	case 7:														// CW-R
		sMode = eCW;
		gUserTask.setMode(eCW);
		break;
	case 4:														// FM
		sMode = eFM;
		gUserTask.setMode(eFM);
		break;
	case 5:														// AM
		sMode = eAM;
		gUserTask.setMode(eAM);
		break;
	default:
		break;
	}

	return getMode(masq);
}
//-----------------------------------------------------------------------------
std::string SerialTask::setNone(const char *masq, const char *cmde)
{
	return Format().Fmt(masq, atol(cmde));
}
//-----------------------------------------------------------------------------
std::string SerialTask::setPrea(const char *masq, const char *cmde)
{
	gUserTask.setPreampli(atoi(cmde) ? true : false);

	return getPrea(masq);
}
//-----------------------------------------------------------------------------
std::string SerialTask::setMeter(const char *masq, const char *cmde)
{
	sRMCmd = (eRMCmd) atoi(cmde);

	return getMeter(masq);
}
//-----------------------------------------------------------------------------
std::string SerialTask::setTxTx(const char *masq, const char *cmde)
{
	int16_t value = atoi(cmde);

	switch(value)
	{
	case 2:
		gUserTask.setTuneMode(true);
		break;

	default:
		gUserTask.setCatPtt(true);
		break;
	}

	return sAiInfo ? Format().Fmt(masq, value) : "";
}
//-----------------------------------------------------------------------------
std::string SerialTask::setVfoA(const char *masq, const char *cmde)
{
	gUserTask.setVfoAfreq(atol(cmde));

	return getVfoA(masq);
}
//-----------------------------------------------------------------------------
std::string SerialTask::setVfoB(const char *masq, const char *cmde)
{
	gUserTask.setVfoBfreq(atol(cmde));

	return getVfoB(masq);
}
//-----------------------------------------------------------------------------
std::string SerialTask::setVfoM(const char *masq, const char *cmde)
{
	switch(atoi(cmde))
	{
	case 0:
		gUserTask.setVfoA();
		break;
	case 1:
		gUserTask.setVfoB();
		break;
	default:
		break;
	}

	return getVfoM(masq);
}
//-----------------------------------------------------------------------------
std::string SerialTask::Calibre(const char *masq, const char *cmde)
{
	static const char * msg[] = { "Imported", "error" };

	if (strlen(cmde) < 36)
		return Format().Fmt(masq, gUserTask.Export(cmde).c_str());

	return Format().Fmt(masq, msg[gUserTask.Import(cmde)]);
}
//-----------------------------------------------------------------------------
