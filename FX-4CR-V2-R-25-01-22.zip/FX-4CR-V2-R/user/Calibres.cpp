/*
 * This file is part of the FX-4CR-V2 project.
 * See: https://github.com/f5bud/FX-4CR-V2
 *
 * Copyright (c) 2024 Daniel Nespoulous, F5BUD
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE. 
 */
//-----------------------------------------------------------------------------
//	Calibres.cpp
//-----------------------------------------------------------------------------
#include "Calibres.h"
#include "Eeprom.h"
#include "Format.h"

//-----------------------------------------------------------------------------
static const char * sBandMasks[RADIO_BAND_SIZE] =
{
	"80m-%s: %d", "60m-%s: %d", "40m-%s: %d", "30m-%s: %d", "20m-%s: %d",
	"17m-%s: %d", "15m-%s: %d", "12m-%s: %d", "10m-%s: %d",  "6m-%s: %d"
};
//-----------------------------------------------------------------------------
static const int16_t sPowerSet[RADIO_BAND_SIZE]
{
	341, 687, 815, 825, 609, 771, 952, 1460, 1946, 7788
};
//-----------------------------------------------------------------------------
//
//-----------------------------------------------------------------------------
SetBandType &Calibres::getBandConf(int16_t band)
{
	return mCalibres.Bands[band];
}
//-----------------------------------------------------------------------------
int16_t Calibres::getRssiCal()
{
	mCalibres.RssiCal = std::max((int16_t) 50, std::min((int16_t) 100, mCalibres.RssiCal));

	return mCalibres.RssiCal;
}
//-----------------------------------------------------------------------------
int32_t Calibres::getTcxoCal()
{
	mCalibres.TcxoCal = std::max((int32_t) 24'990'000L, std::min((int32_t) 25'010'000L, mCalibres.TcxoCal));

	return mCalibres.TcxoCal;
}
//-----------------------------------------------------------------------------
int16_t Calibres::getVoltCal()
{
	mCalibres.VoltCal = std::max((int16_t) 2400, std::min((int16_t) 2800, mCalibres.VoltCal));

	return mCalibres.VoltCal;
}
//-----------------------------------------------------------------------------
int16_t Calibres::getWattCal()
{
	mCalibres.WattCal = std::max((int16_t) 700, std::min((int16_t) 1300, mCalibres.WattCal));

	return mCalibres.WattCal;
}
//-----------------------------------------------------------------------------
//
//-----------------------------------------------------------------------------
std::string	Calibres::changeRssiCal(int16_t value)
{
	mCalibres.RssiCal += value;

	return Format().Fmt("Rssi-Cal: %d", getRssiCal());
}
//-----------------------------------------------------------------------------
std::string	Calibres::changeRxMag(int16_t value, int16_t band)
{
	SetBandType *bandType = mCalibres.Bands + band;

	bandType->RxMag += value;
	bandType->RxMag = std::max((int16_t) 800, std::min((int16_t) 1200, bandType->RxMag));

	return Format().Fmt(sBandMasks[band], "RxMag", bandType->RxMag);
}
//-----------------------------------------------------------------------------
std::string	Calibres::changeRxPha(int16_t value, int16_t band)
{
	SetBandType *bandType = mCalibres.Bands + band;

	bandType->RxPha += value;
	bandType->RxPha = std::max((int16_t) 800, std::min((int16_t) 1200, bandType->RxPha));

	return Format().Fmt(sBandMasks[band], "RxPha", bandType->RxPha);
}
//-----------------------------------------------------------------------------
std::string Calibres::changeTcxoCal(int16_t value)
{
	mCalibres.TcxoCal += value;

	return Format().Fmt("Tcxo-Cal: %dhz", getTcxoCal());
}
//-----------------------------------------------------------------------------
std::string	Calibres::changeTxMag(int16_t value, int16_t band)
{
	SetBandType *bandType = mCalibres.Bands + band;

	bandType->TxMag += value;
	bandType->TxMag = std::max((int16_t) 800, std::min((int16_t) 1200, bandType->TxMag));

	return Format().Fmt(sBandMasks[band], "TxMag", bandType->TxMag);
}
//-----------------------------------------------------------------------------
std::string	Calibres::changeTxPha(int16_t value, int16_t band)
{
	SetBandType *bandType = mCalibres.Bands + band;

	bandType->TxPha += value;
	bandType->TxPha = std::max((int16_t) 800, std::min((int16_t) 1200, bandType->TxPha));

	return Format().Fmt(sBandMasks[band], "TxPha", bandType->TxPha);
}
//-----------------------------------------------------------------------------
std::string	Calibres::changeTxPower(int16_t value, int16_t band)
{
	SetBandType *bandType = mCalibres.Bands + band;

	bandType->TxPower += value;
	bandType->TxPower = std::max((int16_t) 200, std::min((int16_t) 9999, bandType->TxPower));

	return Format().Fmt(sBandMasks[band], "TxPwr", bandType->TxPower);
}
//-----------------------------------------------------------------------------
std::string	Calibres::changeVoltCal(int16_t value)
{
	mCalibres.VoltCal += value;

	return Format().Fmt("Volt-Cal: %d", getVoltCal());
}
//-----------------------------------------------------------------------------
std::string Calibres::changeWattCal(int16_t value)
{
	mCalibres.WattCal += value;

	return Format().Fmt("Watt-Cal: %d", getWattCal());
}
//-----------------------------------------------------------------------------
void Calibres::Init()
{
	for (int16_t page = 0; page < CALIBRE_PAGE; page ++)
	{
		gI2cData.ReadPage(AT24C16, CALIBRE_ADDR + page, mCalibres.buffer[page]);
		memcpy(mCalCache.buffer[page], mCalibres.buffer[page], PAGE_SIZE);
	}

	if (mCalibres.Magic != MAGIC_CALIBRE)
	{
		memset(mCalibres.buffer, 0xFF, sizeof(mCalibres.buffer));

		mCalibres.Magic = MAGIC_CALIBRE;

		mCalibres.VoltCal = 2621;
		mCalibres.WattCal = 1000;
		mCalibres.RssiCal = 82;
		mCalibres.TcxoCal = 25'000'000L;

		for (int16_t i = 0; i < RADIO_BAND_SIZE; i ++)
		{
			mCalibres.Bands[i].RxMag = 1000;
			mCalibres.Bands[i].RxPha = 1000;

			mCalibres.Bands[i].TxMag = 1000;
			mCalibres.Bands[i].TxPha = 1000;

			mCalibres.Bands[i].TxPower = sPowerSet[i];
		}
	}
}
//-----------------------------------------------------------------------------
void Calibres::Loop(Thread &thread)
{
	for (int16_t page = 0; page < CALIBRE_PAGE; page ++)
	{
		if (memcmp(mCalCache.buffer[page], mCalibres.buffer[page], PAGE_SIZE))
		{
			memcpy(mCalCache.buffer[page], mCalibres.buffer[page], PAGE_SIZE);
			gI2cData.WritePage(AT24C16, CALIBRE_ADDR + page, mCalibres.buffer[page]);
			thread.Delay(10L);
		}
	}
}
//-----------------------------------------------------------------------------
uint8_t Calibres::getValue(const char *buffer)
{
	uint8_t result = 0;

	for (int16_t i = 0; i < 2; i ++)
	{
		uint8_t a = *(buffer ++);

		if (a >= 'A') a -= 55;
		if (a >= '0') a -= 48;

		result <<= 4;
		result  |= a;
	}

	return result;
}
//-----------------------------------------------------------------------------
std::string	Calibres::Export(const char *buffer)
{
	static const char hex[] = {"0123456789ABCDEF" };

	std::string result;

	if (buffer[2] == ';')
	{
		int16_t index = getValue(buffer);
		int16_t checkSum = index;

		result.append(1, ';');

		result.append(1, hex[(index >> 4) & 0x0F]);
		result.append(1, hex[(index >> 0) & 0x0F]);

		for (int16_t page = 0; page < PAGE_SIZE; page ++)
		{
			uint8_t temp = mCalibres.buffer[index][page];

			result.append(1, hex[(temp >> 4) & 0x0F]);
			result.append(1, hex[(temp >> 0) & 0x0F]);

			checkSum += temp;
		}

		result.append(1, hex[(checkSum >> 4) & 0x0F]);
		result.append(1, hex[(checkSum >> 0) & 0x0F]);
	}

	return result;
}
//-----------------------------------------------------------------------------
bool Calibres::Import(const char *buffer)
{
	bool result = false;

	if (buffer[36] == ';')
	{
		int16_t index = getValue(buffer);
		int16_t checkSum = index;

		buffer += 2;

		for (int16_t page = 0; page < PAGE_SIZE; page ++)
		{
			uint8_t value = getValue(buffer);

			mCalibres.buffer[index][page] = value;
			checkSum += value;
			buffer   += 2;
		}

		if ((checkSum & 0xFF) != getValue(buffer))
		{
			mCalibres.Magic = 0;
			result = true;
		}
	}

	return result;
}
//-----------------------------------------------------------------------------
