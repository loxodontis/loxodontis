/*
 * This file is part of the FX-4CR-V2 project.
 * See: https://github.com/f5bud/FX-4CR-V2
 *
 * Copyright (c) 2024 Daniel Nespoulous, F5BUD
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
//-----------------------------------------------------------------------------
//	UserTask.cpp
//-----------------------------------------------------------------------------
#include "UserTask.h"
#include "RadioTask.h"
#include "ScreenTask.h"
#include "ScreenColors.h"

#include "Format.h"

#include "KeyPressSSB.h"		// 0
#include "KeyPressMV.h"			// 1
#include "KeyPressAB.h"			// 2
#include "KeyPressCW.h"			// 3
#include "KeyPressAMFM.h"		// 4
#include "KeyPressRIT.h"		// 5
#include "KeyPressIFATT.h"		// 6
#include "KeyPressPWR.h"		// 7
#include "KeyPressMENU.h"		// 8
#include "KeyPressFILTER.h"		// 9
#include "KeyPressFUNC.h"		// 10
#include "KeyPressAF.h"			// 11
#include "KeyPressTUNE.h"		// 12

//-----------------------------------------------------------------------------
enum eMenuType
{
	eMenuVersion,				// user mode
	eMenuLight,
	eMenuDelay,
	eMenuDegreCF,
	eMenuFftWidht,
	eMenuFftSmooth,
	eMenuAdcAux,
	eMenuAdcMic,
	eMenuDacAux,
	eMenuRitKey,
	eMenuKeyCwType,
	eMenuKeyCwPitch,
	eMenuKeyCwAudio,
	eMenuKeyCwDelay,
	eMenuKeyCwMsg1,
	eMenuKeyCwMsg2,
	eMenuKeyCwMsg3,
	eMenuKeyCwMsg4,
	eMenuKeyCwMsg5,
	eMenuVoiceRecord,
	eMenuVoiceMonitor,

	eMenuMarsCap,				// service mode
	eMenuTcxoCal,
	eMenuVoltCal,
	eMenuWattCal,
	eMenuRssiCal,
	eMenuTxPwr,
	eMenuTxMag,
	eMenuTxPha,
	eMenuRxMag,
	eMenuRxPha
};

//-----------------------------------------------------------------------------
UserTask  gUserTask;

//-----------------------------------------------------------------------------
static KeyPressSSB		sKeySsb;
static KeyPressMV		sKeyMv;
static KeyPressAB		sKeyAb;
static KeyPressCW		sKeyCw;
static KeyPressAMFM		sKeyAmFm;
static KeyPressRIT		sKeyRit;
static KeyPressIFATT	sKeyIfAtt;
static KeyPressPWR		sKeyPwr;
static KeyPressMENU		sKeyMenu;
static KeyPressFILTER	sKeyFilter;
static KeyPressFUNC		sKeyFunc;
static KeyPressAF		sKeyAf;
static KeyPressTUNE		sKeyTune;

#define KEY_PRESS_SIZE 13

static KeyPressBase *sKeyPressList[KEY_PRESS_SIZE] =
{
	&sKeySsb,		&sKeyMv,	&sKeyAb,
	&sKeyCw,		&sKeyAmFm,	&sKeyRit,
	&sKeyIfAtt,		&sKeyPwr,	&sKeyMenu,
	&sKeyFilter,	&sKeyFunc,
	&sKeyAf,		&sKeyTune
};

//-----------------------------------------------------------------------------
extern "C" void BusFault_Handler()
{
	gUserTask.ErrorHandler();
}
//-----------------------------------------------------------------------------
void UserTask::Handler()
{
	gUserTask.Loop();
}
//-----------------------------------------------------------------------------
void UserTask::Loop()
{
	mEncoderAf.Init();
	mEncoderTune.Init();
	mSideTone.Init();

	InitColors(sKeyCw.getPin() == false);

	gServiceMode = (sKeyRit.getPin() == false);									// RIT: service mode

	Calibres::Init();
	Settings::Init(sKeyAb.getPin() == false);									// AB: factory reset ?

	while(getPttKey())
	{
		mRadioType = eRadioMenu;
		mMenuText  = "Check PTT or RTS signal";

		gScreenTask.setState(READY);
		gScreenTask.Delay(100L);
	}

	IwdgInit(3, 3000);															// (32kHz / 32), 3000mS

	mCatPtt    = false;
	mRitPtt    = false;
	mRadioType = eRadioStd;

	mPowerSup.setLow();															// All is Ok, Power Up

	while (1)
	{
		IwdgRefresh();

		gScreenTask.setState(READY);
		gRadioTask.setState(READY);

		Delay(100L);

		mMenuText = userEvent();

		Calibres::Loop(*this);
		Settings::Loop(*this);

		mBltPower.setPin(getBlueTooth());											// bluetooth change ?

		if (gServiceMode)
		{
			switchModeCW();
			setCwKey(eStraightKey);
			mMenuValue = setTraceMsg();												// to activate the SideTone
			continue;
		}

		if (Scheduler::GetTick() > mBigTimer)
		{
			switch(mRadioType)
			{
			case eRadioLock:
			case eRadioCaller:
				break;

			default:
				mRadioType = eRadioStd;
				break;
			}

			backLight(false);
		}
	}
}
//-----------------------------------------------------------------------------
bool UserTask::getBltCnted()
{
	if (getBlueTooth())
		return (mBltCnted.getPin() == false);

	return false;
}
//-----------------------------------------------------------------------------
bool UserTask::getCatPtt()
{
	return getPttKey() || mCatPtt;												// RTS or CAT cmde
}
//-----------------------------------------------------------------------------
eInputType UserTask::getKeyTone()												// called by RadioTask in its own task !!!
{
	if (gServiceMode) return mSideTone.getKeyTone();

	switch(mRadioType)
	{
	case eRadioMenu:
		switch(mMenuIndex)
		{
		case eMenuKeyCwMsg1:
		case eMenuKeyCwMsg2:
		case eMenuKeyCwMsg3:
		case eMenuKeyCwMsg4:
		case eMenuKeyCwMsg5:
			break;

		case eMenuVoiceRecord:
			if (getPttKey()) return eVxRecord;
			break;

		case eMenuVoiceMonitor:
			if (getPttKey()) return eVxMonitor;
			break;

		default:
			break;
		}

		break;

	case eRadioStd:
	case eRadioCaller:
		switch(getMode())
		{
		case eCW:
			return mSideTone.getKeyTone();

		case eSSBL:
		case eSSBU:
		case eAM:
		case eFM:
			if (gRadioTask.getVoicePtt()) return eVxPlayer;							// priority to keyPtt
			if (getPttKey()) return eTxMic;
			break;

		default:																	// eDIGL or eDIGU
			if (getCatPtt()) return eTxAux;
			break;
		}
		break;

	default:
		break;
	}

	return eRxIQ;
}
//-----------------------------------------------------------------------------
bool UserTask::getPttKey()
{
//	return false;
//	return getTuneMode() || mRitPtt;

	return getTuneMode() || mRitPtt || (mPttKey.getPin() == false);
}
//-----------------------------------------------------------------------------
const char *UserTask::getMenuText()
{
	return mMenuText.c_str();
}
//-----------------------------------------------------------------------------
const char * UserTask::getMenuValue()
{
	return mMenuValue.c_str();
}
//-----------------------------------------------------------------------------
eRadioType UserTask::getRadioType()
{
	return mRadioType;
}
//-----------------------------------------------------------------------------
SetBandType &UserTask::getSetBand()
{
	return getBandConf(getBand());
}
//-----------------------------------------------------------------------------
float32_t UserTask::getTxPower()
{
	float32_t txPower = getSetBand().TxPower;									// ref for 10W

	txPower *= (getPower() / 10'000.0f);

	return sqrtf(txPower) / 100.0f;
}
//-----------------------------------------------------------------------------
void UserTask::setCatPtt(bool value)
{
	mCatPtt = value;
}
//-----------------------------------------------------------------------------
void UserTask::setRadioType(eRadioType value)
{
	mRadioType = value;
}
//-----------------------------------------------------------------------------
void UserTask::setRitPtt(bool value)
{
	mRitPtt = value;
}
//-----------------------------------------------------------------------------
void UserTask::CwCorrection(bool all)
{
	mSideTone.Correction(all);
}
//-----------------------------------------------------------------------------
void UserTask::ErrorHandler()
{
	for (int16_t i = 0; i < 20; i ++)
	{
		mBackLight.toggle();
		IwdgRefresh();
		Delay(150);
	}

	mPowerSup.setHigh();														// Power Down
}
//-----------------------------------------------------------------------------
void UserTask::PowerOff()
{
	gScreenTask.showText("73");
	gRadioTask.FinalMute();

	while (sKeyPwr.getPin() == 0)												// PWR
	{
		IwdgRefresh();
		Delay(100);
	}

	mPowerSup.setHigh();														// Power Down
}
//-----------------------------------------------------------------------------
void UserTask::SendMessage(eCallerType value)
{
	switch(getMode())
	{
	case eCW:
		mSideTone.setTxMessage(getCwMsgs(value));								// space before for timing
		break;

	case eSSBL:
	case eSSBU:
	case eAM:
	case eFM:
		VoiceRepeat(value, true);
		break;

	default:
		break;
	}
}
//-----------------------------------------------------------------------------
void UserTask::backLight(bool value)
{
	switch(getBackLight())
	{
	case eBlDelayed:
		mBackLight.setPin(value);												// backLight on : off
		break;

	case eBlAlwaysOn:
		mBackLight.setHigh();													// backLight on
		break;

	default:
		mBackLight.setLow();													// backLight off
		break;
	}
}
//-----------------------------------------------------------------------------
std::string UserTask::userEvent()
{
	bool isOnAir = gRadioTask.isOnAir();
	uint64_t tickTime = Scheduler::GetTick();

	for (int16_t i = 0; i < KEY_PRESS_SIZE; i ++)
	{
		if (sKeyPressList[i]->checkPressed(tickTime, isOnAir))
		{
			backLight(true);
			mBigTimer = tickTime + getMenuDelay() * 1000L;
			break;
		}
	}
	if (mEncoderAf.isChanged() || mEncoderTune.isChanged())
		mBigTimer = tickTime + getMenuDelay() * 1000L;


	int32_t afValue   = mEncoderAf.getValue();									// getValue reset changed !!!
	int32_t tuneValue = mEncoderTune.getValue();								// getValue reset changed !!!

	mMenuValue = "";

	switch(mRadioType)
	{
	case eRadioLock:
		return "";

	case eRadioMenu:
		return gServiceMode ? serviceMenu(afValue, tuneValue) : userMenu(afValue, tuneValue);

	case eRadioFilter:
		return changeFilter(afValue);

	case eRAdioMemory:
		return changeMemory(tuneValue);

	case eRadioPwr:
		return changePower(afValue);

	case eRadioCw:
		return changeCwSpeed(afValue);

	case eRadioSql:
		return changeSqlValue(afValue);

	case eRadioDsp:
		return changeDspValue(afValue);

	case eRadioTune:
		return changeStep(tuneValue);

	case eRadioFunc:
		return "Press band buttons";

	case eRadioRitKey:
		return changeRitValue(tuneValue);

	default:
		switch (getMode())
		{
		case eCW:
			mMenuValue = setTraceMsg();											// to activate the SideTone
			break;

		case eSSBL:
		case eSSBU:
		case eAM:
		case eFM:
			mMenuValue = VoiceRepeat(mCallerType, false);						// every 100ms
			break;

		default:
			mMenuValue = setNoneMsg();
			break;
		}

		break;
	}

	if (isOnAir)
	{
		changePower(afValue);
		return "";
	}

	changeSpeaker(afValue);
	changeFrequency(tuneValue);

	return "";
}
//-----------------------------------------------------------------------------
std::string UserTask::userMenu(int32_t afValue, int32_t tuneValue)
{
	mMenuIndex += tuneValue;

	mMenuIndex = std::max((int16_t) eMenuVersion,      mMenuIndex);
	mMenuIndex = std::min((int16_t) eMenuVoiceMonitor, mMenuIndex);

	switch(mMenuIndex)
	{
	case eMenuVersion:
		mMenuValue = HARDWARE_VERSION;
		return BUILD_VERSION;

	case eMenuLight:
		mMenuValue = setNoneMsg();
		return changeBackLight(afValue);

	case eMenuDelay:
		mMenuValue = setNoneMsg();
		return changeMenuDelay(afValue);

	case eMenuDegreCF:
		mMenuValue = setNoneMsg();
		return changeDegreCF(afValue);

	case eMenuFftWidht:
		mMenuValue = setNoneMsg();
		return changeFftWidth(afValue);

	case eMenuFftSmooth:
		mMenuValue = setNoneMsg();
		return changeFftSmooth(afValue);

	case eMenuAdcAux:
		return changeAdcAux(afValue);

	case eMenuAdcMic:
		return changeAdcMic(afValue);

	case eMenuDacAux:
		mMenuValue = setNoneMsg();
		return changeDacAux(afValue);

	case eMenuRitKey:
		mMenuValue = setNoneMsg();
		return changeRitKey(afValue);

	case eMenuKeyCwType:
		mMenuValue = setNoneMsg();
		return changeCwKey(afValue);

	case eMenuKeyCwPitch:
		mMenuValue = setNoneMsg();
		return changeCwPitch(afValue);

	case eMenuKeyCwAudio:
		mMenuValue = setNoneMsg();
		return changeCwAudio(afValue);

	case eMenuKeyCwDelay:
		mMenuValue = setNoneMsg();
		return changeCwDelay(afValue);

	case eMenuKeyCwMsg1:
	case eMenuKeyCwMsg2:
	case eMenuKeyCwMsg3:
	case eMenuKeyCwMsg4:
	case eMenuKeyCwMsg5:
		mMenuValue = setCwMsg(mMenuIndex - eMenuKeyCwMsg1);
		return Format().Fmt("Cw-Message %d:", 1 + mMenuIndex - eMenuKeyCwMsg1);		// for msg 1

	case eMenuVoiceRecord:
		mMenuValue = setVoiceMsg();
		return "Voice-Record:";

	case eMenuVoiceMonitor:
		mMenuValue = setVoiceMsg();
		return "Voice-Monitor:";

	default:
		break;
	}

	return "";
}
//-----------------------------------------------------------------------------
std::string UserTask::serviceMenu(int32_t afValue, int32_t tuneValue)
{
	mMenuIndex += tuneValue;

	mMenuIndex = std::max((int16_t) eMenuMarsCap, mMenuIndex);
	mMenuIndex = std::min((int16_t) eMenuRxPha,   mMenuIndex);

	switch(mMenuIndex)
	{
	case eMenuMarsCap:
		return changeMarsCap(afValue);

	case eMenuTcxoCal:
		return changeTcxoCal(afValue);

	case eMenuVoltCal:
		return changeVoltCal(afValue);

	case eMenuWattCal:
		return Format().Fmt("%s %s", changeWattCal(afValue).c_str(), gRadioTask.getWattStr().c_str());

	case eMenuRssiCal:
		return Format().Fmt("%s %s", changeRssiCal(afValue).c_str(), gRadioTask.getRssiDbStr().c_str());

	case eMenuTxPwr:
		return Format().Fmt("%s %s", changeTxPower(afValue, getBand()).c_str(), gRadioTask.getWattStr().c_str());

	case eMenuTxMag:
		return changeTxMag(afValue, getBand());

	case eMenuTxPha:
		return changeTxPha(afValue, getBand());

	case eMenuRxMag:
		return changeRxMag(afValue, getBand());

	case eMenuRxPha:
		return changeRxPha(afValue, getBand());

	default:
		break;
	}

	return "";
}
//-----------------------------------------------------------------------------
std::string UserTask::getCallerStr()
{
	if (mCallerCount > 0)
		return Format().Fmt("%2d", 1 + (mCallerCount / 10));

	return "";
}
//-----------------------------------------------------------------------------
std::string UserTask::setCwMsg(int16_t index)
{
	char *temp = getCwMsgs(index);
	mBigTimer  = Scheduler::GetTick() + getMenuDelay() * 10000L;				// force BigTimer delay * 100S

	mSideTone.setEditTemp(temp, MY_MSG_SIZE);
	return showSpace(temp, false);
}
//-----------------------------------------------------------------------------
std::string UserTask::setNoneMsg()
{
	mSideTone.setEditTemp(nullptr, 0);
	return "";
}
//-----------------------------------------------------------------------------
std::string UserTask::setTraceMsg()
{
	mSideTone.setEditTemp(mCwTrace, CWTRACE_SIZE);
	return " " + showSpace(mCwTrace, true);
}
//-----------------------------------------------------------------------------
std::string UserTask::setVoiceMsg()
{
	mBigTimer  = Scheduler::GetTick() + getMenuDelay() * 10000L;				// force BigTimer delay * 100S

	mSideTone.setEditTemp(nullptr, 0);
	return gRadioTask.getProgress();
}
//-----------------------------------------------------------------------------
std::string UserTask::showSpace(char *value, bool shift)
{
	size_t pos = 0;
	std::string buffer = value;

	while((pos = buffer.find(' ', pos)) != std::string::npos)
	{
		buffer[pos ++] = 0x7F;												// replace " " by "_"
	}

	if (shift)
	{
		while (buffer.length() > CWTRACE_SIZE - 5)
		{
			buffer.erase(0, 1);
		}

		strcpy(value, buffer.c_str());
	}

	return buffer;
}
//-----------------------------------------------------------------------------
std::string UserTask::VoiceRepeat(eCallerType value, bool flag)
{
	if (mRadioType == eRadioCaller)
	{
		if (flag)
		{
			mCallerType   = value;
			mCallerCount  = 0;
			mCallerRepeat = (value == eCallerUsr1) ? 1 : 10;
		}

		if (gRadioTask.getVoicePtt())											// in transmit
		{
			if (getPttKey())
			{
				mCallerCount  = 0;
				mCallerRepeat = 0;
				gRadioTask.stopSignal();
				Delay(200L);
			}
		}

		if (mCallerRepeat > 0)
		{
			mCallerCount --;

			if (mCallerCount < 1)
			{
				mCallerCount = value * 150;
				mCallerRepeat --;

				gRadioTask.setVoicePtt();
			}
		}

		return gRadioTask.getProgress();
	}

	mCallerCount  = 0;
	mCallerRepeat = 0;

	return setNoneMsg();
}
