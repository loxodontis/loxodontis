/*
 * This file is part of the FX-4CR-V2 project.
 * See: https://github.com/f5bud/FX-4CR-V2
 *
 * Copyright (c) 2024 Daniel Nespoulous, F5BUD
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE. 
 */
//-----------------------------------------------------------------------------
//	Settings.cpp
//-----------------------------------------------------------------------------
#include "Settings.h"
#include "Eeprom.h"
#include "Format.h"

//-----------------------------------------------------------------------------
typedef struct
{
	eBandType	Band;
	eModeType	Mode;
	int32_t		Current;
	int32_t		HamMin;
	int32_t		HamMax;
	int32_t		Limite;
	RelaysType  Relays;
} RadioBandType;

//-----------------------------------------------------------------------------
static const RadioBandType sRadioBands[RADIO_BAND_SIZE] =
{					// Current,    HamMin,    HamMax,    Limite
	{ eBand80m, eCW,  3600000L,  3500000L,  4000000L,  4800000L, { 9, 1, 0, 0, 0, 0, 0 } },
	{ eBand60m, eCW,  5352000L,  5260000L,  5403500L,  5800000L, { 6, 0, 1, 0, 0, 0, 0 } },		// UK version
	{ eBand40m, eCW,  7100000L,  7000000L,  7300000L,  7800000L, { 5, 0, 1, 0, 0, 0, 0 } },		// Region 2, 3
	{ eBand30m, eCW, 10100000L, 10100000L, 10150000L, 11800000L, { 4, 0, 0, 1, 0, 0, 0 } },
	{ eBand20m, eCW, 14100000L, 14000000L, 14350000L, 15500000L, { 3, 0, 0, 1, 0, 0, 0 } },
	{ eBand17m, eCW, 18100000L, 18068000L, 18168000L, 19600000L, { 2, 0, 0, 0, 1, 0, 0 } },
	{ eBand15m, eCW, 21100000L, 21000000L, 21450000L, 23200000L, { 2, 0, 0, 0, 1, 0, 0 } },
	{ eBand12m, eCW, 24900000L, 24890000L, 24990000L, 27000000L, { 1, 0, 0, 0, 0, 1, 0 } },
	{ eBand10m, eCW, 28100000L, 28000000L, 29700000L, 32000000L, { 1, 0, 0, 0, 0, 1, 0 } },
	{ eBand6m,  eCW, 50100000L, 50000000L, 54000000L, 54000000L, { 0, 0, 0, 0, 0, 0, 1 } },
};

//-----------------------------------------------------------------------------
int16_t Settings::getAdcAux()
{
	mSettings.AdcAux = std::max((int16_t) 50, std::min((int16_t) 200, mSettings.AdcAux));

	return mSettings.AdcAux;
}
//-----------------------------------------------------------------------------
int16_t Settings::getAdcMic()
{
	mSettings.AdcMic = std::max((int16_t) 100, std::min((int16_t) 500, mSettings.AdcMic));

	return mSettings.AdcMic;
}
//-----------------------------------------------------------------------------
eAgcType Settings::getAgcSpeed()
{
	return mSettings.Memories[getMemory()].ModeData.AgcSpeed;
}
//-----------------------------------------------------------------------------
std::string Settings::getAgcSpeedStr()
{
	static const char * AgcList[] = { "Fast", "Mid.", "Slow" };

	return AgcList[getAgcSpeed()];
}
//-----------------------------------------------------------------------------
std::string Settings::getSpeakerStr()
{
	return Format().Fmt("%d", getSpeaker());
}
//-----------------------------------------------------------------------------
eLightType Settings::getBackLight()
{
	return mSettings.BackLight;
}
//-----------------------------------------------------------------------------
eBandType Settings::getBand()
{
	eBandType result = eBand6m;
	int32_t freq = getFrequency(getMemory());

	for (int16_t i = 0; i < RADIO_BAND_SIZE; i ++)
	{
		if (freq <= sRadioBands[i].Limite)
		{
			result = sRadioBands[i].Band;
			break;
		}
	}

	return result;
}
//-----------------------------------------------------------------------------
std::string Settings::getBandStr()
{
	static const int16_t BandList[] = { 80, 60, 40, 30, 20, 17, 15, 12, 10, 6 };

	return Format().Fmt("%3dm", BandList[getBand()]);
}
//-----------------------------------------------------------------------------
bool Settings::getBlueTooth()
{
	return mSettings.BlueTooth;
}
//-----------------------------------------------------------------------------
int16_t Settings::getCwAudio()
{
	mSettings.CwAudio = std::max((int16_t) 0, std::min((int16_t) 20, mSettings.CwAudio));

	return mSettings.CwAudio;
}
//-----------------------------------------------------------------------------
int16_t Settings::getCwDelay()
{
	mSettings.CwDelay = std::max((int16_t) 50, std::min((int16_t) 1000, mSettings.CwDelay));

	return mTuneMode ? 0 : mSettings.CwDelay;
}
//-----------------------------------------------------------------------------
eCwKeyType Settings::getCwKey()
{
	return mTuneMode ? eStraightKey : mSettings.CwKey;
}
//-----------------------------------------------------------------------------
int16_t Settings::getCwPitch()
{
	mSettings.CwPitch = std::max((int16_t) 400, std::min((int16_t) 1000, mSettings.CwPitch));

	return mSettings.CwPitch;
}
//-----------------------------------------------------------------------------
std::string Settings::getCwPitchStr()
{
	return Format().Fmt("%dhz", getCwPitch());
}
//-----------------------------------------------------------------------------
bool Settings::getCwPractice()
{
	if (mTuneMode) return false;
	if (getMode() != eCW) return false;

	return mSettings.CwPractice;
}
//-----------------------------------------------------------------------------
int16_t Settings::getCwSpeed()
{
	mSettings.CwSpeed = std::max((int16_t) 5, std::min((int16_t) 40, mSettings.CwSpeed));

	return mSettings.CwSpeed;
}
//-----------------------------------------------------------------------------
std::string Settings::getCwSpeedStr()
{
	return Format().Fmt("%dwpm", getCwSpeed());
}
//-----------------------------------------------------------------------------
char * Settings::getCwMsgs(int16_t msg)
{
	return mSettings.CwMsgs[msg];
}
//-----------------------------------------------------------------------------
int16_t Settings::getDacAux()
{
	mSettings.DacAux = std::max((int16_t) 0, std::min((int16_t) 20, mSettings.DacAux));

	return mSettings.DacAux;
}
//-----------------------------------------------------------------------------
bool Settings::getDegreCF()
{
	return mSettings.DegreCF;
}
//-----------------------------------------------------------------------------
bool Settings::getDspStatus()
{
	return mSettings.DspStatus;
}
//-----------------------------------------------------------------------------
int16_t Settings::getDspValue()
{
	if (mSettings.DspStatus)
		return std::max((int16_t) 1, std::min((int16_t) 20, mSettings.DspValue));

	return 0;
}
//-----------------------------------------------------------------------------
std::string	Settings::getDspValueStr()
{
	return "Notch";
//	return Format().Fmt("Dsp %d", getDspValue());
}
//-----------------------------------------------------------------------------
int16_t Settings::getFilter()
{
	static const int16_t loList[] = {  100, 1600, 1600,  3000,  3000, 3300, 3300 };		// eCW, eSSBL, eSSBU, eAM, eFM, eDIGL, eDIGU
	static const int16_t hiList[] = { 1000, 3000, 3000, 10000, 10000, 3300, 3300 };

	int16_t mem  = getMemory();
	int16_t mode = getMode();

	int16_t filter = mSettings.Memories[mem].ModeData.Filter;

	if (mTuneMode == false)														// tune switch to CW and change filter
	{
		filter = std::max(loList[mode], std::min(hiList[mode], filter));

		mSettings.Memories[mem].ModeData.Filter = filter;
	}

	return filter;
}
//-----------------------------------------------------------------------------
std::string Settings::getFilterStr()
{
	float32_t value = getFilter();

	if (value < 1000.0f)
		return Format().Fmt("%fhz", value);

	return Format().Fmt("%.1fkhz", value / 1000);
}
//-----------------------------------------------------------------------------
int32_t Settings::getFrequency(int16_t mem)
{
	return mSettings.Memories[mem].BandData.Freq;
}
//-----------------------------------------------------------------------------
int16_t Settings::getFftSmooth()
{
	mSettings.FftSmooth = std::max((int16_t) 1, std::min((int16_t) 5, mSettings.FftSmooth));

	return mSettings.FftSmooth;
}
//-----------------------------------------------------------------------------
int16_t Settings::getFftWidth()
{
	mSettings.FftWidth = std::max((int16_t) 1, std::min((int16_t) 4, mSettings.FftWidth));

	return mSettings.FftWidth;
}
//-----------------------------------------------------------------------------
std::string Settings::getFftWidthStr()
{
	return Format().Fmt("%dk", 24 / getFftWidth());
}
//-----------------------------------------------------------------------------
bool Settings::getMarsCap()
{
	return mSettings.MarsCap;
}
//-----------------------------------------------------------------------------
int16_t Settings::getMemory()
{
	switch(mSettings.Vfo)
	{
	case eVfoA:
		return mSettings.MemoryA;

	default:
		return mSettings.MemoryB;
	}
}
//-----------------------------------------------------------------------------
std::string Settings::getMemoryStr()
{
	int16_t mem = getMemory();

	switch(mem)
	{
	case 0:
		return "VFO A";

	case 1:
		return "VFO B";

	default:
		return Format().Fmt("%02d", mem - 1);
	}
}
//-----------------------------------------------------------------------------
int16_t Settings::getMenuDelay()
{
	mSettings.MenuDelay = std::max((int16_t) 2, std::min((int16_t) 30, mSettings.MenuDelay));

	return mSettings.MenuDelay;
}
//-----------------------------------------------------------------------------
eModeType Settings::getMode()
{
	return mTuneMode ? eCW : mSettings.Memories[getMemory()].BandData.Mode;
}
//-----------------------------------------------------------------------------
std::string Settings::getModeStr()
{
	static const char * ModeList[] = { "CW", "LSB", "USB", "AM", "FM", "DIG-L", "DIG-U" };

	return ModeList[getMode()];
}
//-----------------------------------------------------------------------------
int16_t Settings::getPower()
{
	int16_t power = mSettings.Memories[getMemory()].ModeData.Power;

	switch(getBand())
	{
	case eBand6m:
		power = std::max((int16_t) 100, std::min((int16_t) 5'000, power));
		break;

	default:
		power = std::max((int16_t) 100, std::min((int16_t) 20'000, power));
		break;
	}

	mSettings.Memories[getMemory()].ModeData.Power = power;

	return mTuneMode ? 5'000 : power;
}
//-----------------------------------------------------------------------------
std::string Settings::getPowerStr()
{
	return Format().Fmt("%.1fw", getPower() / 1000.0f);
}
//-----------------------------------------------------------------------------
RelaysType Settings::getRelays()
{
	return sRadioBands[getBand()].Relays;
}
//-----------------------------------------------------------------------------
eRitKeyType Settings::getRitKey()
{
	return mSettings.Memories[getMemory()].ModeData.RitKey;
}
//-----------------------------------------------------------------------------
std::string Settings::getRitKeyStr()
{
	static const char * SplitList[] = { "RIT", "XIT", "T/R", "PTT" };

	if (isHamBand(NULL) || getMarsCap())
	{
		if (getRitStatus())
			return SplitList[getRitKey()];

		return "T=R";
	}

	return "RX";
}
//-----------------------------------------------------------------------------
bool Settings::getRitStatus()
{
	return mSettings.Memories[getMemory()].ModeData.RitStatus;
}
//-----------------------------------------------------------------------------
int16_t Settings::getRitValue()
{
	ModeType *modeType = &mSettings.Memories[getMemory()].ModeData;

	modeType->RitValue = std::max((int16_t) -9990, std::min((int16_t) 9990, modeType->RitValue));

	return modeType->RitValue;
}
//-----------------------------------------------------------------------------
std::string Settings::getRitValueStr()
{
	switch(getRitKey())
	{
	case eRit:
		return Format().Fmt("rit: %d", getRitValue());

	case eXit:
		return Format().Fmt("xit: %d", getRitValue());

	case eSplit:
		return "split";

	default:
		return "as ptt";
	}
}
//-----------------------------------------------------------------------------
bool Settings::getRxAtt()
{
	return mSettings.Memories[getMemory()].BandData.RxAtt;
}
//-----------------------------------------------------------------------------
std::string Settings::getRxAttStr()
{
	static const char * AttList[] = { "Att.", "---" };

	return AttList[getRxAtt()];
}
//-----------------------------------------------------------------------------
int32_t Settings::getRxFrequency()
{
	int16_t mem = getMemory();

	if (getRitStatus())
	{
		switch(getRitKey())
		{
		case eRit:
			return getFrequency(mem) + getRitValue();

		case eSplit:
			return getVfoAfreq();

		default:
			break;
		}
	}

	return getFrequency(mem);
}
//-----------------------------------------------------------------------------
int16_t Settings::getSpeaker()
{
	mSettings.Speaker = std::max((int16_t) 0, std::min((int16_t) 20, mSettings.Speaker));

	return mSettings.Speaker;
}
//-----------------------------------------------------------------------------
int16_t Settings::getSqlValue()
{
	mSettings.SqlValue = std::max((int16_t) 0, std::min((int16_t) 90, mSettings.SqlValue));

	return mSettings.SqlValue;
}
//-----------------------------------------------------------------------------
std::string Settings::getSqlValueStr()
{
	return Format().Fmt("%d", getSqlValue());
}
//-----------------------------------------------------------------------------
eFreqStep Settings::getStep()
{
	return mSettings.Memories[getMemory()].ModeData.Step;
}
//-----------------------------------------------------------------------------
int32_t Settings::getStepFreq()
{
	static const int32_t StepList[] = { 10, 100, 500, 1000, 5000, 10'000, 100'000, 1000'000 };

	return StepList[getStep()];
}
//-----------------------------------------------------------------------------
bool Settings::getTuneMode()
{
	return mTuneMode;
}
//-----------------------------------------------------------------------------
int32_t Settings::getTxFrequency()
{
	int16_t mem = getMemory();

	if (getRitStatus())
	{
		switch(getRitKey())
		{
		case eXit:
			return getFrequency(mem) + getRitValue();

		case eSplit:
			return getVfoBfreq();

		default:
			break;
		}
	}

	return getFrequency(mem);
}
//-----------------------------------------------------------------------------
eVfoType Settings::getVfo()
{
	return mSettings.Vfo;
}
//-----------------------------------------------------------------------------
int32_t Settings::getVfoA(bool transmit)
{
	int32_t freq = getVfoAfreq();

	if ((getRitStatus()) && (getVfo() == eVfoA))
	{
		switch(getRitKey())
		{
		case eRit:
			if (transmit == false) freq += getRitValue();
			break;

		case eXit:
			if (transmit) freq += getRitValue();

		default:
			break;
		}
	}

	return freq;
}
//-----------------------------------------------------------------------------
int32_t Settings::getVfoB(bool transmit)
{
	int32_t freq = getVfoBfreq();

	if ((getRitStatus()) && (getVfo() == eVfoB))
	{
		switch(getRitKey())
		{
		case eRit:
			if (transmit == false) freq += getRitValue();
			break;

		case eXit:
			if (transmit) freq += getRitValue();

		default:
			break;
		}
	}

	return freq;
}
//-----------------------------------------------------------------------------
int32_t Settings::getVfoAfreq()
{
	return getFrequency(mSettings.MemoryA);
}
//-----------------------------------------------------------------------------
int32_t Settings::getVfoBfreq()
{
	return getFrequency(mSettings.MemoryB);
}
//-----------------------------------------------------------------------------
//
//-----------------------------------------------------------------------------
void Settings::setBand(eBandType value)
{
	eBandType band;
	int16_t mem  = getMemory();

	if (isHamBand(&band))
	{
		eModeType mode = mSettings.Memories[mem].BandData.Mode;

		mSettings.Bands[band].RxAtt  = mSettings.Memories[mem].BandData.RxAtt;
		mSettings.Bands[band].Freq = mSettings.Memories[mem].BandData.Freq;
		mSettings.Bands[band].Mode = mode;

		mSettings.Modes[mode].AgcSpeed = mSettings.Memories[mem].ModeData.AgcSpeed;
		mSettings.Modes[mode].Power    = mSettings.Memories[mem].ModeData.Power;
		mSettings.Modes[mode].Filter   = mSettings.Memories[mem].ModeData.Filter;
		mSettings.Modes[mode].Step     = mSettings.Memories[mem].ModeData.Step;
	}

	eModeType mode = mSettings.Bands[value].Mode;

	mSettings.Memories[mem].BandData.RxAtt  = mSettings.Bands[value].RxAtt;
	mSettings.Memories[mem].BandData.Freq = mSettings.Bands[value].Freq;
	mSettings.Memories[mem].BandData.Mode = mode;

	mSettings.Memories[mem].ModeData.AgcSpeed = mSettings.Modes[mode].AgcSpeed;
	mSettings.Memories[mem].ModeData.Power    = mSettings.Modes[mode].Power;
	mSettings.Memories[mem].ModeData.Filter   = mSettings.Modes[mode].Filter;
	mSettings.Memories[mem].ModeData.Step     = mSettings.Modes[mode].Step;
}
//-----------------------------------------------------------------------------
void Settings::setCwKey(eCwKeyType value)
{
	 mSettings.CwKey = value;
}
//-----------------------------------------------------------------------------
void Settings::setFrequency(int16_t mem, int32_t value)
{
	value = std::max((int32_t) 522'000L, std::min((int32_t) 54'000'000L, value));

	mSettings.Memories[mem].BandData.Freq = value;
}
//-----------------------------------------------------------------------------
void Settings::setMemory(int16_t value)
{
	switch(mSettings.Vfo)
	{
	case eVfoA:
		mSettings.MemoryA = value;
		break;

	default:
		mSettings.MemoryB = value;
		break;
	}
}
//-----------------------------------------------------------------------------
void Settings::setMode(eModeType value)
{
	int16_t mem = getMemory();
	eModeType mode = mSettings.Memories[mem].BandData.Mode;

	mSettings.Modes[mode].AgcSpeed = mSettings.Memories[mem].ModeData.AgcSpeed;
	mSettings.Modes[mode].Power    = mSettings.Memories[mem].ModeData.Power;
	mSettings.Modes[mode].Filter   = mSettings.Memories[mem].ModeData.Filter;
	mSettings.Modes[mode].Step     = mSettings.Memories[mem].ModeData.Step;

	mSettings.Modes[mode].RitKey    = mSettings.Memories[mem].ModeData.RitKey;
	mSettings.Modes[mode].RitValue  = mSettings.Memories[mem].ModeData.RitValue;
	mSettings.Modes[mode].RitStatus = mSettings.Memories[mem].ModeData.RitStatus;

	mSettings.Memories[mem].BandData.Mode = value;

	mSettings.Memories[mem].ModeData.AgcSpeed = mSettings.Modes[value].AgcSpeed;
	mSettings.Memories[mem].ModeData.Power    = mSettings.Modes[value].Power;
	mSettings.Memories[mem].ModeData.Filter   = mSettings.Modes[value].Filter;
	mSettings.Memories[mem].ModeData.Step     = mSettings.Modes[value].Step;

	mSettings.Memories[mem].ModeData.RitKey    = mSettings.Modes[value].RitKey;
	mSettings.Memories[mem].ModeData.RitValue  = mSettings.Modes[value].RitValue;
	mSettings.Memories[mem].ModeData.RitStatus = mSettings.Modes[value].RitStatus;
}
//-----------------------------------------------------------------------------
void Settings::setPreampli(bool value)
{
	mSettings.Memories[getMemory()].BandData.RxAtt = value;
}
//-----------------------------------------------------------------------------
void Settings::setRitStatus(bool value)
{
	mSettings.Memories[getMemory()].ModeData.RitStatus = value;
}
//-----------------------------------------------------------------------------
void Settings::setSpeaker(int16_t value)
{
	mSettings.Speaker = value;
}
//-----------------------------------------------------------------------------
void Settings::setTuneMode(bool value)
{
	mTuneMode = value;
}
//-----------------------------------------------------------------------------
void Settings::setVfoA()
{
	mSettings.Vfo = eVfoA;
}
//-----------------------------------------------------------------------------
void Settings::setVfoB()
{
	mSettings.Vfo = eVfoB;
}
//-----------------------------------------------------------------------------
void Settings::setVfoAfreq(int32_t value)
{
	setFrequency(mSettings.MemoryA, value);
}
//-----------------------------------------------------------------------------
void Settings::setVfoBfreq(int32_t value)
{
	setFrequency(mSettings.MemoryB, value);
}
//-----------------------------------------------------------------------------
//
//-----------------------------------------------------------------------------
std::string Settings::changeAdcAux(int16_t value)
{
	mSettings.AdcAux += value * 2;

	return Format().Fmt("Aux-Input-Level: %d", getAdcAux());
}
//-----------------------------------------------------------------------------
std::string Settings::changeAdcMic(int16_t value)
{
	mSettings.AdcMic += value * 2;

	return Format().Fmt("Mic-Input-Level: %d", getAdcMic());
}
//-----------------------------------------------------------------------------
std::string	Settings::changeBackLight(int16_t value)
{
	static const char * BackLight[] = { "Timed", "Always On", "Always Off" };

	if (value > 0)
	{
		switch(mSettings.BackLight)
		{
		case eBlDelayed:
			mSettings.BackLight = eBlAlwaysOn;
			break;

		case eBlAlwaysOn:
			mSettings.BackLight = eBlAlwaysOff;
			break;

		default:
			mSettings.BackLight = eBlAlwaysOff;
			break;
		}
	}

	if (value < 0)
	{
		switch(mSettings.BackLight)
		{
		case eBlAlwaysOff:
			mSettings.BackLight = eBlAlwaysOn;
			break;

		case eBlAlwaysOn:
			mSettings.BackLight = eBlDelayed;
			break;

		default:
			mSettings.BackLight = eBlDelayed;
			break;
		}
	}

	return Format().Fmt("Back-Light: %s", BackLight[mSettings.BackLight]);
}
//-----------------------------------------------------------------------------
void Settings::changeBand(int16_t value)
{
	int16_t band = getBand() + value;

	setBand((eBandType) std::max((int16_t) eBand80m, std::min((int16_t) eBand6m, band)));
}
//-----------------------------------------------------------------------------
std::string	Settings::changeCwAudio(int16_t value)
{
	mSettings.CwAudio += value;

	return Format().Fmt("Cw-Level: %d", getCwAudio());
}
//-----------------------------------------------------------------------------
std::string	Settings::changeCwDelay(int16_t value)
{
	mSettings.CwDelay += (value * 10);

	return Format().Fmt("Cw-Delay: %dms", getCwDelay());
}
//-----------------------------------------------------------------------------
std::string	Settings::changeCwKey(int16_t value)
{
	static const char * CwKeyList[] = { "Iambic-A Regul", "Iambic-A Rev", "Iambic-B Regul", "Iambic-B Rev", "Straight Key" };

	if (value > 0)
	{
		switch(mSettings.CwKey)
		{
		case eIambicRegA:
			mSettings.CwKey = eIambicRevA;
			break;

		case eIambicRevA:
			mSettings.CwKey = eIambicRegB;
			break;

		case eIambicRegB:
			mSettings.CwKey = eIambicRevB;
			break;

		case eIambicRevB:
			mSettings.CwKey = eStraightKey;
			break;

		default:
			mSettings.CwKey = eStraightKey;
			break;
		}
	}

	if (value < 0)
	{
		switch(mSettings.CwKey)
		{
		case eStraightKey:
			mSettings.CwKey = eIambicRevB;
			break;

		case eIambicRevB:
			mSettings.CwKey = eIambicRegB;
			break;

		case eIambicRegB:
			mSettings.CwKey = eIambicRevA;
			break;

		case eIambicRevA:
			mSettings.CwKey = eIambicRegA;
			break;

		default:
			mSettings.CwKey = eIambicRegA;
			break;
		}
	}

	return Format().Fmt("Cw-Key: %s", CwKeyList[mSettings.CwKey]);
}
//-----------------------------------------------------------------------------
std::string	Settings::changeCwPitch(int16_t value)
{
	mSettings.CwPitch += (value * 50);

	return Format().Fmt("Cw-Pitch: %s", getCwPitchStr().c_str());
}
//-----------------------------------------------------------------------------
std::string	Settings::changeCwSpeed(int16_t value)
{
	mSettings.CwSpeed += value;

	return Format().Fmt("Cw-Speed: %s", getCwSpeedStr().c_str());
}
//-----------------------------------------------------------------------------
std::string Settings::changeDacAux(int16_t value)
{
	mSettings.DacAux += value;

	return Format().Fmt("Aux-Output-Level: %d", getDacAux());
}
//-----------------------------------------------------------------------------
std::string Settings::changeDegreCF(int16_t value)
{
	static const char * tempList[] = { "Celsius", "Fahrenheit" };

	if (value > 0) mSettings.DegreCF = true;
	if (value < 0) mSettings.DegreCF = false;

	return Format().Fmt("Temperature: %s", tempList[mSettings.DegreCF]);
}
//-----------------------------------------------------------------------------
std::string Settings::changeDspValue(int16_t value)
{
	mSettings.DspValue += value;

	return Format().Fmt("Dsp-Noise: %d", getDspValue());
}
//-----------------------------------------------------------------------------
std::string	Settings::changeFilter(int16_t value)
{
	static const int16_t incList[] = { 100, 100, 100, 1000, 1000, 0, 0 };				// eCW, eSSBL, eSSBU, eAM, eFM, eDIGL, eDIGU

	mSettings.Memories[getMemory()].ModeData.Filter += (value * incList[getMode()]);

	return Format().Fmt("Audio-Filter: %s", getFilterStr().c_str());
}
//-----------------------------------------------------------------------------
void Settings::changeFrequency(int32_t value)
{
	if (value)
	{
		int16_t mem  = getMemory();
		int32_t step = getStepFreq();
		int32_t freq = getFrequency(mem);

		int32_t modulo = (freq % step);

		if ((value < 0) && modulo) step = 0;

//		if (std::abs(value) > 4) step *= 10;

		freq += (value * step);
		freq -= modulo;

		setFrequency(mem, freq);
	}
}
//-----------------------------------------------------------------------------
std::string Settings::changeFftSmooth(int16_t value)
{
	mSettings.FftSmooth += value;

	return Format().Fmt("Fft-Smooth: %d", getFftSmooth());
}
//-----------------------------------------------------------------------------
std::string Settings::changeFftWidth(int16_t value)
{
	if (value > 0) mSettings.FftWidth >>= 1;
	if (value < 0) mSettings.FftWidth <<= 1;

	return Format().Fmt("Fft-Width: %s", getFftWidthStr().c_str());
}
//-----------------------------------------------------------------------------
std::string	Settings::changeMarsCap(int16_t value)
{
	static const char * MarsCapList[] = { "Mars/Cap: Ham-Bands", "Mars/Cap: Extended" };

	if (value > 0)
		mSettings.MarsCap = true;

	if (value < 0)
		mSettings.MarsCap = false;

	return MarsCapList[mSettings.MarsCap];
}
//-----------------------------------------------------------------------------
std::string	Settings::changeMemory(int16_t value)
{
	if (value > 0)
	{
		switch(mSettings.Vfo)
		{
		case eVfoA:
			mSettings.MemoryA = std::min((int16_t) (VFO_MEM_SIZE - 1), (int16_t) (mSettings.MemoryA + 1));
			if (mSettings.MemoryA == 1) mSettings.MemoryA ++;						// 1 is for VfoB
			break;

		default:
			mSettings.MemoryB = std::min((int16_t) (VFO_MEM_SIZE - 1), (int16_t) (mSettings.MemoryB + 1));
			break;
		}
	}

	if (value < 0)
	{
		switch(mSettings.Vfo)
		{
		case eVfoA:
			mSettings.MemoryA = std::max((int16_t) 0, (int16_t) (mSettings.MemoryA - 1));
			if (mSettings.MemoryA == 1) mSettings.MemoryA --;						// 1 is for VfoB
			break;

		default:
			mSettings.MemoryB = std::max((int16_t) 1, (int16_t) (mSettings.MemoryB - 1));
			break;
		}
	}

	return Format().Fmt("Vfo/Memory: %s", getMemoryStr().c_str());
}
//-----------------------------------------------------------------------------
std::string	Settings::changeMenuDelay(int16_t value)
{
	mSettings.MenuDelay += value;

	return Format().Fmt("Menu-Delay: %ds", getMenuDelay());
}
//-----------------------------------------------------------------------------
std::string	Settings::changePower(int16_t value)
{
	int16_t count = (std::abs(value) > 2) ? 1000 : 100;
	int16_t power = mSettings.Memories[getMemory()].ModeData.Power;

	if (value < 0)
	{
		power -= count;
		power -= (power % count);
	}

	if (value > 0)
	{
		power += count;
		power -= (power % count);
	}

	mSettings.Memories[getMemory()].ModeData.Power = power;

	return Format().Fmt("Power: %s", getPowerStr().c_str());
}
//-----------------------------------------------------------------------------
std::string Settings::changeRitKey(int16_t value)
{
	static const char * RitKeyList[] = { "Rit", "Xit", "Split", "Ptt" };

	ModeType *modeType = &mSettings.Memories[getMemory()].ModeData;

	if (value > 0)
	{
		modeType->RitStatus = false;
		resetRitValue();

		switch (modeType->RitKey)
		{
		case eRit:
			modeType->RitKey = eXit;
			break;

		case eXit:
			modeType->RitKey = eSplit;
			break;

		default:
			modeType->RitKey = ePtt;
			break;
		}
	}

	if (value < 0)
	{
		modeType->RitStatus = false;
		resetRitValue();

		switch (modeType->RitKey)
		{
		case ePtt:
			modeType->RitKey = eSplit;
			break;

		case eSplit:
			modeType->RitKey = eXit;
			break;

		default:
			modeType->RitKey = eRit;
			break;
		}
	}

	return Format().Fmt("Rit-Key for %s as: %s", getModeStr().c_str(), RitKeyList[modeType->RitKey]);
}
//-----------------------------------------------------------------------------
std::string Settings::changeRitValue(int16_t value)
{
	mSettings.Memories[getMemory()].ModeData.RitValue += (value * 10);

	return getRitValueStr();
}
//-----------------------------------------------------------------------------
std::string Settings::changeSpeaker(int16_t value)
{
	mSettings.Speaker += value;

	return getSpeakerStr();
}
//-----------------------------------------------------------------------------
std::string	Settings::changeSqlValue(int16_t value)
{
	mSettings.SqlValue += (value * 2);

	return Format().Fmt("Squelch: %s", getSqlValueStr().c_str());
}
//-----------------------------------------------------------------------------
std::string Settings::changeStep(int16_t value)
{
	static const char *StepList[] = { "10Hz", "100Hz", "500Hz", "1kHz", "5kHz", "10kHz", "100kHz", "1MHz" };

	int16_t mem = getMemory();

	if (value > 0)
	{
		switch(getStep())
		{
		case eStep1m:
			mSettings.Memories[mem].ModeData.Step = eStep100k;
			break;

		case eStep100k:
			mSettings.Memories[mem].ModeData.Step = eStep10k;
			break;

		case eStep10k:
			mSettings.Memories[mem].ModeData.Step = eStep5k;
			break;

		case eStep5k:
			mSettings.Memories[mem].ModeData.Step = eStep1k;
			break;

		case eStep1k:
			mSettings.Memories[mem].ModeData.Step = eStep500;
			break;

		case eStep500:
			mSettings.Memories[mem].ModeData.Step = eStep100;
			break;

		default:
			mSettings.Memories[mem].ModeData.Step = eStep10;
			break;
		}
	}

	if (value < 0)
	{
		switch(getStep())
		{
		case eStep10:
			mSettings.Memories[mem].ModeData.Step = eStep100;
			break;

		case eStep100:
			mSettings.Memories[mem].ModeData.Step = eStep500;
			break;

		case eStep500:
			mSettings.Memories[mem].ModeData.Step = eStep1k;
			break;

		case eStep1k:
			mSettings.Memories[mem].ModeData.Step = eStep5k;
			break;

		case eStep5k:
			mSettings.Memories[mem].ModeData.Step = eStep10k;
			break;

		case eStep10k:
			mSettings.Memories[mem].ModeData.Step = eStep100k;
			break;

		default:
			mSettings.Memories[mem].ModeData.Step = eStep1m;
			break;
		}
	}

	return Format().Fmt("Tune step: %s", StepList[getStep()]);
}
//-----------------------------------------------------------------------------
//
//-----------------------------------------------------------------------------
void Settings::switchAgcSpeed()
{
	int16_t mem = getMemory();

	switch (getAgcSpeed())
	{
	case eAgcS:
		mSettings.Memories[mem].ModeData.AgcSpeed = eAgcM;
		break;

	case eAgcM:
		mSettings.Memories[mem].ModeData.AgcSpeed = eAgcF;
		break;

	default:
		mSettings.Memories[mem].ModeData.AgcSpeed = eAgcS;
		break;
	}
}
//-----------------------------------------------------------------------------
void Settings::switchAttenuator()
{
	setPreampli(getRxAtt() ? false : true);
}
//-----------------------------------------------------------------------------
void Settings::switchBlueTooth()
{
	mSettings.BlueTooth = !mSettings.BlueTooth;
}
//-----------------------------------------------------------------------------
void Settings::switchDsp()
{
	mSettings.DspStatus = !mSettings.DspStatus;
}
//-----------------------------------------------------------------------------
void Settings::switchModeSSB()
{
	switch (getMode())
	{
	case eSSBL:
		setMode(eSSBU);
		break;

	case eSSBU:
		setMode(eDIGL);
		break;

	case eDIGL:
		setMode(eDIGU);
		break;

	default:
		setMode(eSSBL);
		break;
	}
}
//-----------------------------------------------------------------------------
void Settings::switchModeCW()
{
	switch (getMode())
	{
	case eCW:
		mSettings.CwPractice = !mSettings.CwPractice;
		break;

	default:
		mSettings.CwPractice = false;
		setMode(eCW);
		break;
	}

	if (gServiceMode) mSettings.CwPractice = false;
}
//-----------------------------------------------------------------------------
void Settings::switchModeAM()
{
	switch (getMode())
	{
	case eAM:
		setMode(eFM);
		break;

	default:
		setMode(eAM);
		break;
	}
}
//-----------------------------------------------------------------------------
void Settings::switchRit()
{
	setRitStatus(getRitStatus() == false);
}
//-----------------------------------------------------------------------------
void Settings::switchVfo()
{
	switch(mSettings.Vfo)
	{
	case eVfoA:
		mSettings.Vfo = eVfoB;
		break;

	default:
		mSettings.Vfo = eVfoA;
		break;
	}
}
//-----------------------------------------------------------------------------
void Settings::vfoAtoVfoB()
{
	int16_t src;
	int16_t dst;

	switch(mSettings.Vfo)
	{
	case eVfoA:
		src = mSettings.MemoryA;
		dst = mSettings.MemoryB;
		break;

	default:
		src = mSettings.MemoryB;
		dst = mSettings.MemoryA;
		break;
	}

	mSettings.Memories[dst].BandData.RxAtt  = mSettings.Memories[src].BandData.RxAtt;
	mSettings.Memories[dst].BandData.Freq = mSettings.Memories[src].BandData.Freq;
	mSettings.Memories[dst].BandData.Mode = mSettings.Memories[src].BandData.Mode;

	mSettings.Memories[dst].ModeData.Step     = mSettings.Memories[src].ModeData.Step;
	mSettings.Memories[dst].ModeData.Filter   = mSettings.Memories[src].ModeData.Filter;
	mSettings.Memories[dst].ModeData.AgcSpeed = mSettings.Memories[src].ModeData.AgcSpeed;
	mSettings.Memories[dst].ModeData.Power    = mSettings.Memories[src].ModeData.Power;
}
//-----------------------------------------------------------------------------
void Settings::resetRitValue()
{
	mSettings.Memories[getMemory()].ModeData.RitValue = 0;
}
//-----------------------------------------------------------------------------
bool Settings::isHamBand(eBandType *value)
{
	int32_t freq = getTxFrequency();

	for (int16_t i = 0; i < RADIO_BAND_SIZE; i ++)
	{
		if (freq < sRadioBands[i].HamMax)
		{
			if (freq >= sRadioBands[i].HamMin)
			{
				if (value != NULL) *(value) = sRadioBands[i].Band;
				return true;
			}
		}
	}

	return false;
}
//-----------------------------------------------------------------------------
bool Settings::isPractice()
{
	return (getMode() == eCW) && getCwPractice();
}
//-----------------------------------------------------------------------------
bool Settings::canTransmit()
{
	return (isHamBand(nullptr) || getMarsCap());
}
//-----------------------------------------------------------------------------
void Settings::Init(bool flag)
{
	mTuneMode = false;

	for (int16_t page = 0; page < SETTING_PAGE; page ++)
	{
		gI2cData.ReadPage(AT24C16, SETTING_ADDR + page, mSettings.buffer[page]);
		memcpy(mSetCache.buffer[page], mSettings.buffer[page], PAGE_SIZE);
	}

	flag |= (mSettings.Magic != MAGIC_SETTING);

	if (flag)
	{
		memset(mSettings.buffer, 0xFF, sizeof(mSettings.buffer));

		mSettings.Magic = MAGIC_SETTING;

		for (int16_t i = 0; i < RADIO_MODE_SIZE; i ++)
		{
			switch(i)
			{
			case eCW:
				mSettings.Modes[i].AgcSpeed = eAgcM;
				mSettings.Modes[i].Power = 10'000;								// 10.0W
				mSettings.Modes[i].Filter = 800;
				mSettings.Modes[i].Step = eStep100;
				break;

			case eSSBL:
			case eSSBU:
				mSettings.Modes[i].AgcSpeed = eAgcS;
				mSettings.Modes[i].Power = 500;									// 0.5W
				mSettings.Modes[i].Filter = 2700;
				mSettings.Modes[i].Step = eStep1k;
				break;

			case eAM:
			case eFM:
				mSettings.Modes[i].AgcSpeed = eAgcS;
				mSettings.Modes[i].Power = 500;									// 0.5W
				mSettings.Modes[i].Filter = 5000;
				mSettings.Modes[i].Step = eStep1k;
				break;

			default:
				mSettings.Modes[i].AgcSpeed = eAgcS;
				mSettings.Modes[i].Power = 500;									// 0.5W
				mSettings.Modes[i].Filter = 3300;
				mSettings.Modes[i].Step = eStep1k;
				break;
			}

			mSettings.Modes[i].RitKey = eRit;
			mSettings.Modes[i].RitValue = 0;
			mSettings.Modes[i].RitStatus = false;
		}

		for (int16_t i = 0; i < RADIO_BAND_SIZE; i ++)
		{
			mSettings.Bands[i].RxAtt = true;									// (true = no attenuator)
			mSettings.Bands[i].Freq  = sRadioBands[i].Current;
			mSettings.Bands[i].Mode  = sRadioBands[i].Mode;
		}

		for (int16_t i = 0; i < VFO_MEM_SIZE; i ++)
		{
			mSettings.Memories[i].BandData.RxAtt  = mSettings.Bands[eBand80m].RxAtt;
			mSettings.Memories[i].BandData.Freq = mSettings.Bands[eBand80m].Freq;
			mSettings.Memories[i].BandData.Mode = mSettings.Bands[eBand80m].Mode;

			mSettings.Memories[i].ModeData.AgcSpeed = mSettings.Modes[eCW].AgcSpeed;
			mSettings.Memories[i].ModeData.Power    = mSettings.Modes[eCW].Power;
			mSettings.Memories[i].ModeData.Filter   = mSettings.Modes[eCW].Filter;
			mSettings.Memories[i].ModeData.Step     = mSettings.Modes[eCW].Step;

			mSettings.Memories[i].ModeData.RitKey    = mSettings.Modes[eCW].RitKey;
			mSettings.Memories[i].ModeData.RitValue  = mSettings.Modes[eCW].RitValue;
			mSettings.Memories[i].ModeData.RitStatus = mSettings.Modes[eCW].RitStatus;
		}

		mSettings.BlueTooth  = false;
		mSettings.MarsCap    = false;
		mSettings.CwPractice = false;
		mSettings.DegreCF    = false;
		mSettings.DspStatus  = false;

		mSettings.DspStatus = false;												// force noise dsp off
		mSettings.DspValue  = 4;

		mSettings.BackLight = eBlDelayed;
		mSettings.MenuDelay = 5;

		mSettings.AdcAux = 100;
		mSettings.AdcMic = 200;
		mSettings.DacAux = 10;

		mSettings.Speaker  = 6;
		mSettings.SqlValue = 0;

		mSettings.FftSmooth = 3;
		mSettings.FftWidth  = 1;

		mSettings.CwKey   = eStraightKey;
		mSettings.CwSpeed = 15;
		mSettings.CwPitch = 800;
		mSettings.CwDelay = 400;
		mSettings.CwAudio = 6;

		mSettings.Vfo = eVfoA;
		mSettings.MemoryA = 0;													// 0 = VfoA, 2... = Memory
		mSettings.MemoryB = 1;													// 1 = VfoB, 2... = Memory

		strcpy(mSettings.CwMsgs[0], "CQ POTA DE ");
		strcpy(mSettings.CwMsgs[1], "CQ SOTA DE ");
		strcpy(mSettings.CwMsgs[2], "CQ CQ DE ");
		strcpy(mSettings.CwMsgs[3], "BK TU UR 599 5NN VA VA BK");
		strcpy(mSettings.CwMsgs[4], "TU ES 73 DE ");
	}
}
//-----------------------------------------------------------------------------
void Settings::Loop(Thread &thread)
{
	for (int16_t page = 0; page < SETTING_PAGE; page ++)
	{
		if (memcmp(mSetCache.buffer[page], mSettings.buffer[page], PAGE_SIZE))
		{
			memcpy(mSetCache.buffer[page], mSettings.buffer[page], PAGE_SIZE);
			gI2cData.WritePage(AT24C16, SETTING_ADDR + page, mSettings.buffer[page]);
			thread.Delay(10L);
		}
	}
}
//-----------------------------------------------------------------------------
