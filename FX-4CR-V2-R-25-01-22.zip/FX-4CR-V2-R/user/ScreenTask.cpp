/*
 * This file is part of the FX-4CR-V2 project.
 * See: https://github.com/f5bud/FX-4CR-V2
 *
 * Copyright (c) 2024 Daniel Nespoulous, F5BUD
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE. 
 */
//-----------------------------------------------------------------------------
//	ScreenTask.cpp
//-----------------------------------------------------------------------------
#include "ScreenTask.h"
#include "ScreenColors.h"

//-----------------------------------------------------------------------------
ScreenTask gScreenTask;

//-----------------------------------------------------------------------------
void ScreenTask::Handler()
{
	gScreenTask.Loop();
}
//-----------------------------------------------------------------------------
void ScreenTask::Loop()
{
	bool clearFull = false;

	LabelDecoType msgRx = { GRAY6, WHITE, GRAY6, FONT6, eCenter };
	LabelDecoType msgCw = { GRAY6, WHITE, GRAY6, FONT5, eRight };

	ClearBuffer(0, LCD_HEIGHT, BLACK);
	LcdService::Init(*this);

	while (1)
	{
		DrawBuffer();
		setState(SUSPENDED);

		ClearBuffer(0, clearFull ? 240 : 192, BLACK);

		eRadioType radioType = gUserTask.getRadioType();

		showStatus(radioType);
		showRadio();

		clearFull = true;

		if (mTransmit != gRadioTask.isOnAir())
		{
			mTransmit = gRadioTask.isOnAir();

			mMeterCnt = 0;
			mMeterMax = 0;
		}

		if (gServiceMode)
		{
			clearFull = false;

			msgRx.bgcolor = GREEN4;

			switch(radioType)
			{
			case eRadioStd:
			case eRadioLock:
				msgRx.text = "Service Mode";
				DrawLabel(10, 150, 299, msgRx);
				break;

			default:
				msgRx.text = gUserTask.getMenuText();
				DrawLabel(10, 150, 299, msgRx);
				break;
			}

			continue;
		}

		if (mTransmit)
		{
			DrawLabel(10, 150, 299, getSwrAlcDeco());

			switch (gUserTask.getMode())
			{
			case eCW:
				msgCw.align   = eRight;
				msgCw.bgcolor = RED3;
				msgCw.text    = gUserTask.getMenuValue();
				DrawLabel(10, 190, 299, msgCw);
				break;

			case eSSBL:
			case eSSBU:
			case eAM:
			case eFM:
				msgCw.align = eCenter;
				msgCw.bgcolor = RED3;
				msgCw.text = gUserTask.getMenuValue();
				DrawLabel(10, 190, 299, msgCw);

			default:
				break;
			}

			continue;
		}

		switch(radioType)
		{
		case eRadioStd:
		case eRadioLock:
			if (gUserTask.isPractice())
			{
				msgRx.text = "Practice mode";
				DrawLabel(10, 150, 299, msgRx);

				msgCw.align   = eRight;
				msgCw.bgcolor = GRAY6;
				msgCw.text    = gUserTask.getMenuValue();
				DrawLabel(10, 190, 299, msgCw);
			}
			else
			{
				clearFull = false;
				DrawWaterFall(0, 145, SCREEN_SIZE, getWaterFallDeco());
			}
			break;

		case eRadioCaller:
			DrawCallerList(5, 143, SCREEN_SIZE, getCallerListDeco());
			break;

		default:
			msgRx.text = gUserTask.getMenuText();
			DrawLabel(10, 150, 299, msgRx);

			msgCw.align   = eCenter;
			msgCw.bgcolor = GRAY6;
			msgCw.text    = gUserTask.getMenuValue();
			DrawLabel(10, 190, 299, msgCw);
			break;
		}
	}
}
//-----------------------------------------------------------------------------
void ScreenTask::showText(const char *text)
{
	DrawLabel(110, 150, 110, { YELLOW1, WHITE, GRAY6, FONT6, eCenter, text } );
	DrawBuffer();
}
//-----------------------------------------------------------------------------
void ScreenTask::showRadio()
{
	DrawLabel (  5,  25, 66, getModeDeco());
	DrawLabel (  5,  51, 66, getVfoDeco());
	DrawLabel (  5,  77, 66, getVolDeco());
	DrawLabel (  5,  98, 66, getDspDeco());
	DrawLabel (  5, 119, 66, getSqlDeco());

	DrawFilter(249,  25, 66, getFilterDeco());
	DrawLabel (249,  56, 66, getRitDeco());
	DrawLabel (249,  77, 66, getPwrDeco());
	DrawLabel (249,  98, 66, getCwSpeedDeco());
	DrawLabel (249, 119, 66, getCwPitchDeco());

	DrawFrequ (80,  30, 160, getVfoADeco());
	DrawStep  (80,  63, 160, getStepDeco());
	DrawFrequ (80,  70, 160, getVfoBDeco());
	DrawMeter (80, 105, 160, getMeterDeco());
}
//-----------------------------------------------------------------------------
void ScreenTask::showStatus(eRadioType radioType)
{
	mFgColor  = GRAY1;
	mBgColor  = (radioType == eRadioLock) ? RED5 : BLUE5;
	mLcdFont  = FONT5;

	DrawRect(0, 0, SCREEN_SIZE, mLcdFont->yAdvance + 4, mBgColor);

	DrawText(gUserTask.getRitKeyStr()  .c_str(),  10, 2, 32, eCenter);
	DrawText(gUserTask.getRxAttStr()   .c_str(),  42, 2, 38, eCenter);
	DrawText(gUserTask.getAgcSpeedStr().c_str(),  80, 2, 38, eCenter);
	DrawText(gUserTask.getCallerStr()  .c_str(), 118, 2, 22, eCenter);
	DrawText(gRadioTask.getRssiDbStr() .c_str(), 160, 2, 55, eCenter);
	DrawText(gRadioTask.getTempStr()   .c_str(), 215, 2, 40, eCenter);
	DrawText(gRadioTask.getVoltStr()   .c_str(), 255, 2, 55, eCenter);

	mFgColor = YELLOW1;
	mLcdFont = SYMB1;

	DrawText(getBlueToothStr().c_str(), 140, 2, 20, eCenter);
}
//-----------------------------------------------------------------------------
void ScreenTask::DrawCallerList	(int16_t x, int16_t y, int16_t w, CallerListDeco deco)
{
	static const char * MsgKeyStr[] = { "SSB: ", "M.V: ", "A.B: ", ".FM: ", "RIT: " };
	static const char * MsgDelStr[] = { "Call once",
		"Call every 15 seconds", "Call every 30 seconds",
		"Call every 45 seconds", "Call every 60 seconds" };

	mFgColor  = deco.fgcolor;
	mBgColor  = deco.bgcolor;
	mLcdFont  = deco.lcdFont;

	for (int16_t i = 0; i < MY_MSG_COUNT; i ++)
	{
		std::string temp = MsgKeyStr[i];

		temp.append((gUserTask.getMode() == eCW) ? gUserTask.getCwMsgs(i) : MsgDelStr[i]);

		DrawText(temp.c_str(), x, y, w, eLeft);

		y += mLcdFont->yAdvance;
	}
}
//-----------------------------------------------------------------------------
void ScreenTask::DrawFilter(int16_t x, int16_t y, int16_t w, FilterDecoType deco)
{
	mBdColor  = deco.bdcolor;
	mFgColor  = deco.fgcolor;
	mBgColor  = deco.bgcolor;
	mLcdFont  = deco.lcdFont;

	DrawBox(x, y, w, 30);

	int16_t width = getFilterWidth();
	int16_t xGapp = w / 2;
	int16_t yGapp = 12;

	switch(deco.mode)
	{
	case -1:			// LSB, DIG-L
		xGapp -= (width + 2);
		break;
	case 1: 			// USB, DIG-U
		xGapp += 1;
		break;
	default:			// CW, AM, FM
		xGapp = (w - width) / 2;
		break;
	}

	while (yGapp > 4)
	{
		DrawHLine(x + xGapp, y + yGapp --, width, RED3);
		DrawHLine(x + xGapp, y + yGapp --, width, RED3);
		DrawHLine(x + xGapp, y + yGapp --, width, RED3);

		xGapp ++;
		width -= 2;
	}

	DrawText(gUserTask.getFilterStr().c_str(), x, y + 15, w, eCenter);

	DrawHLine(x, y + 15, w - 1, mBdColor);
	DrawVLine(x + (w / 2) - 1, y, 15, mBdColor);
}
//-----------------------------------------------------------------------------
void ScreenTask::DrawFrequ(int16_t x, int16_t y, int16_t w, FrequDecoType deco)
{
	mFgColor  = deco.fgcolor;
	mLcdFont  = deco.lcdFont;

	DrawText(deco.text.c_str(), x, y, w, eRight);
}
//-----------------------------------------------------------------------------
void ScreenTask::DrawLabel(int16_t x, int16_t y, int16_t w, LabelDecoType deco)
{
	if (deco.text.empty() == false)
	{
		mBdColor  = deco.bdcolor;
		mFgColor  = deco.fgcolor;
		mBgColor  = deco.bgcolor;
		mLcdFont  = deco.lcdFont;

		DrawBox(x, y, w, mLcdFont->yAdvance + 4);

		DrawText(deco.text.c_str(), x, y + 2, w, deco.align);
	}
}
//-----------------------------------------------------------------------------
void ScreenTask::DrawLevel(int16_t x, int16_t y, int16_t w, MeterDecoType deco)
{
	int16_t value1 = std::min((int16_t) w, (int16_t) ((deco.value1 * w) / 100));
	int16_t value2 = std::min((int16_t) w, (int16_t) ((deco.value2 * w) / 102));		// not an error !!!
	int16_t value3 = std::min((int16_t) w, (int16_t) ((deco.value3 * w) / 102));		// not an error !!!

	DrawRect(x, y, w, 16, GRAY4);

	if (value2 > 0) DrawRect(x, y, value2, 16, YELLOW2);
	if (value1 > 0) DrawRect(x, y, value1, 16, GREEN2);
	if (value3 > 0) DrawRect(x + value3, y + 3, 2, 10, YELLOW1);
}
//-----------------------------------------------------------------------------
void ScreenTask::DrawMeter(int16_t x, int16_t y, int16_t w, MeterDecoType deco)
{
	mFgColor = YELLOW1;
	mLcdFont = deco.lcdFont;

	if (mTransmit)
	{
		DrawText("_1___5____10___15__20W", x, y, w, eLeft);
	}
	else
	{
		DrawText("1__3__5__7__9", x, y, w, eLeft);

		mFgColor = RED1;
		DrawText("_______________20_40_60", x, y, w, eLeft);
	}

	DrawLevel(x, y + 2 + deco.lcdFont->yAdvance, w, deco);
}
//-----------------------------------------------------------------------------
void ScreenTask::DrawStep(int16_t x, int16_t y, int16_t w, StepDecoType deco)
{
	mLcdFont = deco.lcdFont;

	int16_t advance = mLcdFont->glyph->xAdvance;								// fixed font width
	int16_t width = advance;
	const char *chr = FreqToStr(gUserTask.getStepFreq()).c_str();

	x += w;																		// right aligned

	if (*(chr) == '5')
	{
		x -= advance;
		width += advance;
	}

	while (*(chr ++))
	{
		x -= advance;
	}

	DrawRect(x, y, width, 3, deco.fgcolor);
}
//-----------------------------------------------------------------------------
void ScreenTask::DrawWaterFall(int16_t x, int16_t y, int16_t w, WaterFDecoType deco)	// y = 145, height = 46
{
	int16_t left = w / 2;

	switch(deco.mode)
	{
	case -1:			// LSB, DIG-L
		left -= deco.width;
		break;

	case 0:				// CW, AM, FM
		left -= (deco.width / 2);
		break;
	}

	mFgColor = deco.fgcolor;
	mLcdFont = FONT4;

	DrawRect(left + 1, y, deco.width, 45, deco.bgcolor);						// band wide

	DrawHLine(0, y +  0, w, mFgColor);
	DrawHLine(0, y + 23, w, mFgColor);
	DrawHLine(0, y + 46, w, mFgColor);

	DrawVLine(  0, y + 1, 45, mFgColor);
	DrawVLine( 80, y + 1, 45, mFgColor);
	DrawVLine(160, y + 1, 45, mFgColor);
	DrawVLine(240, y + 1, 45, mFgColor);
	DrawVLine(319, y + 1, 45, mFgColor);

	DrawText(("-" + gUserTask.getFftWidthStr()).c_str(), 8, y + 5, SCREEN_SIZE - 16, eLeft);
	DrawText("___0k",                                    8, y + 5, SCREEN_SIZE - 16, eCenter);
	DrawText(("+" + gUserTask.getFftWidthStr()).c_str(), 8, y + 5, SCREEN_SIZE - 16, eRight);

	WaterFall(x, y + 46, w);
}
//-----------------------------------------------------------------------------
void ScreenTask::WaterFall(int16_t x, int16_t y, int16_t w)						// y = 191, height = 48
{
	int32_t *array = gRadioTask.getRssiArray();
	int32_t freq   = gUserTask.getRxFrequency();
	int16_t delta  = ((freq - mCurrentFreq) * w) / 48000;						// fc = 96000 ->

	uint16_t color = gWaterFallColors[0];
	uint16_t *line  = getLine(y + 1);

	std::memmove(getLine(y + 2), line, w * 47 * 2);								// 47 lines (uint16_t)

	MoveTo(x, y);

	for (x = 0; x < w; x ++)
	{
		int16_t zz = array[x];

		LineTo(x, y - zz - 1, WHITE);

		line[x] = gWaterFallColors[zz / 3];										// 0..45

		if (delta > 0)
		{
			for (int16_t yy = 0; yy < 48; yy ++)
			{
				uint16_t *line  = getLine(y + yy);

				if ((x + delta) < w)
					line[x] = line[x + delta];
				else
					line[x] = color;
			}
		}

		if (delta < 0)
		{
			for (int16_t yy = 0; yy < 48; yy ++)
			{
				uint16_t *line  = getLine(y + yy);

				int16_t xxx = w - x - 1;

				if ((xxx + delta) > 0)
					line[xxx] = line[xxx + delta];
				else
					line[xxx] = color;
			}
		}
	}

	mCurrentFreq = freq;
}
//-----------------------------------------------------------------------------
int16_t ScreenTask::getFilterWidth()
{
	return 10 + (gUserTask.getFilter() * 46) / 9900;							// freq 100::10000, width 10::56
}
//-----------------------------------------------------------------------------
LabelDecoType ScreenTask::getCwPitchDeco()
{
	if (gUserTask.getMode() == eCW)
		return { WHITE, YELLOW1, GRAY6, FONT4, eCenter, gUserTask.getCwPitchStr() };

	return { GRAY2, GRAY2, GRAY6, FONT4, eCenter, gUserTask.getCwPitchStr() };
}
//-----------------------------------------------------------------------------
LabelDecoType ScreenTask::getCwSpeedDeco()
{
	if (gUserTask.getMode() == eCW)
	{
		switch(gUserTask.getCwKey())
		{
		case eIambicRegA:
		case eIambicRevA:
		case eIambicRegB:
		case eIambicRevB:
			return { WHITE, YELLOW1, GRAY6, FONT4, eCenter, gUserTask.getCwSpeedStr() };
		default:
			break;
		}
	}

	return { GRAY2, GRAY2, GRAY6, FONT4, eCenter, gUserTask.getCwSpeedStr() };
}
//-----------------------------------------------------------------------------
LabelDecoType ScreenTask::getDspDeco()
{
	std::string temp = gUserTask.getDspValueStr();

	if (gUserTask.getDspStatus())
		return { WHITE, YELLOW1, GRAY6, FONT4, eCenter, temp };

	return { GRAY2, GRAY2, GRAY6, FONT4, eCenter, temp };
}
//-----------------------------------------------------------------------------
LabelDecoType ScreenTask::getModeDeco()
{
	uint16_t color = gUserTask.isPractice() ? GREEN2 : RED3;

	return { WHITE, WHITE, color, FONT5, eCenter, gUserTask.getModeStr() };
}
//-----------------------------------------------------------------------------
LabelDecoType ScreenTask::getPwrDeco()
{
	return { GRAY2, GRAY2, GRAY6, FONT4, eCenter, gUserTask.getPowerStr() };
}
//-----------------------------------------------------------------------------
LabelDecoType ScreenTask::getRitDeco()
{
	if (gUserTask.getRitStatus() || (gUserTask.getRitKey() == ePtt))
		return { WHITE, YELLOW1, GRAY6, FONT4, eCenter, gUserTask.getRitValueStr() };

	return { GRAY2, GRAY2, GRAY6, FONT4, eCenter, "no rit" };
}
//-----------------------------------------------------------------------------
LabelDecoType ScreenTask::getSqlDeco()
{
	if (gUserTask.getSqlValue())
		return { WHITE, YELLOW1, GRAY6, FONT4, eCenter, "Sql " + gUserTask.getSqlValueStr() };

	return { GRAY2, GRAY2, GRAY6, FONT4, eCenter, "Sql " + gUserTask.getSqlValueStr() };
}
//-----------------------------------------------------------------------------
LabelDecoType ScreenTask::getSwrAlcDeco()
{
	return { RED3, WHITE, RED3, FONT6, eCenter, gRadioTask.getSwrAlcStr() };
}
//-----------------------------------------------------------------------------
LabelDecoType ScreenTask::getVfoDeco()
{
	return { WHITE, YELLOW1, GRAY6, FONT5, eCenter, gUserTask.getMemoryStr() };
}
//-----------------------------------------------------------------------------
LabelDecoType ScreenTask::getVolDeco()
{
	switch(gUserTask.getRadioType())
	{
	case eRadioStd:
	case eRadioLock:
	case eRadioCaller:
		return { WHITE, YELLOW1, GRAY6, FONT4, eCenter, "Vol " + gUserTask.getSpeakerStr() };

	default:
		return { GRAY2, GRAY2, GRAY6, FONT4, eCenter, "Vol " + gUserTask.getSpeakerStr() };
	}
}
//-----------------------------------------------------------------------------
CallerListDeco ScreenTask::getCallerListDeco()
{
	return { YELLOW1, GRAY6, FONT5 };
}
//-----------------------------------------------------------------------------
FilterDecoType ScreenTask::getFilterDeco()
{
	int16_t mode = 0;

	switch(gUserTask.getMode())
	{
//	case eCWL:
	case eSSBL:
	case eDIGL:
		mode = -1;
		break;

//	case eCWU:
	case eSSBU:
	case eDIGU:
		mode = 1;

	default:
		break;
	}

	return { GRAY2, YELLOW1, GRAY6, FONT4, mode };
}
//-----------------------------------------------------------------------------
MeterDecoType ScreenTask::getMeterDeco()
{
	int16_t value1;
	int16_t value3;

	if (mTransmit)
	{
		value1 = gRadioTask.getWatt() * 5;								// 20W * 5 = 100%


		value3 = gUserTask.getPower() / 200;							// 20'000 / 200 = 100%
	}
	else
	{
		value1 = gRadioTask.getSmeter();								// 0 ... 100%
		value3 = gUserTask.getSqlValue();								// 0 ... 100%
	}

	if (value1 >= mMeterMax)
	{
		mMeterCnt = 0;
		mMeterMax = value1;
	}

	if (mMeterCnt ++ > 8)
		mMeterMax = std::max((int16_t) 0, (int16_t) (mMeterMax - 2));

	return { FONT4, value1, mMeterMax, value3 };
}
//-----------------------------------------------------------------------------
StepDecoType ScreenTask::getStepDeco()
{
	return { YELLOW1, DIGI1 };
}
//-----------------------------------------------------------------------------
FrequDecoType ScreenTask::getVfoADeco()
{
	uint16_t color = (gUserTask.getVfo() == eVfoA) ? WHITE : GRAY4;

	if (gUserTask.getRitStatus() && (gUserTask.getRitKey() == eSplit) && mTransmit)
		color = GRAY4;

	return { color, DIGI1, FreqToStr(gUserTask.getVfoA(mTransmit)) };
}
//-----------------------------------------------------------------------------
FrequDecoType ScreenTask::getVfoBDeco()
{
	uint16_t color = (gUserTask.getVfo() == eVfoB) ? WHITE : GRAY4;

	if (gUserTask.getRitStatus() && (gUserTask.getRitKey() == eSplit) && mTransmit)
		color = WHITE;

	return { color, DIGI1, FreqToStr(gUserTask.getVfoB(mTransmit)) };
}
//-----------------------------------------------------------------------------
WaterFDecoType ScreenTask::getWaterFallDeco()
{
	int16_t mode = 0;

	switch(gUserTask.getMode())
	{
//	case eCWL:
	case eSSBL:
	case eDIGL:
		mode = -1;
		break;

//	case eCWU:
	case eSSBU:
	case eDIGU:
		mode = 1;

	default:
		break;
	}

	int16_t width  = std::min(160, (160 * gUserTask.getFilter()) / (int16_t) (L24000 / gUserTask.getFftWidth()));

	return { GRAY4, YELLOW6, mode, width };
}
//-----------------------------------------------------------------------------
std::string ScreenTask::getBlueToothStr()
{
	static const char * BltStr[] = { "2", "3" };

	if (gUserTask.getBlueTooth())
	{
		return BltStr[gUserTask.getBltCnted()];
	}

	return "/";
}
//-----------------------------------------------------------------------------
std::string ScreenTask::FreqToStr(int32_t value)
{
	int16_t i = 0;
	char buffer[32];
	char *str = buffer + sizeof buffer;

	*(-- str) = 0;

	value /= 10;				// saute 1Hz

	while (value)
	{
		switch(i ++)
		{
		case 2:
		case 6:
			*(-- str) = '.';
			break;

		default:
			*(-- str) = '0' + (value % 10);
			value /= 10;
			break;
		}
	}

	return str;
}
//-----------------------------------------------------------------------------
