/*
 * This file is part of the FX-4CR-V2 project.
 * See: https://github.com/f5bud/FX-4CR-V2
 *
 * Copyright (c) 2024 Daniel Nespoulous, F5BUD
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE. 
 */
//-----------------------------------------------------------------------------
//	ScreenTask.h
//-----------------------------------------------------------------------------
#ifndef INC_SCREENTASK_H_
#define INC_SCREENTASK_H_

//-----------------------------------------------------------------------------
#include "RadioTask.h"
#include "UserTask.h"
#include "LcdService.h"

//-----------------------------------------------------------------------------
typedef struct
{
	uint16_t	bdcolor;		// border color
	uint16_t	fgcolor;		// text color
	uint16_t	bgcolor;		// background color

	LCDFont		*lcdFont;
	eAlign		align;
	std::string	text;
} LabelDecoType;

typedef struct
{
	uint16_t	bdcolor;		// border color
	uint16_t	fgcolor;		// text color
	uint16_t	bgcolor;		// background color

	LCDFont		*lcdFont;
	int16_t		mode;			// -1 = LSB, = AM-FM, 1 = USB
} FilterDecoType;

typedef struct
{
	uint16_t	fgcolor;		// text color
	LCDFont		*lcdFont;
	std::string	text;
} FrequDecoType;

typedef struct
{
	uint16_t	fgcolor;		// text color
	LCDFont		*lcdFont;
} StepDecoType;

typedef struct
{
	LCDFont		*lcdFont;
	int16_t		value1;			// level
	int16_t		value2;			// delayed max value
	int16_t		value3;			// sql or power
} MeterDecoType;

typedef struct
{
	uint16_t	fgcolor;
	uint16_t	bgcolor;
	int16_t		mode;			// -1 = LSB, = AM-FM, 1 = USB
	int16_t		width;
} WaterFDecoType;

typedef struct
{
	uint16_t	fgcolor;
	uint16_t	bgcolor;
	LCDFont		*lcdFont;
} CallerListDeco;

//-----------------------------------------------------------------------------
#define SCREENSTACK_SIZE 512				// (size * 4)

//-----------------------------------------------------------------------------
class ScreenTask : public Thread, public LcdService
{
private:
	bool	mTransmit;
	int32_t	mCurrentFreq;

	int16_t	mMeterCnt;
	int16_t	mMeterMax;

	static void Handler();

	void Loop();

	void showRadio	();
	void showStatus	(eRadioType radioType);

	void DrawCallerList	(int16_t x, int16_t y, int16_t w, CallerListDeco deco);
	void DrawFilter		(int16_t x, int16_t y, int16_t w, FilterDecoType deco);
	void DrawFrequ		(int16_t x, int16_t y, int16_t w, FrequDecoType deco);
	void DrawLabel		(int16_t x, int16_t y, int16_t w, LabelDecoType deco);
	void DrawLevel		(int16_t x, int16_t y, int16_t w, MeterDecoType deco);
	void DrawMeter		(int16_t x, int16_t y, int16_t w, MeterDecoType deco);
	void DrawStep		(int16_t x, int16_t y, int16_t w, StepDecoType deco);
	void DrawWaterFall	(int16_t x, int16_t y, int16_t w, WaterFDecoType deco);
	void WaterFall		(int16_t x, int16_t y, int16_t w);

	int16_t		getFilterWidth	();

	LabelDecoType getCwPitchDeco();
	LabelDecoType getCwSpeedDeco();
	LabelDecoType getDspDeco	();
	LabelDecoType getModeDeco	();
	LabelDecoType getPwrDeco	();
	LabelDecoType getRitDeco	();
	LabelDecoType getSqlDeco	();
	LabelDecoType getSwrAlcDeco	();
	LabelDecoType getVfoDeco	();
	LabelDecoType getVolDeco	();

	CallerListDeco	getCallerListDeco();
	FilterDecoType	getFilterDeco	 ();
	MeterDecoType	getMeterDeco	 ();
	StepDecoType	getStepDeco		 ();
	FrequDecoType	getVfoADeco		 ();
	FrequDecoType	getVfoBDeco		 ();
	WaterFDecoType	getWaterFallDeco ();

	std::string getBlueToothStr		 ();
	std::string FreqToStr			 (int32_t value);

public:
	ScreenTask():Thread(Handler, SCREENSTACK_SIZE) { }

	void showText(const char *text);
};
//-----------------------------------------------------------------------------
extern ScreenTask gScreenTask;

#endif
