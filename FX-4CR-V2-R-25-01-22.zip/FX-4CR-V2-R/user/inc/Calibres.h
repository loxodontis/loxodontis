/*
 * This file is part of the FX-4CR-V2 project.
 * See: https://github.com/f5bud/FX-4CR-V2
 *
 * Copyright (c) 2024 Daniel Nespoulous, F5BUD
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE. 
 */
//-----------------------------------------------------------------------------
//	Calibres.h
//-----------------------------------------------------------------------------
#ifndef INC_CALIBRES_H_
#define INC_CALIBRES_H_

//-----------------------------------------------------------------------------
#include "Defines.h"
#include "I2cData.h"								// for PAGE_SIZE
#include "Kernel.h"

//-----------------------------------------------------------------------------
static constexpr int32_t MAGIC_CALIBRE = 0x24425549;

//-----------------------------------------------------------------------------
union CalibresType
{
	struct
	{
		uint32_t		Magic;							// crc of config

		int16_t			VoltCal;						// Tension meter calibration
		int16_t			WattCal;						// Power meter calibration
		int16_t			RssiCal;						// Smeter calibration
		int32_t			TcxoCal;						// Si5351 clock calibration

		SetBandType		Bands[RADIO_BAND_SIZE];			// [eBandType]
	};

	uint8_t buffer[CALIBRE_PAGE][PAGE_SIZE];			// (0x10 pages)
};

//static char (*azerty)[sizeof(CalibresType)] = 1;		// astuce pour afficher taille

//-----------------------------------------------------------------------------
class Calibres
{
private:
	CalibresType	mCalibres;
	CalibresType	mCalCache;

	uint8_t		getValue		(const char *buffer);

public:
	SetBandType &getBandConf	(int16_t band);
	int16_t		getRssiCal		();
	int32_t		getTcxoCal		();
	int16_t		getVoltCal		();
	int16_t		getWattCal		();

	std::string	changeRssiCal	(int16_t value);
	std::string	changeRxMag		(int16_t value, int16_t band);
	std::string	changeRxPha		(int16_t value, int16_t band);
	std::string	changeTcxoCal	(int16_t value);
	std::string	changeTxMag		(int16_t value, int16_t band);
	std::string	changeTxPha		(int16_t value, int16_t band);
	std::string	changeTxPower	(int16_t value, int16_t band);
	std::string	changeVoltCal	(int16_t value);
	std::string	changeWattCal	(int16_t value);

	void		Init			();
	void		Loop			(Thread &thread);

	std::string	Export			(const char *buffer);
	bool		Import			(const char *buffer);
};
//-----------------------------------------------------------------------------
#endif
