/*
 * This file is part of the FX-4CR-V2 project.
 * See: https://github.com/f5bud/FX-4CR-V2
 *
 * Copyright (c) 2024 Daniel Nespoulous, F5BUD
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
//-----------------------------------------------------------------------------
//	Defines.h
//-----------------------------------------------------------------------------
#ifndef INC_DEFINES_H_
#define INC_DEFINES_H_

//-----------------------------------------------------------------------------
#include "System.h"

//-----------------------------------------------------------------------------
#define VERSION	"2.02"			// 4 characters max (Cat control)

#define BUILD_VERSION	 ("V" VERSION " / " __DATE__)
#define HARDWARE_VERSION ("Hardware: 2024-R")

//-----------------------------------------------------------------------------
constexpr int32_t L96000 = 96013L;											// 98.317307MHz / 1024 = 96012,99
constexpr int32_t L24000 = 24003L;											// 98.317307MHz / 4096 = 24003,24

constexpr int16_t SAMPLE_SIZE = 512;
constexpr int16_t FFT_SIZE    = SAMPLE_SIZE * 2;
constexpr int16_t FFT_48000   = FFT_SIZE    / 2;							// Fft Result
constexpr int16_t FFT_24000   = FFT_SIZE    / 4;							// 24kHz = center

constexpr int32_t VOICE_SIZE  = SAMPLE_SIZE * 117;							// 512 * 117 = 59904 / 6000 = 9,984 Seconds
constexpr int32_t VOICE_SIZE8 = ((VOICE_SIZE >> 3) + 1) << 3;				// ((59904 >> 3) + 1) << 3 = 59912

constexpr int16_t SCREEN_SIZE = 320;
//-----------------------------------------------------------------------------

#define RADIO_BAND_SIZE 10
#define RADIO_MODE_SIZE  7
#define VFO_MEM_SIZE    52														// [eVfoA, eVfoB, MemX]

#define CALIBRE_ADDR	0x00
#define CALIBRE_PAGE	0x10													// [0x10 pages reserved for calibres]

#define SETTING_ADDR	0x10
#define SETTING_PAGE	0x70													// [0x70 pages reserved for settings]

#define MY_MSG_SIZE		30
#define MY_MSG_COUNT	 5

//-----------------------------------------------------------------------------
//	typedef enum
//-----------------------------------------------------------------------------
enum eRadioType
{
	eRadioStd,			// normal mode
	eRadioLock,			// locked mode
	eRadioMenu,			// MENU   pressed
	eRadioFilter,		// FILTER pressed
	eRAdioMemory,		// M.V    pressed
	eRadioPwr,			// PWR    pressed
	eRadioCw,			// AF     pressed
	eRadioSql,			// AF     pressed
	eRadioDsp,			// AF     pressed
	eRadioTune,			// TUNE   pressed
	eRadioFunc,			// FUNC   pressed
	eRadioRitKey,		// RIT    pressed
	eRadioCaller		// Caller launcher
};

enum eVfoType
{
	eVfoA,
	eVfoB
};

enum eFreqStep
{
	eStep10,
	eStep100,
	eStep500,
	eStep1k,
	eStep5k,
	eStep10k,
	eStep100k,
	eStep1m
};

enum eRitKeyType
{
	eRit,
	eXit,
	eSplit,
	ePtt
};

enum eBandType
{
	eBand80m,
	eBand60m,
	eBand40m,
	eBand30m,
	eBand20m,
	eBand17m,
	eBand15m,
	eBand12m,
	eBand10m,
	eBand6m
};

enum eModeType
{
	eCW,
	eSSBL,
	eSSBU,
	eAM,
	eFM,
	eDIGL,
	eDIGU
};

enum eAgcType
{
	eAgcF,
	eAgcM,
	eAgcS
};

enum eCwKeyType
{
	eIambicRegA,									// A Normal  paddle
	eIambicRevA,									// A Reverse paddle
	eIambicRegB,									// B Normal  paddle
	eIambicRevB,									// B Reverse paddle
	eStraightKey,									// right keyer
	eCallerCw										// SideTone generator
};

enum eCallerType
{
	eCallerUsr1,										// Cw Msg 1 or Call voice once
	eCallerUsr2,										// Cw Msg 2 or Call voice every 15 seconds
	eCallerUsr3,										// Cw Msg 3 or Call voice every 30 seconds
	eCallerUsr4,										// Cw Msg 4 or Call voice every 45 seconds
	eCallerUsr5,										// Cw Msg 5 or Call voice every 60 seconds
};

enum eLightType
{
	eBlDelayed,
	eBlAlwaysOn,
	eBlAlwaysOff
};

enum eInputType
{
	eRxIQ,											// Rx mode
	eTxNone,										// Tx on but no modulation
	eTxKey,											// Tx morse key or iambic
	eTxAux,											// Tx adc from usb & bt
	eTxMic,											// Tx micro int or ext

	eVxMonitor,										// Voice monitor memory -> audio  (radio in Rx mode)
	eVxRecord,										// Voice record  audio  -> memory (radio in Rx mode)
	eVxPlayer										// Voice player  memory -> mixer  (radio in Tx mode)
};

//-----------------------------------------------------------------------------
typedef struct											// From settings
{
	int16_t		RxTxFilter: 4;
	int16_t		TxRelay0  : 1;
	int16_t		TxRelay1  : 1;
	int16_t		TxRelay2  : 1;
	int16_t		TxRelay3  : 1;
	int16_t		TxRelay4  : 1;
	int16_t		TxRelay5  : 1;
} RelaysType;

//-----------------------------------------------------------------------------
typedef struct											// From Calibrate
{
	int16_t		RxMag;									// balance IQ amplitude
	int16_t		RxPha;									// balance IQ phase

	int16_t		TxMag;									// balance IQ amplitude
	int16_t		TxPha;									// balance IQ phase

	int16_t		TxPower;								// Calibre value to 10.0W
} SetBandType;

//-----------------------------------------------------------------------------
typedef struct											// From RadioTask
{
	int16_t		AdcAux;
	int16_t		AdcMic;
	eAgcType	AgcSpeed;
	bool		RxAtt;
	eBandType	Band;
	int16_t		CwPitch;
	int16_t		DacAux;
	bool		DspStatus;
//	int16_t		DspValue;
	eInputType	InputType;
	int16_t		Filter;
	eModeType	Mode;
	bool		Muted;
	RelaysType	Relays;
	int16_t		RssiCal;
	SetBandType SetBand;
	int16_t		Speaker;
	float32_t	TxPower;
} ParamType;

//-----------------------------------------------------------------------------
union VoiceType											// From SaiSwitch
{
	struct												// 512 * 118 + 1 = 60417
	{
		int32_t	Writer;
		int32_t	Reader;
		int8_t	Wave[VOICE_SIZE];					// ((59904 >> 3) + 1) << 3 = 59912 * 4 = 239648 on 262144 flash bytes
	};

	uint32_t buffer[VOICE_SIZE8];
};

//-----------------------------------------------------------------------------
extern bool gServiceMode;														// true = service mode

//-----------------------------------------------------------------------------
#endif
