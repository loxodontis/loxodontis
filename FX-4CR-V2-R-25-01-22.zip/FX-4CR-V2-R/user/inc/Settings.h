/*
 * This file is part of the FX-4CR-V2 project.
 * See: https://github.com/f5bud/FX-4CR-V2
 *
 * Copyright (c) 2024 Daniel Nespoulous, F5BUD
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE. 
 */
//-----------------------------------------------------------------------------
//	Settings.h
//-----------------------------------------------------------------------------
#ifndef INC_SETTINGS_H_
#define INC_SETTINGS_H_

//-----------------------------------------------------------------------------
#include "Defines.h"
#include "I2cData.h"								// for PAGE_SIZE
#include "Kernel.h"

//-----------------------------------------------------------------------------
static constexpr int32_t MAGIC_SETTING = 0x20425547;

//-----------------------------------------------------------------------------
typedef struct
{
	bool		RxAtt;							// Pre, ---, Att
	uint32_t	Freq;							// 522Khz - 54Mhz
	eModeType	Mode;							// CW-L, CW-U, LSB, USB, AM, FM, DIG-L, DIG-U
} BandType;

//-----------------------------------------------------------------------------
typedef struct
{
	eAgcType	AgcSpeed;						// Fast, middle, slow
	int16_t		Power;							// 0.1W - 20W
	int16_t		Filter;							// CW (100-1000), SSB (1500-3000), AM, FM (5000-6000)
	eFreqStep	Step;							// 10, 100, 1000, 1000

	eRitKeyType	RitKey;							// RIT key mode
	int16_t		RitValue;						// rit, xit, offset rx +- tx
	bool		RitStatus;						// 1: Rit, Xit or Split enable
} ModeType;

//-----------------------------------------------------------------------------
typedef struct
{
	BandType	BandData;
	ModeType	ModeData;
} MemoryType;

typedef char MyMsgType [MY_MSG_SIZE + 1];				// string len 30 + chr(0)
//-----------------------------------------------------------------------------
union SettingsType
{
	struct
	{
		uint32_t		Magic;							// crc of config

		bool			BlueTooth;						// 1: bluetooth enable
		bool			MarsCap;						// 1: Extended Tx
		bool			CwPractice;						// 1: tone without transmit
		bool			DegreCF;						// 0: degrees, 1: Fahrenheit

		bool			DspStatus;						// 1: Noise reduction enable
		int16_t			DspValue;						// 1 ... 9

		eLightType		BackLight;						// keyboard light
		int16_t			MenuDelay;						// menu delay

		int16_t			AdcAux;							// Adc audio gain for usb & bt
		int16_t			AdcMic;							// Adc audio gain for mic
		int16_t			DacAux;							// digital gain

		int16_t			Speaker;						// speaker gain
		int16_t			SqlValue;						// squelch level

		int16_t			FftSmooth;						// [1 ... 9]
		int16_t			FftWidth;						// 1, 2, 4 (24k, 12k, 6k)

		eCwKeyType		CwKey;							// morse key type
		int16_t			CwSpeed;						// PARIS speed
		int16_t			CwPitch;						// sidetone pitch
		int16_t			CwDelay;						//
		int16_t			CwAudio;						// sidetone gain

		eVfoType		Vfo;							// VfoA, VfoB
		int16_t			MemoryA;						// 0 = VfoA, 1 = VfoB, 2... = Memory
		int16_t			MemoryB;						// 0 = VfoA, 1 = VfoB, 2... = Memory

		ModeType		Modes[RADIO_MODE_SIZE];			// [eModeType]
		BandType		Bands[RADIO_BAND_SIZE];			// [eBandType]
		MemoryType		Memories[VFO_MEM_SIZE];

		MyMsgType		CwMsgs[MY_MSG_COUNT];			// CW messages
	};

	uint8_t buffer[SETTING_PAGE][PAGE_SIZE];			// (0x70 pages)
};

//static char (*azerty)[sizeof(SettingsType)] = 1;		// astuce pour afficher taille

//-----------------------------------------------------------------------------
class Settings
{
private:
	bool mTuneMode;

	SettingsType	mSettings;
	SettingsType	mSetCache;

public:
	int16_t		getAdcAux		();
	int16_t		getAdcMic		();
	eAgcType	getAgcSpeed		();
	std::string getAgcSpeedStr	();
	eLightType	getBackLight	();
	eBandType	getBand			();
	std::string getBandStr		();
	bool		getBlueTooth	();
	int16_t		getCwAudio		();
	int16_t		getCwDelay		();
	eCwKeyType	getCwKey		();
	int16_t		getCwPitch		();
	std::string getCwPitchStr	();
	bool		getCwPractice	();
	int16_t		getCwSpeed		();
	std::string getCwSpeedStr	();
	char *		getCwMsgs		(int16_t msg);
	int16_t		getDacAux		();
	bool		getDegreCF		();
	bool		getDspStatus	();
	int16_t		getDspValue		();
	std::string	getDspValueStr	();
	int16_t		getFilter		();
	std::string getFilterStr	();
	int32_t		getFrequency	(int16_t mem);									// used by FxControl
	int16_t		getFftSmooth	();
	int16_t		getFftWidth		();
	std::string getFftWidthStr	();
	bool		getMarsCap		();
	int16_t		getMemory		();
	std::string getMemoryStr	();
	int16_t		getMenuDelay	();
	eModeType	getMode			();
	std::string getModeStr		();
	int16_t		getPower		();
	std::string getPowerStr		();
	RelaysType	getRelays		();
	eRitKeyType	getRitKey		();
	std::string getRitKeyStr	();
	bool		getRitStatus	();
	int16_t		getRitValue		();
	std::string getRitValueStr	();
	bool	 	getRxAtt		();
	std::string getRxAttStr		();
	int32_t		getRxFrequency	();
	int16_t		getSpeaker		();
	std::string getSpeakerStr	();
	int16_t		getSqlValue		();
	std::string getSqlValueStr	();
	eFreqStep	getStep			();
	int32_t		getStepFreq		();
	bool		getTuneMode		();
	int32_t		getTxFrequency	();
	eVfoType	getVfo			();
	int32_t		getVfoA			(bool transmit);
	int32_t		getVfoB			(bool transmit);
	int32_t		getVfoAfreq		();
	int32_t		getVfoBfreq		();

	void		setBand			(eBandType value);
	void		setCwKey		(eCwKeyType value);
	void		setFrequency	(int16_t mem, int32_t value);					// used by FxControl
	void		setMemory		(int16_t value);
	void		setMode			(eModeType value);
	void		setPreampli		(bool value);
	void		setRitStatus	(bool value);
	void		setSpeaker		(int16_t value);
	void		setTuneMode		(bool value);
	void		setVfoA			();
	void		setVfoB			();
	void		setVfoAfreq		(int32_t value);
	void		setVfoBfreq		(int32_t value);

	std::string	changeAdcAux	(int16_t value);
	std::string	changeAdcMic	(int16_t value);
	std::string	changeBackLight	(int16_t value);
	void		changeBand		(int16_t value);
	std::string	changeCwAudio	(int16_t value);
	std::string	changeCwDelay	(int16_t value);
	std::string	changeCwKey		(int16_t value);
	std::string	changeCwPitch	(int16_t value);
	std::string	changeCwSpeed	(int16_t value);
	std::string	changeDacAux	(int16_t value);
	std::string changeDegreCF	(int16_t value);
	std::string changeDspValue	(int16_t value);
	std::string	changeFilter	(int16_t value);
	void		changeFrequency	(int32_t value);
	std::string changeFftSmooth	(int16_t value);
	std::string changeFftWidth	(int16_t value);
	std::string	changeMarsCap	(int16_t value);
	std::string	changeMemory	(int16_t value);
	std::string	changeMenuDelay	(int16_t value);
	std::string	changePower		(int16_t value);
	std::string	changePowerConv	(int16_t value);
	std::string changeRitKey	(int16_t value);
	std::string changeRitValue	(int16_t value);
	std::string	changeSpeaker	(int16_t value);
	std::string	changeSqlValue	(int16_t value);
	std::string	changeStep		(int16_t value);

	void		switchAgcSpeed	();
	void		switchAttenuator();
	void		switchBlueTooth	();
	void		switchDsp		();
	void		switchModeAM	();
	void		switchModeCW	();
	void		switchModeSSB	();
	void		switchRit		();
	void		switchVfo		();

	void		vfoAtoVfoB		();
	void		resetRitValue	();
	bool		isHamBand		(eBandType *value);
	bool		isPractice		();
	bool		canTransmit		();

	void		Init			(bool flag);
	void		Loop			(Thread &thread);
};
//-----------------------------------------------------------------------------
#endif
