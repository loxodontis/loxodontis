/*
 * This file is part of the FX-4CR-V2 project.
 * See: https://github.com/f5bud/FX-4CR-V2
 *
 * Copyright (c) 2024 Daniel Nespoulous, F5BUD
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE. 
 */
//-----------------------------------------------------------------------------
//	ScreenColors.h
//-----------------------------------------------------------------------------
#ifndef INC_SCREENCOLORS_H_
#define INC_SCREENCOLORS_H_

//-----------------------------------------------------------------------------
#include "System.h"

//-----------------------------------------------------------------------------
extern uint16_t gWaterFallColors[];
extern uint16_t gScreenColors[];

extern void InitColors(bool night);

#define RED1		gScreenColors[0]			// smeter text
#define RED3		gScreenColors[1]			// mode background, filter
#define RED5		gScreenColors[2]			// status lock

#define GREEN2		gScreenColors[3]			// smeter
#define GREEN4		gScreenColors[4]			// service

#define BLUE5		gScreenColors[5]			// status band

#define YELLOW1		gScreenColors[6]			// smeter text
#define YELLOW2		gScreenColors[7]			// smeter max
#define YELLOW6		gScreenColors[8]			// bw spectrum

#define WHITE		gScreenColors[9]

#define GRAY1		gScreenColors[10]			// status fonts
#define GRAY2		gScreenColors[11]			// box border
#define GRAY4		gScreenColors[12]			// smeter bg, other vfo
#define GRAY6		gScreenColors[13]			// box background

#define BLACK		gScreenColors[14]

#endif
