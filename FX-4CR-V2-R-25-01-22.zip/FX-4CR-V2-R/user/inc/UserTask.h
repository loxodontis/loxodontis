/*
 * This file is part of the FX-4CR-V2 project.
 * See: https://github.com/f5bud/FX-4CR-V2
 *
 * Copyright (c) 2024 Daniel Nespoulous, F5BUD
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
//-----------------------------------------------------------------------------
//	UserTask.h
//-----------------------------------------------------------------------------
#ifndef INC_USERTASK_H_
#define INC_USERTASK_H_

//-----------------------------------------------------------------------------
#include "Kernel.h"
#include "IwdgBase.h"
#include "Settings.h"
#include "Calibres.h"
#include "Encoders.h"
#include "SideTone.h"

//-----------------------------------------------------------------------------
#define USERSTACK_SIZE 256				// (size * 4)

#define CWTRACE_SIZE 60
//-----------------------------------------------------------------------------
class UserTask: private IwdgBase, public Thread, public Settings, public Calibres
{
private:
	GpioPin		mBackLight = GpioPin(GPIOD, 15, eOutMode, ePushPull,  eLowSpeed, ePullDown, 0);	// Low = light
	GpioPin		mPowerSup  = GpioPin(GPIOB,  5, eOutMode, eOpenDrain, eLowSpeed, ePullUp,   0);	// Low = power up

	GpioPin		mBltCnted = GpioPin(GPIOC,  8, eInMode,  eOpenDrain, eLowSpeed, ePullUp, 0);	// Bluetooth connect
	GpioPin		mBltPower = GpioPin(GPIOD, 14, eOutMode, eOpenDrain, eLowSpeed, ePullUp, 0);	// Bluetooth power

	GpioPin		mPttKey   = GpioPin(GPIOB, 14, eInMode, eOpenDrain, eLowSpeed, ePullUp, 0);

	EncoderAf	mEncoderAf;
	EncoderTune	mEncoderTune;

	SideTone	mSideTone;

	eRadioType	mRadioType;
	uint64_t	mBigTimer;
	int16_t		mMenuIndex;

	bool		mCatPtt;
	bool		mRitPtt;

	std::string mMenuText;
	std::string mMenuValue;

	char		mCwTrace[CWTRACE_SIZE + 1];

	eCallerType mCallerType;
	int16_t 	mCallerCount;
	int16_t 	mCallerRepeat;

	static void Handler();

	void Loop				();

	void backLight			(bool value);

	std::string userEvent	();
	std::string userMenu	(int32_t afValue, int32_t tuneValue);
	std::string serviceMenu	(int32_t afValue, int32_t tuneValue);

	std::string setCwMsg	(int16_t index);
	std::string setNoneMsg	();
	std::string setTraceMsg	();
	std::string setVoiceMsg	();
	std::string showSpace	(char *value, bool shift);
	std::string VoiceRepeat	(eCallerType value, bool flag);

public:
	UserTask():Thread		(Handler, USERSTACK_SIZE) { }

	bool		getBltCnted	();
	bool		getCatPtt	();
	eInputType	getKeyTone	();
	bool		getPttKey	();
	const char *getMenuText	();
	const char *getMenuValue();
	eRadioType  getRadioType();
	SetBandType &getSetBand	();
	float32_t	getTxPower	();

	std::string getCallerStr();

	void		flashVoice	();
	void		setCatPtt	(bool value);
	void		setRadioType(eRadioType value);
	void		setRitPtt	(bool value);

	void		CwCorrection(bool all);
	void		ErrorHandler();
	void		PowerOff	();
	void		SendMessage	(eCallerType value);
};
//-----------------------------------------------------------------------------
extern UserTask gUserTask;

#endif
