/*
 * This file is part of the FX-4CR-V2 project.
 * See: https://github.com/f5bud/FX-4CR-V2
 *
 * Copyright (c) 2024 Daniel Nespoulous, F5BUD
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
//-----------------------------------------------------------------------------
//	ScreenTask.h
//-----------------------------------------------------------------------------
#ifndef INC_SERIALTASK_H_
#define INC_SERIALTASK_H_

//-----------------------------------------------------------------------------
#include "Kernel.h"

//-----------------------------------------------------------------------------
#define SERIALSTACK_SIZE 256				// (size * 4)

//-----------------------------------------------------------------------------
typedef std::string (*GetFuncType)(const char *masq);
typedef std::string (*SetFuncType)(const char *masq, const char *cmde);

typedef struct
{
	const char *Masq;
	GetFuncType	GetFunc;
	SetFuncType	SetFunc;
	bool Flag;
} MsgControlType;


enum eRMCmd
{
	eNset,			// 0: No selection, return values type: 0000 ~ 0030: Meter value in dots
	eSwr,			// 1: SWR
	eComp,			// 2: COMP
	eAlc			// 3: ALC
};
//-----------------------------------------------------------------------------
class SerialTask: public Thread
{
private:
	static void Handler();

	void Loop();

	static void CallBack();

	static int16_t		getTS590SMode();
	static int16_t		getTS590SVfo();
	static int16_t		getTS590SMem();
	static std::string	getTS590SRit();

	std::string execute(std::string cmde);

public:
	SerialTask():Thread(Handler, SERIALSTACK_SIZE) { }

	static std::string getAtte	(const char *masq);
	static std::string getBand	(const char *masq);
	static std::string getData	(const char *masq);
	static std::string getGain	(const char *masq);
	static std::string getInfo	(const char *masq);
	static std::string getMode	(const char *masq);
	static std::string getNone	(const char *masq);
	static std::string getPrea	(const char *masq);
	static std::string getPwr	(const char *masq);
	static std::string getRxRx	(const char *masq);
	static std::string getSmtr	(const char *masq);
	static std::string getStat	(const char *masq);
	static std::string getMeter	(const char *masq);
	static std::string getVer	(const char *masq);
	static std::string getVfoA	(const char *masq);
	static std::string getVfoB	(const char *masq);
	static std::string getVfoM	(const char *masq);

	static std::string setAtte	(const char *masq, const char *cmde);
	static std::string setBand	(const char *masq, const char *cmde);
	static std::string setData	(const char *masq, const char *cmde);
	static std::string setGain	(const char *masq, const char *cmde);
	static std::string setInfo	(const char *masq, const char *cmde);
	static std::string setMenu	(const char *masq, const char *cmde);
	static std::string setMode	(const char *masq, const char *cmde);
	static std::string setNone	(const char *masq, const char *cmde);
	static std::string setPrea	(const char *masq, const char *cmde);
	static std::string setMeter	(const char *masq, const char *cmde);
	static std::string setTxTx	(const char *masq, const char *cmde);
	static std::string setVfoA	(const char *masq, const char *cmde);
	static std::string setVfoB	(const char *masq, const char *cmde);
	static std::string setVfoM	(const char *masq, const char *cmde);

	static std::string Calibre	(const char *masq, const char *cmde);
};
//-----------------------------------------------------------------------------
extern SerialTask gSerialTask;

#endif
