/*
 * This file is part of the FX-4CR-V2 project.
 * See: https://github.com/f5bud/FX-4CR-V2
 *
 * Copyright (c) 2024 Daniel Nespoulous, F5BUD
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE. 
 */
//-----------------------------------------------------------------------------
//	ScreenColors.cpp
//-----------------------------------------------------------------------------
#include "ScreenColors.h"

//-----------------------------------------------------------------------------
uint16_t gScreenColors[15];
uint16_t gWaterFallColors[16];

//-----------------------------------------------------------------------------
static const uint16_t sScreenHiColors[15] =
{
	0b11110'000000'00000,			// RED1, smeter text
	0b11000'000000'00000,			// RED3, mode background, filter
	0b01100'000000'00000,			// RED5, status lock

	0b00000'100111'00000,			// GREEN2, smeter
	0b00000'010000'00000,			// GREEN4, service

	0b00000'000000'01100,			// BLUE5, status band

	0b11110'111110'00000,			// YELLOW1, smeter text
	0b10000'110000'00000,			// YELLOW2, smeter max
	0b00101'001100'00000,			// YELLOW6, bw spectrum

	0b11111'111111'11111,			// WHITE

	0b11000'110000'11000,			// GRAY1, status fonts
	0b10000'100000'10000,			// GRAY2, box border
	0b01000'010000'01000,			// GRAY4, smeter bg, other vfo
	0b00100'001000'00100,			// GRAY6, box background
	0b00000'000000'00000,			// BLACK
};

static const uint16_t sWaterFallHiColors[16] =
{
	0b00000'000000'00100,
	0b00000'000001'10100,
	0b00110'001100'10100,
	0b01010'010100'10001,
	0b01110'011100'01110,
	0b10010'100100'01010,
	0b10110'101100'00111,
	0b11010'110100'00100,
	0b11110'111100'00001,
	0b11111'110011'00000,
	0b11111'101100'00000,
	0b11111'100100'00000,
	0b11111'011100'00000,
	0b11111'010100'00000,
	0b11111'001100'00000,
	0b11111'000100'00000,
};

//-----------------------------------------------------------------------------
typedef struct
{
	uint16_t r : 5;
	uint16_t g : 6;
	uint16_t b : 5;
} Rgb_t;

typedef union
{
	Rgb_t rgb;
	uint16_t color;
} RgbColor_t;

//-----------------------------------------------------------------------------
void InitColors(bool night)
{
	RgbColor_t color;

	for (int16_t i = 0; i < 15; i ++)
	{
		color.color = sScreenHiColors[i];

		if (night)
		{
			color.rgb.r = (color.rgb.r * 25) / 100;
			color.rgb.g = (color.rgb.g * 35) / 100;
			color.rgb.b = (color.rgb.b * 25) / 100;
		}

		gScreenColors[i] = color.color;
	}

	for (int16_t i = 0; i < 16; i ++)
	{
		color.color = sWaterFallHiColors[i];

		if (night)
		{
			color.rgb.r = (color.rgb.r * 25) / 100;
			color.rgb.g = (color.rgb.g * 25) / 100;
			color.rgb.b = (color.rgb.b * 25) / 100;
		}

		gWaterFallColors[i] = color.color;
	}
}
//-----------------------------------------------------------------------------
