/*
 * This file is part of the FX-4CR-V2 project.
 * See: https://github.com/f5bud/FX-4CR-V2
 *
 * Copyright (c) 2024 Daniel Nespoulous, F5BUD
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE. 
 */
//-----------------------------------------------------------------------------
//	Eeprom.cpp
//-----------------------------------------------------------------------------
#include "Eeprom.h"

// for ATMLH11464DM address as 2 bytes
//-----------------------------------------------------------------------------
void Eeprom::WritePage(uint8_t addr, int16_t page, uint8_t *data)
{
	if (mMutex.Lock())
	{
		int16_t write = PAGE_SIZE;

		addr &= 0b1111'1110;													// bit write

		mI2c->CR2 = 0;

		MODIFY_REG(mI2c->CR2, I2C_CR2_SADD,          addr << I2C_CR2_SADD_Pos);
		MODIFY_REG(mI2c->CR2, I2C_CR2_NBYTES, (write + 2) << I2C_CR2_NBYTES_Pos);

		SET_BIT(mI2c->CR2, I2C_CR2_AUTOEND);									// 1: STOP condition is sent when NBYTES data are transferred
		SET_BIT(mI2c->CR2, I2C_CR2_START);

		WaitOnFlag(I2C_ISR_TXIS, false);										// Set by hardware when the TXDR is empty
		mI2c->TXDR = (page >> 4);												// page [0x000 - 0xFFF] (4096 pages)

		WaitOnFlag(I2C_ISR_TXIS, false);										// Set by hardware when the TXDR is empty
		mI2c->TXDR = (page << 4);

		while (write > 0)
		{
			WaitOnFlag(I2C_ISR_TXIS, false);									// Set by hardware when the TXDR is empty
			mI2c->TXDR = *(data ++);

			write --;
		}

		WaitOnFlag(I2C_ISR_BUSY, true);

		mMutex.Unlock();
	}
}
//-----------------------------------------------------------------------------
void Eeprom::ReadPage(uint8_t addr, int16_t page, uint8_t *data)
{
	if (mMutex.Lock())
	{
		int16_t read = PAGE_SIZE;

		addr &= 0b1111'1110;													// bit write

		mI2c->CR2 = 0;

		MODIFY_REG(mI2c->CR2, I2C_CR2_SADD, addr << I2C_CR2_SADD_Pos);
		MODIFY_REG(mI2c->CR2, I2C_CR2_NBYTES,  2 << I2C_CR2_NBYTES_Pos);

		SET_BIT(mI2c->CR2, I2C_CR2_START);

		WaitOnFlag(I2C_ISR_TXIS, false);										// Set by hardware when the TXDR is empty
		mI2c->TXDR = (page >> 4);												// page [0x000 - 0xFFF] (4096 pages)

		WaitOnFlag(I2C_ISR_TXIS, false);										// Set by hardware when the TXDR is empty
		mI2c->TXDR = (page << 4);

		WaitOnFlag(I2C_ISR_TC, false);											// Transfer Complete, AUTOEND = 0 !!!

		addr |= 0b0000'0001;													// bit read

		mI2c->CR2 = 0;

		MODIFY_REG(mI2c->CR2, I2C_CR2_SADD,   addr << I2C_CR2_SADD_Pos);		// 0xA0 and R/W with I2C_CR2_RD_WRN
		MODIFY_REG(mI2c->CR2, I2C_CR2_NBYTES, read << I2C_CR2_NBYTES_Pos);

		SET_BIT(mI2c->CR2, I2C_CR2_RD_WRN);										// 1: Master requests a read transfer.
		SET_BIT(mI2c->CR2, I2C_CR2_AUTOEND);									// 1: STOP condition is sent when NBYTES data are transferred
		SET_BIT(mI2c->CR2, I2C_CR2_START);

		while (read > 0)
		{
			WaitOnFlag(I2C_ISR_RXNE, false);									// Set by hardware when RXDR is ready
			*(data ++) = (uint8_t) mI2c->RXDR;

			read --;
		}

		WaitOnFlag(I2C_ISR_BUSY, true);

		mMutex.Unlock();
	}
}
//-----------------------------------------------------------------------------
