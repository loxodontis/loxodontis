/*
 * This file is part of the FX-4CR-V2 project.
 * See: https://github.com/f5bud/FX-4CR-V2
 *
 * Copyright (c) 2024 Daniel Nespoulous, F5BUD
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE. 
 */
//-----------------------------------------------------------------------------
//	main.cpp
//-----------------------------------------------------------------------------
#include "Kernel.h"

#include "Uarts.h"
#include "Eeprom.h"

#include "UserTask.h"
#include "SerialTask.h"
#include "ScreenTask.h"
#include "RadioTask.h"

//-----------------------------------------------------------------------------
bool gServiceMode;																// true == service mode

//-----------------------------------------------------------------------------
extern "C" int main()
{
	SystemClockSetup();
	SystemCacheEnable();

	gUart1.Init();
	gUart3.Init();

	gI2cData.Init();

	Scheduler::Append(gUserTask);
	Scheduler::Append(gSerialTask);
	Scheduler::Append(gScreenTask, SUSPENDED);
	Scheduler::Append(gRadioTask,  SUSPENDED);

	Scheduler::Run();															// gives control to the kernel
}

#ifdef DEBUG
//-----------------------------------------------------------------------------
extern"C" void HardFault_Handler ()
{
	gUart1.write("HardFault\n");
	while (1);
}
//-----------------------------------------------------------------------------
extern"C" void MemManage_Handler()
{
	gUart1.write("MemFault\n");
	while (1);
}
//-----------------------------------------------------------------------------
extern"C" void UsageFault_Handler()
{
	gUart1.write("UsageFault\n");
	while (1);
}
//-----------------------------------------------------------------------------
#endif
